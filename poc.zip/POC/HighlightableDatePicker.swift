//
//  HighlightableDatePicker.swift
//  ortho
//
//  Created by SAIL on 07/05/24.
//
import UIKit



class HighlightableDatePicker: UIDatePicker {
    private var highlightedDates = [String]()

    func highlightDates(_ dates: [String]) {
        highlightedDates = dates
        setNeedsDisplay()
    }

    override func draw(_ rect: CGRect) {
        super.draw(rect)

        guard let context = UIGraphicsGetCurrentContext() else {
            return
        }

        context.saveGState()

        let calendar = Calendar.current
        let components = calendar.dateComponents([.year, .month, .day], from: self.date)
        let today = calendar.date(from: components)!

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"

        for dateString in highlightedDates {
            if let date = dateFormatter.date(from: dateString),
               calendar.isDate(today, inSameDayAs: date) {
                let origin = originOfDate(date)
                let radius: CGFloat = 6.0
                let circleRect = CGRect(x: origin.x - radius, y: origin.y - radius, width: radius * 2, height: radius * 2)

                context.setFillColor(UIColor.red.cgColor)
                context.fillEllipse(in: circleRect)
            }
        }

        context.restoreGState()
    }

    private func originOfDate(_ date: Date) -> CGPoint {
        let calendar = Calendar.current
        let startOfMonth = calendar.startOfDay(for: self.date)

        let components = calendar.dateComponents([.day], from: startOfMonth, to: date)
        let daysOffset = CGFloat(components.day!)

        let totalDays = CGFloat(calendar.range(of: .day, in: .month, for: self.date)!.count)

        let ratio = daysOffset / totalDays

        let pickerSize = self.frame.size
        let xPos = ratio * pickerSize.width

        return CGPoint(x: xPos, y: pickerSize.height / 2)
    }
}

