import UIKit

class medications: UIViewController {

    @IBOutlet weak var updatedmedfield: UITextField!
    @IBOutlet weak var addvicefield: UITextField!
    @IBOutlet weak var calview: UIView!

    var patientId = String()
    var date = String()
    var selectedDate = String()
    var highlightedDates = [TotalDates]()
    var datePicker = UIDatePicker()
    
    
  
    let datesToHighlight = ["2024-04-23", "2024-04-25", "2024-04-30"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        showDatePicker()
        getDate()
     
     
       
    }
    


    @IBAction func backtsp(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    

    func showDatePicker() {
        // Formate Date
        datePicker.datePickerMode = .date

        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .inline
        } else {
            datePicker.preferredDatePickerStyle = .wheels
        }

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let specificDate = dateFormatter.date(from: date)
        datePicker.date = specificDate ?? Date()

//        let highlightedDates = self.highlightedDates.map { $0.date }
//           datePicker.highlightDates(highlightedDates)

        let toolbar = UIToolbar()
        toolbar.sizeToFit()

        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donedatePicker(_:)))

        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)

        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.cancelDatePicker(_:)))

        toolbar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        view.addSubview(datePicker)
        view.addSubview(toolbar)
        datePicker.translatesAutoresizingMaskIntoConstraints = false
        toolbar.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            datePicker.topAnchor.constraint(equalTo: calview.topAnchor),
            datePicker.leadingAnchor.constraint(equalTo: calview.leadingAnchor),
            datePicker.trailingAnchor.constraint(equalTo: calview.trailingAnchor),
            datePicker.bottomAnchor.constraint(equalTo: calview.bottomAnchor, constant: -10),

            toolbar.topAnchor.constraint(equalTo: datePicker.bottomAnchor, constant: -10),
            toolbar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            toolbar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
    }

    @objc func cancelDatePicker(_ sender: UIButton) {
        // Handle cancel action if needed
    }

    @objc func donedatePicker(_ sender: UIButton) {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        self.selectedDate = formatter.string(from: datePicker.date)
        print(formatter.string(from: datePicker.date))
    }
    
    func getDate() {
        let formData = [
            "pid": patientId,
        ]

        APIHandler().postAPIValues(type: HighLightDate.self, apiUrl: ServiceAPI.dateHighlight , method: "POST", formData: formData) { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
                if data.status == "success" {
                    DispatchQueue.main.async {
                        self?.highlightedDates = data.data
                        let val = data.data.map({$0.date})
                        print(val)
                       
                      
                       
                    }
                } else {
                    DispatchQueue.main.async {
                        print("Error: \(data.message)")
                      
                    }
                }
            case .failure(let error):
                print("API Failure: \(error)")
                DispatchQueue.main.async {
                   
                }
            }
        }
    }

    @IBAction func addreports(_ sender: Any) {
        if updatedmedfield.text != "" && addvicefield.text != "" {
            DispatchQueue.main.async { [self] in
                print("UserID from data pass", self.patientId)
                print("UserID from data pass", self.date)
                
                guard let updatedmed = self.updatedmedfield.text,
                      let advice = self.addvicefield.text
                else {
                    self.showAlert(title: "Error", message: "All fields are required")
                    return
                }

                let formData = [
                    "pid": patientId,
                    "updatedmed": updatedmed,
                    "addvice": advice,
                    "date":date
                ]
                print("pid: \(patientId), updatedmed: \(updatedmed), advice: \(advice)")

                APIHandler().postAPIValues(type: addreports1.self, apiUrl: ServiceAPI.addreports , method: "POST", formData: formData) { [weak self] result in
                    switch result {
                    case .success(let data):
                        print(data)
                        if data.status == true {
                            DispatchQueue.main.async {
                                print("Success: \(data.message)")
                                self?.showAlert(title: "Success", message: data.message)
                            }
                        } else {
                            DispatchQueue.main.async {
                                print("Error: \(data.message)")
                                self?.showAlert(title: "Error", message: data.message)
                            }
                        }
                    case .failure(let error):
                        print("API Failure: \(error)")
                        DispatchQueue.main.async {
                            self?.showAlert(title: "Error", message: "Failed to register patient. Please try again.")
                        }
                    }
                }
            }
        } else {
            DispatchQueue.main.async {
                if let nav = self.navigationController {
                    DataManager.shared.sendMessage(title: "Message", message: "Fill required fields!", navigation: nav)
                }
            }
        }
    }

    func showAlert(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)

        let cancelAction = UIAlertAction(title: "Yes", style: .cancel) { _ in
            if let navigationController = self.navigationController {
                for viewController in navigationController.viewControllers {
                    if let desiredViewController = viewController as? followUpListvc {
                        navigationController.popToViewController(desiredViewController, animated: true)
                        break
                    }
                }
            }
        }
        alertController.addAction(cancelAction)

        if let viewController = UIApplication.shared.keyWindow?.rootViewController {
            viewController.present(alertController, animated: true, completion: nil)
        }
    }
}
