//
//  TabBarController.swift
//  ortho
//
//  Created by SAIL L1 on 22/11/23.
//

import UIKit

class TabBarController: UITabBarController {
    var did : String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
//       let storyboard = UIStoryboard(name: "Main", bundle: nil)
       
        // Do any additional setup after loading the view.
    }
    

 

}
