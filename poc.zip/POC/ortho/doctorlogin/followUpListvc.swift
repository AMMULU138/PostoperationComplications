//
//  followUpListvc.swift
//  ortho
//
//  Created by SAIL on 08/02/24.
//

import UIKit

class followUpListvc: UIViewController {

    @IBOutlet weak var ListTable: UITableView!
    var FList: FollowupList?
    var patientId:String?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ListTable.dataSource = self
        ListTable.delegate = self
        LoadingIndicator.shared.showLoading(on: self.view)
        getDashAPI()
    }
    
    
    func getDashAPI() {
        
        let apiURL = ServiceAPI.flistURL
        print(apiURL)

        // Prepare POST parameters if needed
        let parameters: [String: String] = [:
            // Add your JSON parameters here if required
            // "key1": value1,
            // "key2": value2,
        ]

        APIHandler().postAPIValues(type: FollowupList.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    LoadingIndicator.shared.hideLoading()
                self.FList = data

                   self.ListTable.reloadData()
                }
            case .failure(let error):DispatchQueue.main.async {
                LoadingIndicator.shared.hideLoading()
              if let nav = self.navigationController {
                  DataManager.shared.sendMessage(title: "Message", message: "Something went wrong!", navigation: nav)
        
                
                print(error)
            }
            
        }
    }
    
        }
    }
    @IBAction func bcakTapped(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
  
  
}


extension followUpListvc: UITableViewDataSource,UITableViewDelegate {

    
 

   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return self.FList?.data.count ?? 0
   }

   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "followUplist", for: indexPath) as! followUplist
//        cell.name.text = PList?.data[indexPath.row].pname ?? " "
//        cell.diagonsis.text = PList?.data[indexPath.row].diagnosis ?? " "
      // cell.viewbutton.backgroundColor = .red
        cell.patname.text = "\(FList?.data[indexPath.row].pid ?? 0)"
       cell.date.text = FList?.data[indexPath.row].date ?? " "
   
       cell.tap = {
    
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "analysis") as! analysis
        vc.patientId = "\(self.FList?.data[indexPath.row].pid ?? 0)"
        vc.date = self.FList?.data[indexPath.row].date ?? " "
        self.navigationController?.pushViewController(vc, animated: true)
           
       }
        return cell
   }
   
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150.0
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        if let foolowList = self.FList {
            let vc = storyBoard.instantiateViewController(withIdentifier: "analysis") as! analysis
            vc.patientId = "\(foolowList.data[indexPath.row].pid)"
            vc.date = self.FList?.data[indexPath.row].date ?? " "
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}
