//
//  analysis.swift
//  ortho
//
//  Created by SAIL L1 on 15/11/23.
//

import UIKit

class analysis: UIViewController {
    
    
    var id: String?
    var GraphData: BarModel?
    var quesDataArray: [String] = []
    var respDataArray: [String] = []
    var patientId = String()
    var date = String()
    @IBOutlet weak var barChartView: UIView!
    
    
    let dataPoints = ["q1", "q2", "q3", "q4", "q5","q6", "q7", "q8", "q9", "q10","q11", "q12", "q13", "q14","q15"]
    var barValues:[CGFloat] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LoadingIndicator.shared.showLoading(on: self.view)
        barModelApi()
    }


    func barModelApi() {
       
        let formData = [
            "pid": patientId,
           "date": date,
        ]
        

        APIHandler().postAPIValues(type: BarModel.self, apiUrl: ServiceAPI.BarGraphAPI, method: "POST", formData: formData) {  result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    LoadingIndicator.shared.hideLoading()
                    if !data.quesData.isEmpty  {
                        print(data.quesData)
                    
                        let cgFloatArray = data.quesData.map{
                            CGFloat(Double($0) ?? 0.0)
                        }
                        var value = CGFloat()
                        let add = cgFloatArray.map{ val in
                            if val == 0.0 {
                                value = 1.0
                            }else {
                                value = val
                            }
                            self.barValues.append(value)
                        }
                      
                        self.drawBarChart(dataPoints: self.dataPoints, values: self.barValues)
                    } else {
                        // Handle unsuccessful API call
                        print("quesData is nil")
                        // Display an error message or take appropriate action
                    }
                }
            case .failure(let error):
                print("Error: \(error)")
                DispatchQueue.main.async {
                    LoadingIndicator.shared.hideLoading()
                  if let nav = self.navigationController {
                      DataManager.shared.sendMessage(title: "Message", message: "Something went wrong!", navigation: nav)
            
                    
                    print(error)
                  }
                }
            }
        }
    }
    
    @IBAction func report(_ sender: Any) {let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ExerciseStatusVc") as! ExerciseStatusVc
        vc.patientId = self.patientId
        vc.date = self.date
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func backbtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
        
    }
    
}
extension analysis {
    
    
    
   
    func drawBarChart(dataPoints: [String], values: [CGFloat]) {
        let barWidth: CGFloat = 30
        let spaceBetweenBars: CGFloat = 20
        let maxValue = values.max() ?? 100
        
        let yLabels: [String] = ["Normal", "Mild", "Moderate", "Severe"]
        
        // Define an array of colors corresponding to each yLabel
        let barColors: [UIColor] = [UIColor(hex: "##BAD609"),UIColor(hex: "##FFD609"),UIColor(hex: "#FD850B"),UIColor(hex: "##FF3B30")]
        
        for (index, value) in values.enumerated() {
            let barHeight = (value / maxValue) * barChartView.frame.height
            
            let barX = CGFloat(index) * (barWidth + spaceBetweenBars)
            let barY = barChartView.frame.height - barHeight
            
            let bar = UIBezierPath(roundedRect: CGRect(x: barX, y: barY, width: barWidth, height: barHeight),
                                   byRoundingCorners: [.topLeft, .topRight],
                                   cornerRadii: CGSize(width: 8, height: 8))
            
            let barLayer = CAShapeLayer()
            barLayer.path = bar.cgPath
            
            // Set the fillColor based on the corresponding category
            let colorIndex = yLabels.firstIndex(of: yLabels[scaledValue(value, maxValue: maxValue, count: yLabels.count)]) ?? 0
            barLayer.fillColor = barColors[colorIndex].cgColor
            
            // Check if the category is "Normal" and the value is at least 5%
            if yLabels[colorIndex] == "Normal" && (value / maxValue) * 100 >= 5 {
                barLayer.fillColor = UIColor.green.cgColor // Change the color for "Normal" with at least 5%
            }
            
            barChartView.layer.addSublayer(barLayer)
            
            // Optionally, add labels for data points
           
            let label = UILabel(frame: CGRect(x: barX, y: barChartView.frame.height, width: barWidth, height: 20))
            label.text = dataPoints[index]
            label.textAlignment = .center
            label.textColor = .blue
            label.font = UIFont.systemFont(ofSize: 8)
            barChartView.addSubview(label)
            
        }
    }
    
    func scaledValue(_ value: CGFloat, maxValue: CGFloat, count: Int) -> Int {
        let scaledValue = (value / maxValue) * CGFloat(count - 1)
        return Int(round(scaledValue))
    }

}



import UIKit

extension UIColor {
    convenience init(hex: String, alpha: CGFloat = 1.0) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")

        var rgb: UInt64 = 0

        Scanner(string: hexSanitized).scanHexInt64(&rgb)

        let red = CGFloat((rgb & 0xFF0000) >> 16) / 255.0
        let green = CGFloat((rgb & 0x00FF00) >> 8) / 255.0
        let blue = CGFloat(rgb & 0x0000FF) / 255.0

        self.init(red: red, green: green, blue: blue, alpha: alpha)
    }
}

