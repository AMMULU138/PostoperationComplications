//
//  operationalDeatils.swift
//  ortho
//
//  Created by SAIL L1 on 27/10/23.
//

import UIKit;
class operationalDeatils: UIViewController {
    
    @IBOutlet weak var statusfield: UILabel!
    

    
    @IBOutlet weak var procdoneField: UILabel!
    
    @IBOutlet weak var dtofproc: UILabel!
    
    @IBOutlet weak var cheifcomField: UITextView!
    
    
    @IBOutlet weak var hopfield: UITextView!
    
    @IBOutlet weak var pasthisField: UITextView!

    
    @IBOutlet weak var treatmentgivenField: UITextView!
    
    @IBOutlet weak var otdetaisfield: UITextView!
    @IBOutlet weak var coursesinhosFiled: UITextView!
    
    @IBOutlet weak var xRayimage: UIImageView!
    var patientId = String()
    var viewPopList:ViewPop?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LoadingIndicator.shared.showLoading(on: self.view)
        getViewPopAPI()
    }

    func getViewPopAPI() {
        let apiURL = ServiceAPI.viewPop
        let parameters: [String: String] = [
             "pid": patientId,]
        APIHandler().postAPIValues(type: ViewPop.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    if data.status == true {
                    LoadingIndicator.shared.hideLoading()
                self.viewPopList = data
                    self.statusfield.text = self.viewPopList?.viewpatientoperationaldetails.first?.status
                    self.procdoneField.text = self.viewPopList?.viewpatientoperationaldetails.first?.proc
                    self.cheifcomField.text = self.viewPopList?.viewpatientoperationaldetails.first?.chfcompliants
                    self.hopfield.text = self.viewPopList?.viewpatientoperationaldetails.first?.hop
                        self.dtofproc.text = self.viewPopList?.viewpatientoperationaldetails.first?.dtofproc
                    self.pasthisField.text = self.viewPopList?.viewpatientoperationaldetails.first?.cinhos
                    self.otdetaisfield.text = self.viewPopList?.viewpatientoperationaldetails.first?.otdetails
                    self.treatmentgivenField.text = self.viewPopList?.viewpatientoperationaldetails.first?.treatmentgiven
                    self.coursesinhosFiled.text = self.viewPopList?.viewpatientoperationaldetails.first?.cinhos
                    self.loadImage(url:  self.viewPopList?.viewpatientoperationaldetails.first?.pimage ?? "", imageView: self.xRayimage)
                  
                    }else {
                        if let nav = self.navigationController {
                        DataManager.shared.sendMessage(title: "Message", message: "Something went wrong!", navigation: nav)
                        }
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    LoadingIndicator.shared.hideLoading()
                    if let nav = self.navigationController {
                    DataManager.shared.sendMessage(title: "Message", message: "Something went wrong!", navigation: nav)
                    }
                  
            }
        }
    }
        
    }
    @IBAction func backtapbutn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
        

    
}


