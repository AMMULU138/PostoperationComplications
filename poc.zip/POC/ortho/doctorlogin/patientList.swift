//
//  patientList.swift
//  ortho
//
//  Created by SAIL L1 on 24/10/23.
//

import UIKit

class patientList: UIViewController {
    



    @IBOutlet weak var table2: UITableView!
    
    
    
    var PList: PatientList?
    var patientId:String?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        table2.dataSource = self
        table2.delegate = self
        
       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        LoadingIndicator.shared.showLoading(on: self.view)
        getDashAPI()
        
    }
    
    
    func getDashAPI() {
        
        let apiURL = ServiceAPI.PatientListURL
        print(apiURL)

        // Prepare POST parameters if needed
        let parameters: [String: String] = [:
            // Add your JSON parameters here if required
            // "key1": value1,
            // "key2": value2,
        ]

        APIHandler().postAPIValues(type: PatientList.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                LoadingIndicator.shared.hideLoading()
                self.PList = data

                   self.table2.reloadData()
                }
            case .failure(let error):
                DispatchQueue.main.async {
                LoadingIndicator.shared.hideLoading()
              if let nav = self.navigationController {
                  DataManager.shared.sendMessage(title: "Message", message: "Check Our Internet Connection", navigation: nav)
        
                }
            }
        }
        }
    }
    
   
    @IBAction func bcakTapped(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
    
  
}


extension patientList: UITableViewDataSource,UITableViewDelegate {

    
 

   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return self.PList?.data.count ?? 0
   }

   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "listOfPatients", for: indexPath) as! listOfPatients
        cell.name.text = PList?.data[indexPath.row].pname ?? " "
//        cell.diagonsis.text = PList?.data[indexPath.row].diagnosis ?? " "
        cell.pid.text = "\(PList?.data[indexPath.row].pid ?? 0)"
       cell.pimage.clipsToBounds = true
       cell.pimage.layer.cornerRadius = 50
       
       
       let apiURL = ServiceAPI.PatientListURL
       print(apiURL)

       let url = URL(string:  PList?.data[indexPath.row].ppimage ?? "")
  
       loadImage(url: PList?.data[indexPath.row].ppimage ?? "", imageView: cell.pimage)

       
       cell.tap = {
    
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "patientDetails") as! patientDetails
        vc.patientId = "\(self.PList?.data[indexPath.row].pid ?? 0)"
        self.navigationController?.pushViewController(vc, animated: true)
           
       }
        return cell
   }
   
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150.0
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        if let patientList = self.PList {
            let vc = storyBoard.instantiateViewController(withIdentifier: "patientDetails") as! patientDetails
            vc.patientId = "\(patientList.data[indexPath.row].pid)"
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }

  
}
