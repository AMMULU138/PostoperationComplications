//
//  doctorLogin.swift
//  ortho
//
//  Created by SAIL L1 on 05/10/23.
//

import UIKit

class doctorLogin: UIViewController {

    var Dlogin: DloginModel!
    
    @IBOutlet weak var DidTXTfield: UITextField!
    @IBOutlet weak var passwordTXTfield: UITextField!
    @IBOutlet weak var login: UIButton!
    
    
    @IBOutlet weak var doctorView: UIView!
    @IBOutlet weak var mainView: UIView!
    
    
    @IBOutlet weak var passView: UIView!
    var did : String = ""
    
    var userDefault = UserDefaults()
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        LoadingIndicator.shared.showLoading(on: self.view)

        
    }

    
    @IBAction func login1(_ sender: Any) {
       
        if DidTXTfield.text?.isEmpty == true || passwordTXTfield.text?.isEmpty == true {
                    showAlert(title: "Alert", message: "Enter UserID & password")
                } else {
                    postAPI()
                }
}
    func postAPI() {
        let apiURL = ServiceAPI.LogInURL
        let formData = [
            "Did": DidTXTfield.text ?? "",
            "password": passwordTXTfield.text ?? ""
        ]
        
        APIHandler().postAPIValues(type: DloginModel.self, apiUrl: apiURL, method: "POST", formData: formData) { [weak self] result in
                guard let self = self else { return }
                switch result {
                case .success(let data):
                    DispatchQueue.main.async {
                        LoadingIndicator.shared.hideLoading()
                        if data.status == true {
                            self.did = self.DidTXTfield.text!
                            self.userDefault.set(self.DidTXTfield.text, forKey: "DoctorId")
                            self.navigateToHomePage()
                        }else {
                            self.showAlert(title: "Incorrect", message: "Incorrect User ID & Password")
                        }
                      
                    }
                
                
                case .failure(let error):
                    DispatchQueue.main.async {
                        LoadingIndicator.shared.hideLoading()
                      
                          self.showAlertMessage(title: "Alert", message: "Check Our Internet Connection.")
                
                        
                }
            }
        }
    }


    
            func navigateToHomePage() {
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let vc = storyboard.instantiateViewController(withIdentifier: "TabBarController") as! TabBarController
                vc.selectedIndex = 1
                vc.did = self.did
                DataManager.shared.doctorID = self.did
                print("Selected doctor ID -->", did)
                navigationController?.pushViewController(vc, animated: true)
            }
            
            func showAlert(title: String, message: String) {
                let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                present(alert, animated: true)
            }
    
    
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
}
