//
//  PatientDeatilsViewController.swift
//  ortho
//
//  Created by SAIL L1 on 28/11/23.
//

import UIKit
import Foundation

class PatientDeatilsViewController: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate,SendBackVc {
  
    
    
    
    
    @IBOutlet weak var nameField: UITextField!
    
    @IBOutlet weak var patientId: UITextField!
    
    @IBOutlet weak var genderField: UITextField!
    
    
    @IBOutlet weak var pmailfield: UITextField!
    
    
    @IBOutlet weak var consultantField: UITextField!
    
    
    @IBOutlet weak var addressField: UITextField!
    
    
    @IBOutlet weak var passwordField: UITextField!
    
    
    @IBOutlet weak var addBtn: UIButton!
    
    
    @IBOutlet weak var profileImage: UIImageView!
    
    
    var id: String?
    var selectedImage = [UIImage]()
    var imagePicker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        profileImage.isHidden = true
        
        
        profileImage.clipsToBounds = true
        profileImage.layer.cornerRadius = 50
        
        addBtn.layer.cornerRadius = 10
      
        nameField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
//        hospitalIdField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        genderField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        pmailfield.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        consultantField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        addressField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        passwordField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        addBtn.layer.cornerRadius = 10
        
        imagePicker.delegate = self
                imagePicker.allowsEditing = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        nameField.text = ""
        passwordField.text = ""
        genderField.text = ""
        patientId.text = ""
        pmailfield.text = ""
        consultantField.text = DataManager.shared.doctorID
        addressField.text = ""
        
        profileImage.image = UIImage(named: "Unknown")
        
       
       
    }
    
    
    func sendVc() {   // protocol delegates
        if let tab = self.tabBarController {
            tab.selectedIndex = 1
        }
    }
    
    @IBAction func tap(_ sender: Any) {
        
        
        

            let alertController = UIAlertController(title: "Message", message: "Do you want add patient", preferredStyle:UIAlertController.Style.alert)
            alertController.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { (action: UIAlertAction!) in
                alertController .dismiss(animated: true, completion: nil)
            }))
            alertController.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default)
              { action -> Void in
                
                if self.profileImage.image != nil {
                    self.addImage(url:ServiceAPI.addpp,type:"ppimage")
                }else {
                    self.showAlert(title: "Message", message: "Add xrayimage")
                }
                
              })
            self.present(alertController, animated: true, completion: nil)


      
    }
    
        
        @objc private func textFieldDidChange(_ textField: UITextField) {
            guard !selectedImage.isEmpty else {
                   print("No image selected")
                   return
               }
        guard let userId = patientId.text, !userId.isEmpty else {
                    addBtn.isEnabled = false
                    return
                }
         id = userId
        UserDefaults.standard.set(userId, forKey: "userId")


            guard let pid = patientId.text, !pid.isEmpty, let _ = Int(pid) else {
                    addBtn.isEnabled = false
                    return
                }
            guard let pgender = genderField.text, !pgender.isEmpty else {
                   addBtn.isEnabled = false
                   return
               }
            guard let pmail = pmailfield.text, !pmail.isEmpty, pmail.hasSuffix("@gmail.com") else {
                   addBtn.isEnabled = false
                   return
            }
            guard let pconsultant = consultantField.text, !pconsultant.isEmpty else {
                    addBtn.isEnabled = false
                    return
                }
            guard let paddress = addressField.text, !paddress.isEmpty else {
                   addBtn.isEnabled = false
                   return
               }

            addBtn.isEnabled = true
        }

func showAlert(title: String, message: String) {
if let presentedViewController = presentedViewController {
            presentedViewController.dismiss(animated: false) {
                                let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
                                            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                                            self.present(alert, animated: true)
                                        }
                                   }
                                        else {
                                      let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
                                     alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                                      self.present(alert, animated: true)
                                   }
                                }
    
    
    
    @IBAction func imageUpload(_ sender: Any) {
        
       
        presentImagePicker()
    }
    
    

    func presentImagePicker() {
                let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
                alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
                    self.openCamera()
                }))
                alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
                    self.openGallery()
                }))
                alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
                present(alert, animated: true, completion: nil)
            }
            
            
         
            
            func openCamera() {
                if UIImagePickerController.isSourceTypeAvailable(.camera) {
                    imagePicker.sourceType = .camera
                    present(imagePicker, animated: true, completion: nil)
                } else {
                    print("Camera not available")
                }
            }
            
            func openGallery() {
                imagePicker.sourceType = .photoLibrary
                present(imagePicker, animated: true, completion: nil)
            }

            func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
                  if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
                         profileImage.isHidden = false
                          profileImage.image = pickedImage
                          selectedImage.append(pickedImage)
                        
                         
                      }
                     
                  
                  
                  picker.dismiss(animated: true, completion: nil)
              }
            func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
                picker.dismiss(animated: true, completion: nil)
            }
       
       
       
       
       func addImage(url:String,type:String) {
           
           
           
           guard !selectedImage.isEmpty else {
               //   print("No image selected")
                  return
              }
               
                   guard addBtn.isEnabled else { return }
                           
                           guard let pname = nameField.text,
                                 !pname.isEmpty else {
                               showAlert(title: "Error", message: "ALL FIELDS ARE REQUIRED")
                               return
                          }
                   guard let pid = patientId.text,
                         !pid.isEmpty else {
                       showAlert(title: "Error", message: "ALL FIELDS ARE REQUIRED")
                       return
                  }
                   guard let pgender = genderField.text,
                         !pgender.isEmpty else {
                       showAlert(title: "Error", message: "ALL FIELDS ARE REQUIRED")
                       return
                  }
                   guard let pmail = pmailfield.text,
                         !pmail.isEmpty else {
                       showAlert(title: "Error", message: "ALL FIELDS ARE REQUIRED")
                       return
                  }
                   guard let paddress = addressField.text,
                         !paddress.isEmpty else {
                       showAlert(title: "Error", message: "ALL FIELDS ARE REQUIRED")
                       return
                  }
                   guard let pconsultant = consultantField.text,
                         !pconsultant.isEmpty else {
                       showAlert(title: "Error", message: "ALL FIELDS ARE REQUIRED")
                       return
                  }
                   guard let ppassword = passwordField.text,
                         !ppassword.isEmpty else {
                       showAlert(title: "Error", message: "ALL FIELDS ARE REQUIRED")
                       return
                  }
                 
                
                     
           
                  
                  let apiURL = url
                  print("API URL:",apiURL)

                  let boundary = UUID().uuidString
                  var request = URLRequest(url: URL(string: apiURL)!)
                  request.httpMethod = "POST"
                  request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
                  var body = Data()
//                  let formData: [String: String] = [
//                   "patient_id": "",
//
//                  ]
           
                let formData: [String: String] = [
                       "pid": pid,
                       "pname": pname,
                       "pgender": pgender,
                       "pmail": pmail,
                       "paddress": paddress,
                       "pconsultant": pconsultant,
                       "ppassword": ppassword,
                       ]
           
           
           
           
                    print("formData : \(formData)")
                  for (key, value) in formData {
                      body.append(contentsOf: "--\(boundary)\r\n".utf8)
                      body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
                      body.append(contentsOf: "\(value)\r\n".utf8)
                  }


               let fieldNames = [type]

               for (index, image) in selectedImage.enumerated() {
                   let fieldName = fieldNames[index]

                   let imageData = image.jpegData(compressionQuality: 0.8)!
                   body.append("--\(boundary)\r\n".data(using: .utf8)!)
                   body.append("Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".data(using: .utf8)!)
                   body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
                   body.append(imageData)
                   body.append("\r\n".data(using: .utf8)!)
               }




                  // Add closing boundary
                  body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body

                  request.httpBody = body

                  let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                      if let error = error {
                          print("Error: \(error)")
                          // Handle the error, e.g., show an alert to the user
                          return
                      }
                      self.selectedImage.removeAll()
                      if let httpResponse = response as? HTTPURLResponse {
                          print("Status code: \(httpResponse.statusCode)")


                          if let data = data {
                              if let responseData = String(data: data, encoding: .utf8) {
                                  if let jsonData = responseData.data(using: .utf8) {
                                      do {
                                          if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                                              if let status = json["status"] as? Bool, let message = json["message"] as? String {

                                                  DispatchQueue.main.async {
                                                      if status == true {
                                                          let alertController = UIAlertController(title: "Message", message: message, preferredStyle:UIAlertController.Style.alert)
//                                                          alertController.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { (action: UIAlertAction!) in
//                                                              alertController .dismiss(animated: true, completion: nil)
//                                                          }))
                                                          alertController.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default)
                                                            { action -> Void in
                                                                let storyBoard = UIStoryboard(name: "Main", bundle: nil)
                                                                let vc = storyBoard.instantiateViewController(withIdentifier: "AddOPDetails") as! AddOPDetails
                                                              vc.currentPatientId = self.patientId.text ?? ""
                                                              vc.delegate = self
                                                             // vc.diagonsis = self.patientId.text ?? ""
                                                              self.navigationController?.pushViewController(vc, animated: true)
                                                            })
                                                          self.present(alertController, animated: true, completion: nil)
                                                      }else {
                                                          if let nav = self.navigationController {
                                                              DataManager.shared.sendMessage(title: "Message", message: message, navigation: nav)
                                                          }
                                                      }
                                                  }
                                              }
                                          }
                                      } catch {
                                          DispatchQueue.main.async {
                                          print("Error parsing JSON: \(error)")
                                          }
                                      }
                                      }
                              }
                          }
                      }
                  }

                  task.resume()
              }
       
                    

}



               
