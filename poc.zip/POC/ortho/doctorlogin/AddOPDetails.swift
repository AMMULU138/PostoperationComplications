//
//  AddOPDetails.swift
//  ortho
//
//  Created by SAIL L1 on 02/12/23.
//

import UIKit

protocol SendBackVc {
    
    func sendVc()
}

class AddOPDetails: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    

    
    
    @IBOutlet weak var proc: UITextView!
    
    @IBOutlet weak var diagonsis: UITextView!
    @IBOutlet weak var dischargeadvice: UITextView!
    @IBOutlet weak var otdea: UITextView!
    @IBOutlet weak var treatmentg: UITextView!
    @IBOutlet weak var coursesinhop: UITextView!
    @IBOutlet weak var hiopsl: UITextView!
    @IBOutlet weak var dtproc: UITextField!
    @IBOutlet weak var chfcomp: UITextView!
    @IBOutlet weak var pastmedhist: UITextView!
    @IBOutlet weak var xrayimage: UIImageView!
    
    
    @IBOutlet weak var statusfield: UITextField!
    var selectedImage = [UIImage]()
    
    var imagePicker = UIImagePickerController()
    
    var currentPatientId:String?
    let statusOptions = ["inpatient", "Outpatient"]
    var delegate: SendBackVc?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
  
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        
//        statusfield.delegate = self
//                statusfield.dataSource = self
    }

    @IBAction func savedetails(_ sender: Any) {
     
        if xrayimage.image != nil {
            addImage(url:ServiceAPI.addpop,type:"pimage")
        }else {
            self.showAlert(title: "Message", message: "Add xrayimage")
        }
        
        
       
 }
    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    
    @IBAction func backbtn(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }



func presentImagePicker() {
            let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
            alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
                self.openCamera()
            }))
            alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
                self.openGallery()
            }))
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            present(alert, animated: true, completion: nil)
        }
        
        
     
        
        func openCamera() {
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                imagePicker.sourceType = .camera
                present(imagePicker, animated: true, completion: nil)
            } else {
                print("Camera not available")
            }
        }
        
        func openGallery() {
            imagePicker.sourceType = .photoLibrary
            present(imagePicker, animated: true, completion: nil)
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
              if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
              
                      xrayimage.image = pickedImage
                      selectedImage.append(pickedImage)
                    
                     
                  }
          
              
              
              picker.dismiss(animated: true, completion: nil)
          }
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true, completion: nil)
        }
   
   
   
   
   func addImage(url:String,type:String) {
       guard !selectedImage.isEmpty else {
              print("No image selected")
              return
          }
       if let userId = currentPatientId, let procdone = self.proc.text, let discharge = self.dischargeadvice.text, let diagonsis = self.diagonsis.text,let chfcompliants = self.chfcomp.text,
          let hop = self.hiopsl.text,
          let cinhos = self.coursesinhop.text,
          let treatmentgiven = self.treatmentg.text,
          let pmedhis = self.pastmedhist.text,
          let otdeatils = self.otdea.text,
          let dtofproc = self.dtproc.text,
            let pstatus = self.statusfield.text {
//           let selectedStatusRow = statusfield.
//              let pstatus = statusOptions[selectedStatusRow]
           
           let formData: [String:Any] = [
            "pid":userId,
            "status": pstatus,
            "diagonsis": diagonsis,
            "chfcompliants": chfcompliants,
            "cinhos": cinhos,
            "treatmentgiven": treatmentgiven,
            "otdeatils": otdeatils,
            "pmedicalhist": pmedhis,
            "dischargeadvice": discharge,
            "proc": procdone,
            "dtofproc": dtofproc,
            "hop": hop,
            
           ]
           
        
           
           let apiURL = url
           print("API URL:",apiURL)
           
           let boundary = UUID().uuidString
           var request = URLRequest(url: URL(string: apiURL)!)
           request.httpMethod = "POST"
           request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
           var body = Data()
           print("formData : \(formData)")
           for (key, value) in formData {
               body.append(contentsOf: "--\(boundary)\r\n".utf8)
               body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
               body.append(contentsOf: "\(value)\r\n".utf8)
           }
           
           let fieldNames = [type]
           for (index, image) in selectedImage.enumerated() {
               let fieldName = fieldNames[index]

               let imageData = image.jpegData(compressionQuality: 0.8)!
               body.append("--\(boundary)\r\n".data(using: .utf8)!)
               body.append("Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".data(using: .utf8)!)
               body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
               body.append(imageData)
               body.append("\r\n".data(using: .utf8)!)
           }
           body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body
           
           request.httpBody = body
           
           let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
               if let error = error {
                   print("Error: \(error)")
                   return
               }
               self.selectedImage.removeAll()
               if let httpResponse = response as? HTTPURLResponse {
                   print("Status code: \(httpResponse.statusCode)")
                   
                   if let data = data {
                       if let responseData = String(data: data, encoding: .utf8) {
                           if let jsonData = responseData.data(using: .utf8) {
                               do {
                                   if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                                       if let status = json["status"] as? Bool, let message = json["message"] as? String {
                                           
                                           DispatchQueue.main.async {
                                               if status == true {
                                                   let alertController = UIAlertController(title: "Message", message: message, preferredStyle:UIAlertController.Style.alert)
                                               
                                                   alertController.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default)
                                                                             { action -> Void in
                                                                                                                let storyBoard = UIStoryboard(name: "Main", bundle: nil)
                                                                                                                 let vc = storyBoard.instantiateViewController(withIdentifier: "AddOPDetails") as! AddOPDetails
                                                       self.delegate?.sendVc()
                                                       self.navigationController?.popViewController(animated: false)
                                                       
                                                   })
                                                   self.present(alertController, animated: true, completion: nil)
                                               }else {
                                                   if let nav = self.navigationController {
                                                       DataManager.shared.sendMessage(title: "Message", message: message, navigation: nav)
                                                   }
                                               }
                                           }
                                       }
                                   }
                               } catch {
                                   print("Error parsing JSON: \(error)")
                               }
                           }
                       }
                   }
               }
           }
           
           task.resume()
       } else {
           self.showAlert(title: "Error", message: "All fields are required")
       }
   }
   
            
    @IBAction func profileUploadTapped(_ sender: Any) {
        
        presentImagePicker()
    }
    

}

extension AddOPDetails: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1 // If you have multiple components, adjust accordingly
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return statusOptions.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return statusOptions[row]
    }
}


//
//class PlaceholderTextView: UITextView, UITextViewDelegate {
//    var placeholder: String = ""
//    var placeholderColor: UIColor = UIColor.lightGray
//
//    override var text: String! {
//        didSet {
//            updatePlaceholder()
//        }
//    }
//
//    override var attributedText: NSAttributedString! {
//        didSet {
//            updatePlaceholder()
//        }
//    }
//
//    override var textColor: UIColor! {
//        didSet {
//            if textColor != placeholderColor {
//                super.textColor = textColor
//            }
//        }
//    }
//
//    override func awakeFromNib() {
//        super.awakeFromNib()
//        self.delegate = self
//        setupPlaceholder()
//    }
//
//    private func setupPlaceholder() {
//        self.text = placeholder
//        self.textColor = placeholderColor
//    }
//
//    private func updatePlaceholder() {
//        if self.text.isEmpty {
//            setupPlaceholder()
//        } else {
//            self.textColor = super.textColor
//        }
//    }
//
//    // UITextViewDelegate method to handle text changes
//    func textViewDidChange(_ textView: UITextView) {
//        updatePlaceholder()
//    }
//
//    // Clear the placeholder when the user starts editing
//    func textViewDidBeginEditing(_ textView: UITextView) {
//        if self.text == placeholder {
//            self.text = ""
//            self.textColor = super.textColor
//        }
//    }
//
//    // Restore the placeholder if the text view is empty
//    func textViewDidEndEditing(_ textView: UITextView) {
//        updatePlaceholder()
//    }
//}
