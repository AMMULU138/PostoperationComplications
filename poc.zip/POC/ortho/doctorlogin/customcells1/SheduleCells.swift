//
//  SheduleCells.swift
//  ortho
//
//  Created by SAIL L1 on 25/11/23.
//

import UIKit

class SheduleCells: UITableViewCell
{
    
    @IBOutlet weak var pid: UILabel!
    
    @IBOutlet weak var date: UILabel!
    
    @IBOutlet weak var day: UILabel!
    

    @IBOutlet weak var slotLabel: UILabel!
    override func awakeFromNib()
    {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
        override func layoutSubviews() {
            super.layoutSubviews()
        let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        contentView.frame = contentView.bounds.inset(by: margin)
        contentView.layer.cornerRadius = 10
          }
}
