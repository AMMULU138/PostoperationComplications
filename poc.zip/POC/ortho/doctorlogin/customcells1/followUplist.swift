//
//  followUplist.swift
//  ortho
//
//  Created by SAIL L1 on 21/11/23.
//

import UIKit

class followUplist: UITableViewCell {

    @IBOutlet weak var profile: UIImageView!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var patname: UILabel!
    @IBOutlet weak var viewbutton: UIButton!
    var tap:(()->())?
    override func awakeFromNib() {
        super.awakeFromNib()
}
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
 }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
     let margin = UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
        contentView.frame = contentView.bounds.inset(by: margin)
        contentView.layer.cornerRadius = 10
    }

    @IBAction func viewAnalysis(_ sender: Any) {
        tap?()
    }
}
