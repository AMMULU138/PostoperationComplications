//
//  listOfPatients.swift
//  ortho
//
//  Created by SAIL L1 on 27/10/23.
//

import UIKit

class listOfPatients: UITableViewCell {

    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var diagonsis: UILabel!
    @IBOutlet weak var pimage: UIImageView!
    @IBOutlet weak var pid: UILabel!
    @IBOutlet weak var next1: UIButton!
var tap:(() ->())?
    override func awakeFromNib() {
        super.awakeFromNib()
}

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
}
    
    override func layoutSubviews() {
        super.layoutSubviews()
     let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        contentView.frame = contentView.bounds.inset(by: margin)
        contentView.layer.cornerRadius = 10
    }
@IBAction func nextBtnTap(_ sender: Any) {
        tap?()
    }
}
