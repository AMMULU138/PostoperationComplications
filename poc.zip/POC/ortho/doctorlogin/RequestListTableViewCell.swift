

import UIKit

class RequestListTableViewCell: UITableViewCell {

    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var diagonsis: UILabel!
    @IBOutlet weak var imagephot: UIImageView!
    
    @IBOutlet weak var reason: UITextView!
    @IBOutlet weak var slot: UILabel!
    @IBOutlet weak var acceptBtn: UIButton!
    
    var tapAccept:(() -> ())?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        acceptBtn.layer.cornerRadius = 10
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
 }
override func layoutSubviews() {
        super.layoutSubviews()
     let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        contentView.frame = contentView.bounds.inset(by: margin)
        contentView.layer.cornerRadius = 10
    }
 @IBAction func acceptBtnTap(_ sender: Any) {
        
        tapAccept?()
    }
}
