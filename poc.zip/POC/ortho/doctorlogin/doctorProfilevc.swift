import UIKit

class doctorProfilevc: UIViewController {

    @IBOutlet weak var backBtn: UIButton!
    @IBOutlet weak var driddisplayLBL: UILabel!
    @IBOutlet weak var drcontactnumLBL: UILabel!
    @IBOutlet weak var signoutBtn: UIButton!
    @IBOutlet weak var drnamedisplayLBL: UILabel!
    @IBOutlet weak var specificationdisplayLBL: UILabel!
    @IBOutlet weak var emaildisplayLBL: UILabel!

    var did: String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        LoadingIndicator.shared.showLoading(on: self.view)
        fetchDoctorProfile()
    }

    func fetchDoctorProfile() {
        let id = UserDefaults.standard.value(forKey: "did")
        let formData = [
            "Did": DataManager.shared.doctorID,
            
        ]

        APIHandler().postAPIValues(type: drProfile.self, apiUrl: ServiceAPI.drprofileUrl, method: "POST", formData: formData) { [self] result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {  LoadingIndicator.shared.hideLoading()
                    if data.status == true {
                        specificationdisplayLBL.text = data.data.first?.specalization
                        driddisplayLBL.text = data.data.first?.did
                        emaildisplayLBL.text = data.data.first?.mail
                        drcontactnumLBL.text = data.data.first?.gender
                    } else {
                        // Handle unsuccessful API call
                        // Display an error message or take appropriate action
                    }
                }
            case .failure(let error):
                print("Error: \(error)")
                DispatchQueue.main.async {
                    LoadingIndicator.shared.hideLoading()
                    if let nav = self.navigationController {
                        DataManager.shared.sendMessage(title: "Message", message: " Check Our Internet Connection", navigation: nav)
              
                      }
                    
                }
            }
        }
    }

    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }

    @IBAction func signout(_ sender: Any) {
        
        
        
        let alertController = UIAlertController(title: "Alert", message: "Do you want logout!", preferredStyle: .alert)
               
               // Create OK action
               let okAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
                   
                   if let navigationController = self.navigationController {
                       for viewController in navigationController.viewControllers {
                           if let desiredViewController = viewController as? ViewController {
                               navigationController.popToViewController(desiredViewController, animated: true)
                               break
                           }
                       }
                   }
                 
               }
               
               // Create Cancel action
               let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action:UIAlertAction!) in
                   self.dismiss(animated: false, completion: nil)
               }
               
               // Add actions to the alert controller
               alertController.addAction(okAction)
               alertController.addAction(cancelAction)
               
               // Present the alert controller
               self.present(alertController, animated: true, completion:nil)
        
        
    }
    
    
    
    
}
