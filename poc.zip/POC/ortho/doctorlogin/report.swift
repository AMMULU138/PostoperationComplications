//
//  report.swift
//  ortho
//
//  Created by SAIL L1 on 15/11/23.
//

import UIKit

class report: UIViewController {

    @IBOutlet weak var updatedmedfield: UITextView!
    @IBOutlet weak var addvicefield: UITextView!
    var patientId = String()
var date = String()
    override func viewDidLoad() {
  super.viewDidLoad()
}

 @IBAction func saveBtnTapped(_ sender: Any) {
        if updatedmedfield.text != "" &&
            addvicefield.text != ""
        {
        DispatchQueue.main.async { [self] in
            print("UserID from data pass", self.patientId)
            print("UserID from data pass", self.date)
guard   let updatedmed = self.updatedmedfield.text,
                  let advice = self.addvicefield.text
            else  {
                self.showAlert(title: "Error", message: "All fields are required")
                return
            }

            let formData = [
                "pid": patientId,
                "updatedmed": updatedmed,
                "addvice": advice,
                "date":date
               
            ]
            print("pid: \(patientId), updatedmed: \(updatedmed), advice: \(advice)")

            APIHandler().postAPIValues(type: addreports1.self, apiUrl: ServiceAPI.addreports , method: "POST", formData: formData) { [weak self] result in
                switch result {
                case .success(let data):
                    print(data)
                    if data.status == true {
                        DispatchQueue.main.async {
                            print("Success: \(data.message)")
                            self?.showAlert(title: "Success", message: data.message)
  
                        }
                    } else {
                        DispatchQueue.main.async {
                            print("Error: \(data.message)")
                            self?.showAlert(title: "Error", message: data.message)
                        }
                    }
                case .failure(let error):
                    print("API Failure: \(error)")
                    DispatchQueue.main.async {
                        self?.showAlert(title: "Error", message: "Failed to register patient. Please try again.")
                    }
                }
            }

            
       
        
    }
        }else {
        
    DispatchQueue.main.async {
           if let nav = self.navigationController {
     DataManager.shared.sendMessage(title: "Message", message: "Fill required fields!", navigation: nav)
                                                                 
        }
    }
    }
        
        
    }

    func showAlert(title: String, message: String) {
            let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)

            let cancelAction = UIAlertAction(title: "Yes", style: .cancel) { _ in
                if let navigationController = self.navigationController {
                    for viewController in navigationController.viewControllers {
                        if let desiredViewController = viewController as? followUpListvc {
                            navigationController.popToViewController(desiredViewController, animated: true)
                            break
                        }
                    }
                }

            }

            alertController.addAction(cancelAction)

            if let viewController = UIApplication.shared.keyWindow?.rootViewController {
                viewController.present(alertController, animated: true, completion: nil)
            }
        }

        
    @IBAction func viewmed(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "Viewmedications") as! Viewmedications
        vc.patientId = self.patientId
        vc.date = self.date
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func backbutn(_ sender: Any) { self.navigationController?.popViewController(animated: false)
    }
    
}

