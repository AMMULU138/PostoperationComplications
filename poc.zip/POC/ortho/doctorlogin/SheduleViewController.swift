//
//  SheduleViewController.swift
//  ortho
//
//  Created by SAIL L1 on 22/11/23.
//

import UIKit

class SheduleViewController: UIViewController {
 
    @IBOutlet weak var sheduleTable: UITableView!
    
    @IBOutlet weak var subView: UIView!
    
    
    var sheduleDayData:shedule?
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
        LoadingIndicator.shared.showLoading(on: self.view)
        sheduleTable.delegate = self
        sheduleTable.dataSource = self
        subView.layer.borderWidth = 1.0
        let nib = UINib(nibName: "SheduleCells", bundle: nil)
        sheduleTable.register(nib, forCellReuseIdentifier: "cell")
        
        daySheduleData()
        
        
    }
func daySheduleData() {

        let apiURL = ServiceAPI.daysSheduleUrl
            let userIds = UserDefaults.standard.string(forKey: "DoctorId")

                let formData = [
                    "Did": "\(userIds ?? "")"
 ]
 APIHandler().postAPIValues(type: shedule.self, apiUrl: apiURL , method: "POST", formData: formData) {
                    [weak self] result in
                    switch result {
                    case .success(let shedule):
                        print(shedule)
                        DispatchQueue.main.async {
                            LoadingIndicator.shared.hideLoading()
                            self?.sheduleDayData = shedule
                            self?.sheduleTable.reloadData()
                        }
                    case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                            LoadingIndicator.shared.hideLoading()
                        self?.showAlertMessage(title: "Error", message: "Failed to fetch details")
                        }
                    }
                }
 }
    }
extension SheduleViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sheduleDayData?.appointments.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! SheduleCells
        let data = sheduleDayData?.appointments[indexPath.row]
        cell.pid.text = data?.pid
        cell.slotLabel.text =  data?.slot
        cell.date.text = data?.date
        cell.day.text = data?.day
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120.0
    }
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }

}
