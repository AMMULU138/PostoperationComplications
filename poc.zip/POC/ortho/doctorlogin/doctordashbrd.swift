//
//  doctordashbrd.swift
//  ortho
//
//  Created by SAIL L1 on 06/10/23.
//

import UIKit

class doctordashbrd: UIViewController {

    @IBOutlet var PATIENTSLIST: UIView!
    @IBOutlet weak var APPOINTMENTS: UIButton!
    
    @IBOutlet weak var dashBoardbtn: UIButton!
    
    
    
    @IBOutlet var FOLLOWUP: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()

        PATIENTSLIST.layer.cornerRadius = 15
        APPOINTMENTS.layer.cornerRadius = 15
        FOLLOWUP.layer.cornerRadius = 15
  
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = false
    }
    

    @IBAction func next3(_ sender: Any)
    {let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "patientList") as! patientList
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func appointmentreq(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "Appointments") as! Appointments
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func FOLLOW(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "followUpListvc") as! followUpListvc
            
            self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    
    @IBAction func dashBoardTap(_ sender: Any) {
        
        
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "doctorProfilevc") as! doctorProfilevc
            
            self.navigationController?.pushViewController(vc, animated: true)

    }
    

}
