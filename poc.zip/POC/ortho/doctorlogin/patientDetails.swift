//
//  patientDetails.swift
//  ortho
//
//  Created by SAIL L1 on 27/10/23.
//

import UIKit

class patientDetails: UIViewController {

    @IBOutlet weak var next2: UIButton!
    
    @IBOutlet weak var pIdField: UITextField!
    @IBOutlet weak var pnameField: UITextField!
    @IBOutlet weak var pgenderField: UITextField!
    
//    @IBOutlet weak var PDfield: UILabel!
    @IBOutlet weak var pConsField: UITextField!
    
    @IBOutlet weak var pAdressField: UITextField!
    
    @IBOutlet weak var pdADDField: UITextField!
    
    @IBOutlet weak var profileImage: UIImageView!
    
    var patientId = String()
    var viewPpList:ViewPpDetail?
    

    override func viewDidLoad() {
        super.viewDidLoad()
        LoadingIndicator.shared.showLoading(on: self.view)
        next2.layer.cornerRadius = 10
        profileImage.clipsToBounds = true
        profileImage.layer.cornerRadius = 50
        getViewPpAPI()
    }

    func getViewPpAPI() {
        let apiURL = ServiceAPI.viewPp
        let parameters: [String: String] = [
             "pid": patientId,]
        APIHandler().postAPIValues(type: ViewPpDetail.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    LoadingIndicator.shared.hideLoading()
                self.viewPpList = data
                self.pIdField.text = "\(self.viewPpList?.viewpatientpersonaldetails.first?.pid ?? "0")"
                    self.pnameField.text = self.viewPpList?.viewpatientpersonaldetails.first?.pname
                    self.pgenderField.text = self.viewPpList?.viewpatientpersonaldetails.first?.pgender

                    self.pdADDField.text = self.viewPpList?.viewpatientpersonaldetails.first?.pmail
                    self.pAdressField.text = self.viewPpList?.viewpatientpersonaldetails.first?.paddress
                    self.pConsField.text = self.viewPpList?.viewpatientpersonaldetails.first?.pconsultant
                    self.loadImage(url: self.viewPpList?.viewpatientpersonaldetails.first?.ppimage ?? "", imageView: self.profileImage)
                }
            case .failure(let error):
                DispatchQueue.main.async {
                LoadingIndicator.shared.hideLoading()
              if let nav = self.navigationController {
                  DataManager.shared.sendMessage(title: "Message", message: "Something went wrong!", navigation: nav)
        
                
                print(error)
            }
        }
    }
    
        }
    }
    
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    

    @IBAction func nextpage2(_ sender: Any) {
        do {let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "operationalDeatils") as! operationalDeatils
            vc.patientId = self.patientId
            self.navigationController?.pushViewController(vc, animated: true)
            
        
    }
    }
}
