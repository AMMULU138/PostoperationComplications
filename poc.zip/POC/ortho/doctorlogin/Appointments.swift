//
//  Appointments.swift
//  ortho
//
//  Created by SAIL L1 on 16/11/23.
//

import UIKit

class Appointments: UIViewController{
    
    @IBOutlet weak var listtable: UITableView!
    @IBOutlet weak var request: UISegmentedControl!

//   var doctorId = String()
//    var did : String = ""
    var appointStatus:AppoinmentStatus?
    
    var appointStatusAccept:Appoinmentapproved?
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        listtable.delegate = self
        listtable.dataSource = self
        
        LoadingIndicator.shared.showLoading(on: self.view)
        appointmentPending()
       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       
    }
    
    func appointmentPending() {
            let apiURL = ServiceAPI.appPrintBooked
            let userid = UserDefaults.standard.value(forKey: "DoctorId")
        
//        let userIds = UserDefaults.standard.string(forKey: "userId") ?? ""
        let parameters: [String: String] = [
             "Did": "\(userid ?? "")"]
        
                
            
            APIHandler().postAPIValues(type: AppoinmentStatus.self, apiUrl: apiURL, method: "POST", formData:parameters ) { [weak self] result in
                switch result {
                case .success(let data):
                    print(data)
                    DispatchQueue.main.async {
                        LoadingIndicator.shared.hideLoading()
                        self?.appointStatus = data
                       self?.listtable.reloadData()
                    }
                case .failure(let error):
                    print(error)
                    // Handle failure scenarios (e.g., network error)
                    DispatchQueue.main.async {
                        LoadingIndicator.shared.hideLoading()
                    self?.showAlert(title: "Alert", message: "No pedning Appointments")
                    }
                }
            }
        }
    
    
    func appointmentAcccept() {
            let apiURL = ServiceAPI.appPrintBookedAccept
        let userid = UserDefaults.standard.value(forKey: "DoctorId")
       
        let parameters: [String: String] = [
             "Did": "\(userid ?? "")"]
            APIHandler().postAPIValues(type: Appoinmentapproved.self, apiUrl: apiURL, method: "POST", formData: parameters) { [weak self] result in
                switch result {
                case .success(let data):
                    print(data)
                    DispatchQueue.main.async {
                        LoadingIndicator.shared.hideLoading()
                        self?.appointStatusAccept = data
                      self?.listtable.reloadData()
                    }
                case .failure(let error):
                    print(error)
                    // Handle failure scenarios (e.g., network error)
                    DispatchQueue.main.async {
                        LoadingIndicator.shared.hideLoading()
                self?.showAlert(title: "Alert", message: "No pedning Appointments")
                    }
                }
            }
        }
    
    @IBAction func backTap(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
    
    func sendToAccept(id:String) {
            let apiURL = ServiceAPI.toChangeStatus
        
        let formData = ["pid":id]
            
            APIHandler().postAPIValues(type: SendToAccept.self, apiUrl: apiURL, method: "POST", formData: formData) { [weak self] result in
                switch result {
                case .success(let data):
                    print(data)
                    DispatchQueue.main.async {
                        self?.showAlert(title: "Message", message: data.message)
                        self?.listtable.reloadData()
                    }
                case .failure(let error):
                    print(error)
                    // Handle failure scenarios (e.g., network error)
                    DispatchQueue.main.async {
                self?.showAlert(title: "Error", message: "Failed to register patient. Please try again.")
                    }
                }
            }
        }
    
    
    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    
    
    
    @IBAction func seg(_ sender: Any) {
        if request.selectedSegmentIndex == 0 {
            appointmentPending()
            self.listtable.reloadData()
           
          
           
        }
        else if request.selectedSegmentIndex == 1 {
            LoadingIndicator.shared.showLoading(on: self.view)
            appointmentAcccept()
            self.listtable.reloadData()
           
            
        }
    }
    
    @IBAction func confrimAccpet(_ sender: Any) {
        let alertController = UIAlertController(title: "are you sure to accpet", message: " ", preferredStyle: .alert)
           
           let ok = UIAlertAction(title: "Yes", style: .cancel) { _ in
             
               let storyBoard = UIStoryboard(name: "Main", bundle: nil)
               let vc = storyBoard.instantiateViewController(withIdentifier: "TabBarController") as! TabBarController
             self.navigationController?.pushViewController(vc, animated: true)
           }
           
           let cancel = UIAlertAction(title: "No", style: .default) { _ in
               self.dismiss(animated: false, completion: nil)
             
            
              
           }
           
           alertController.addAction(ok)
           alertController.addAction(cancel)
       
           if let viewController = UIApplication.shared.keyWindow?.rootViewController {
               viewController.present(alertController, animated: true, completion: nil)
           }
       }

   
}
        
extension  Appointments: UITableViewDelegate,UITableViewDataSource {
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch request.selectedSegmentIndex{
        case 0:
            return self.appointStatus?.data.count ?? 0
        case 1:
            return self.appointStatusAccept?.data.count ?? 0
        default:
            break
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "RequestListTableViewCell", for: indexPath) as! RequestListTableViewCell
        switch request.selectedSegmentIndex{
        case 0 :
            cell.name.text = appointStatus?.data[indexPath.row].pid ?? ""
            cell.diagonsis.text = appointStatus?.data[indexPath.row].date ?? ""
            cell.reason.text = appointStatus?.data[indexPath.row].reason ?? ""
            cell.slot.text = appointStatus?.data[indexPath.row].slot ?? ""
            cell.acceptBtn.isHidden = false
            cell.tapAccept = {
                self.sendToAccept(id: self.appointStatus?.data[indexPath.row].pid ?? "")
            }
        case 1 :
            cell.name.text = appointStatusAccept?.data[indexPath.row].pid ?? ""
            cell.diagonsis.text = appointStatusAccept?.data[indexPath.row].date ?? ""
            cell.reason.text = appointStatusAccept?.data[indexPath.row].reason ?? ""
            cell.slot.text = appointStatusAccept?.data[indexPath.row].slot ?? ""
            
            cell.acceptBtn.isHidden = true
        default:
            break
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        switch request.selectedSegmentIndex{
        case 0 :
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "patientDetails") as! patientDetails
            vc.patientId = appointStatus?.data[indexPath.row].pid ?? ""
            self.navigationController?.pushViewController(vc, animated: true)
        case 1 :
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "patientDetails") as! patientDetails
            vc.patientId = appointStatus?.data[indexPath.row].pid ?? ""
            self.navigationController?.pushViewController(vc, animated: true)
          print("")
        default:
            break
        }
      
       
    }
}
    
