//
//  DataManager.swift
//  ortho
//
//  Created by SAIL on 05/02/24.
//

import UIKit



class DataManager {
    
    
    static let shared = DataManager()
    
    
   var doctorID = String()
    
    var exercise = String()
    var exercise1 = String()
    var reason = String()
    var reason1 = String()
    
    func sendMessage(title:String,message:String,navigation:UINavigationController) {
           
          
           let alertController = UIAlertController(title: "Message", message: message, preferredStyle: .alert)
           let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
           alertController.addAction(cancelAction)
           navigation.present(alertController, animated: false, completion: nil)
       }
    
}


extension UIColor {
    static let appColor = UIColor(named: "64A997")
}



extension UIViewController {
 

 class LoadingIndicator {

     static let shared = LoadingIndicator()

     private let activityIndicator: UIActivityIndicatorView = {
         let indicator = UIActivityIndicatorView(style: .large)
         indicator.color = .lightGray
         indicator.hidesWhenStopped = true
         return indicator
     }()

     private init() {}

     func showLoading(on view: UIView) {
         DispatchQueue.main.async {
             self.activityIndicator.center = view.center
             view.addSubview(self.activityIndicator)
             self.activityIndicator.startAnimating()
         }
     }

     func hideLoading() {
         DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
        
             self.activityIndicator.stopAnimating()
             self.activityIndicator.removeFromSuperview()
         }
     }
 }

   



}
