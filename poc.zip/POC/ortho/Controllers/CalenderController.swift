//
//  CalenderController.swift
//  ortho
//
//  Created by SAIL L1 on 24/11/23.
//

import UIKit

class CalenderController: UIViewController {
    
    @IBOutlet weak var calenderView: UIView!
    
    
    
    let datePicker : UIDatePicker = UIDatePicker()

    override func viewDidLoad() {
        super.viewDidLoad()
        
     
        calenderView.layer.cornerRadius = 10
        calenderView.layer.borderWidth = 1.0
        
        
        showDatePicker()
    }
    
    func showDatePicker() {
           // Formate Date
           datePicker.datePickerMode = .date

           if #available(iOS 13.4, *) {
               datePicker.preferredDatePickerStyle = .inline
           } else {
               datePicker.preferredDatePickerStyle = .wheels
           }
           let toolbar = UIToolbar()
           toolbar.sizeToFit()

           // done button & cancel button
           let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donedatePicker(_:)))
         
           let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)

           let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.cancelDatePicker(_:)))
           
           toolbar.setItems([cancelButton, spaceButton, doneButton], animated: false)

         
           view.addSubview(datePicker)
           view.addSubview(toolbar)

           // Add constraints or frame as needed
           datePicker.translatesAutoresizingMaskIntoConstraints = false
           toolbar.translatesAutoresizingMaskIntoConstraints = false

           NSLayoutConstraint.activate([
               // Adjust the constraints as per your layout requirements
            datePicker.topAnchor.constraint(equalTo: calenderView.topAnchor),
            datePicker.leadingAnchor.constraint(equalTo: calenderView.leadingAnchor),
            datePicker.trailingAnchor.constraint(equalTo: calenderView.trailingAnchor),
            datePicker.bottomAnchor.constraint(equalTo: calenderView.bottomAnchor,constant: -10),

               toolbar.topAnchor.constraint(equalTo: datePicker.bottomAnchor),
               toolbar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
               toolbar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
           ])
       }

       @objc func cancelDatePicker(_ sender: UIButton) {
         //  datePicker.removeFromSuperview()
       }

       @objc func donedatePicker(_ sender: UIButton) {
           let formatter = DateFormatter()
           formatter.dateFormat = "yyyy-MM-dd"

           // Do something with the selected date, for example, print it
           print(formatter.string(from: datePicker.date))

          
       }


}
