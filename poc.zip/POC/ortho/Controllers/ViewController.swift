//
//  ViewController.swift
//  ortho
//
//  Created by SAIL L1 on 24/10/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var doctor: UIButton!
    
    @IBOutlet weak var patient: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
   
        doctor.layer.cornerRadius = 20
        patient.layer.cornerRadius = 20
       
        
        
    }
    
    @IBAction func doctorlogin(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "doctorLogin") as! doctorLogin
        
                self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func patientlogin(_ sender: Any) {let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "patientLogin") as! patientLogin

        self.navigationController?.pushViewController(vc, animated: true)
    }

}
