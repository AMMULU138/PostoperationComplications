//
//  SheduleViewController.swift
//  ortho
//
//  Created by SAIL L1 on 25/11/23.
//

import UIKit

class SheduleViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

     }
    

   

}
