//
//  PatientTabController.swift
//  ortho
//
//  Created by SAIL L1 on 22/11/23.
//

import UIKit

class PatientTabController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
}
