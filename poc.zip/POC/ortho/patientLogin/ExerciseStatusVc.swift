//
//  ExerciseStatusVc.swift
//  ortho
//
//  Created by SAIL on 23/04/24.
//

import UIKit

class ExerciseStatusVc: UIViewController {

    @IBOutlet weak var firstViewHeight: NSLayoutConstraint!
    
    
    @IBOutlet weak var reason1Lbl: UILabel!
    
    
    
    @IBOutlet weak var secondViewHeight: NSLayoutConstraint!
    
    
    @IBOutlet weak var threeViewHeight: NSLayoutConstraint!
    
    
    
    @IBOutlet weak var reasonOneYesLbl: UILabel!
    
    @IBOutlet weak var reasonOneNoLbl: UILabel!
    
    @IBOutlet weak var reasonTwoYesLbl: UILabel!
    
    @IBOutlet weak var reasonTwoNoLbl: UILabel!
    
    
    
    @IBOutlet weak var reasonThreeYesLbl: UILabel!
    
    
    
    @IBOutlet weak var reasonthreNobl: UILabel!
    
    @IBOutlet weak var reason3Lbl: UILabel!
    
    @IBOutlet weak var reason2lbl: UILabel!
    var patientId = String()
    var date = String()
    var displayStatus:DisplayStatus?
    
    override func viewDidLoad() {
        super.viewDidLoad()
 
        submitToBackend()

      
    }
    
    
    func submitToBackend()
    {

            let pid = UserDefaults.standard.value(forKey: "userId")
                    let formData = [
                        "pid":patientId,
                        "date":date,
                    ]

                    APIHandler().postAPIValues(type: DisplayStatus.self, apiUrl: ServiceAPI.statusDisplay , method: "POST", formData: formData) {
                        [weak self] result in
                        switch result {
                        case .success(let data):
                            print(data)
                            DispatchQueue.main.async {
                            if data.status == true {
                                if data.data.reason1 == "yes" {
                                    self?.firstViewHeight.constant = 60
                                    self?.reasonOneYesLbl.backgroundColor = UIColor(named: "appColor")
                                    self?.reasonOneNoLbl.backgroundColor = .lightGray
                                    self?.reason1Lbl.isHidden = true
                                }else {
                                    self?.firstViewHeight.constant = 120
                                    self?.reason1Lbl.text = data.data.exercise1
                                    self?.reason1Lbl.isHidden = false
                                    self?.reasonOneYesLbl.backgroundColor = .lightGray
                                    self?.reasonOneNoLbl.backgroundColor = .red
                                }
                                
                                if data.data.reason2 == "yes" {
                                    self?.secondViewHeight.constant = 60
                                    self?.reason2lbl.isHidden = true
                                    self?.reasonTwoYesLbl.backgroundColor = UIColor(named: "appColor")
                                    self?.reasonTwoNoLbl.backgroundColor = .lightGray
                                }else {
                                    self?.secondViewHeight.constant = 120
                                    self?.reason2lbl.text = data.data.exercise2
                                    self?.reason2lbl.isHidden = false
                                    self?.reasonTwoYesLbl.backgroundColor = .lightGray
                                    self?.reasonTwoNoLbl.backgroundColor = .red
                                }
                                
                                if data.data.reason3 == "yes" {
                                    self?.threeViewHeight.constant = 60
                                    self?.reason3Lbl.isHidden = true
                                    self?.reasonThreeYesLbl.backgroundColor = UIColor(named: "appColor")
                                    self?.reasonthreNobl.backgroundColor = .lightGray
                                }else {
                                    self?.threeViewHeight.constant = 120
                                    self?.reason3Lbl.text = data.data.exercise3
                                    self?.reason3Lbl.isHidden = false
                                    self?.reasonThreeYesLbl.backgroundColor = .lightGray
                                    self?.reasonthreNobl.backgroundColor = .red
                                }

                            }else {
                                if let navi = self?.navigationController {
                                DataManager.shared.sendMessage(title: "Message", message: data.message, navigation: navi)
                                }
                            }

                            }
                        case .failure(let error):
                            print(error)
                            DispatchQueue.main.async {
                                if let navi = self?.navigationController {
                                DataManager.shared.sendMessage(title: "Alert", message: "Error occured", navigation: navi)
                              }
                        }
                    }
        }
    }


    @IBAction func NEXTTAP(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "report") as! report
            vc.patientId = self.patientId
            vc.date = self.date
            self.navigationController?.pushViewController(vc, animated: true)
            
    
        
    }
  
    @IBAction func backtap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
}

