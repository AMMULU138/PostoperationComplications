//
//  patientDashbrd.swift
//  ortho
//
//  Created by SAIL L1 on 15/11/23.
//

import UIKit

class patientDashbrd: UIViewController {
    @IBOutlet weak var questinare: UIButton!
    
    @IBOutlet weak var appointement: UIButton!
    @IBOutlet weak var videos: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        questinare.layer.cornerRadius = 15
        appointement.layer.cornerRadius = 15
        videos.layer.cornerRadius = 15
    }
    

    @IBAction func questions(_ sender: Any) {let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "painScaleVC") as! painScaleVC
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func appointmentREQ(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "trackappointment") as! trackappointment
            self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
    @IBAction func videos(_ sender: Any) {let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "Videos") as! Videos
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func menubutton(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "patientProfilevc") as! patientProfilevc
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
    


