//
//  patientLogin.swift
//  ortho
//
//  Created by SAIL L1 on 05/10/23.
//

import UIKit

class patientLogin: UIViewController {
    
    @IBOutlet weak var patientid: UITextField!
    @IBOutlet weak var ppassword: UITextField!
    
    @IBOutlet weak var mainView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        LoadingIndicator.shared.showLoading(on: self.view)
    }
    func patinetLogin() {
                let formData = [
                    "pid": patientid.text ?? "",
                    "ppassword": ppassword.text ?? ""
                ]

                APIHandler().postAPIValues(type: SendToAccept.self, apiUrl: ServiceAPI.patientLogin , method: "POST", formData: formData) {
                    [weak self] result in
                    switch result {
                    case .success(let data):
                        print(data)
                        if data.status == "success" {
                            DispatchQueue.main.async {
                                LoadingIndicator.shared.hideLoading()
                                UserDefaults.standard.set(self?.patientid.text ?? "", forKey: "userId")
                                let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                                    let vc = storyBoard.instantiateViewController(withIdentifier: "PatientTabController") as! PatientTabController
                                vc.selectedIndex = 1
                                self?.navigationController?.pushViewController(vc, animated: true)
                            }
                        }else {
                            DispatchQueue.main.async {
                                LoadingIndicator.shared.hideLoading()
                            self?.showAlertMessage(title: "Alert", message: "Something went wrong!")
                            }
                        }
                    case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                            LoadingIndicator.shared.hideLoading()
                        self?.showAlertMessage(title: "Alert", message: "Invalid id or password!")
                        }
                    }
                }


        }

    @IBAction func NEXT5(_ sender: Any) {
        
        if patientid.text ?? "" != "" &&  ppassword.text ?? "" != ""{
            patinetLogin()
        }else {
            DispatchQueue.main.async {
                self.showAlertMessage(title: "Error", message: "Fill all the filed")
            }
        }
        
    }
   
    @IBAction func backTap(_ sender: Any) {
      
            self.navigationController?.popViewController(animated: false)
    }
}
