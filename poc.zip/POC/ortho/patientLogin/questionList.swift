//
//  questionList.swift
//  ortho
//
//  Created by SAIL L1 on 15/11/23.
//

import UIKit

class questionList: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
   

    @IBOutlet weak var table2: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LoadingIndicator.shared.showLoading(on: self.view)
        table2.dataSource = self
        table2.delegate = self
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 15
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"cell" , for: indexPath) as! questionnarieList
        cell.questionno.text = "Question:\(indexPath.row + 1)"
        if indexPath.row < 1 {
            cell.viewButton.image = UIImage(named: "unlock")
        }else {
          cell.viewButton.image = UIImage(named: "lock")
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "painScaleVC") as! painScaleVC
        self.navigationController?.pushViewController(vc, animated: true)
        }
        
    }
    @IBAction func backbtn(_ sender: Any) {navigationController?.popViewController(animated: true)
    }
}
