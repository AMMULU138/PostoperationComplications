import UIKit

class followUpAdvicevc: UIViewController {
    
    @IBOutlet weak var subView: UIView!
    @IBOutlet weak var ADVICETEXTFIELD: UITextView!
    @IBOutlet weak var upadatedmedtextfiled: UILabel!
    let datePicker: UIDatePicker = UIDatePicker()
    var followUpdetails: FollowUp?
   
    override func viewDidLoad() {
        super.viewDidLoad()
//
//        LoadingIndicator.shared.showLoading(on: self.view)
      
        getDate()
    }

    func showDatePicker(date:String) {
        datePicker.datePickerMode = .date
        
        // Set minimum and maximum dates
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        if let minDate = dateFormatter.date(from: date) {
            datePicker.minimumDate = minDate
        }
//        if let maxDate = dateFormatter.date(from: "2024-05-31") {
//            datePicker.maximumDate = maxDate
//        }
        
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .inline
        } else {
            datePicker.preferredDatePickerStyle = .wheels
        }
        
        subView.addSubview(datePicker)
        datePicker.translatesAutoresizingMaskIntoConstraints = true
        datePicker.addTarget(self, action: #selector(datePickerValueChanged(_:)), for: .valueChanged)
    }


    @objc func datePickerValueChanged(_ datePicker: UIDatePicker) {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        dayfolowUpData(date: formatter.string(from: datePicker.date))
        print(formatter.string(from: datePicker.date))
    }

    func dayfolowUpData(date: String) {
        let patientIds = UserDefaults.standard.string(forKey: "userId") ?? ""
        let formData = [
            "pid": "\(patientIds)",
            "date": date,
        ]
        
        APIHandler().postAPIValues(type: FollowUp.self, apiUrl: ServiceAPI.followUpUrl, method: "POST", formData: formData) { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    [weak self] in
                    LoadingIndicator.shared.hideLoading()
                    self?.followUpdetails = data
                    if let followUpDetails = self?.followUpdetails,
                       let firstData = followUpDetails.data.first {
                        self?.ADVICETEXTFIELD.text = firstData.addvice
                        self?.upadatedmedtextfiled.text = firstData.updatedmed
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    LoadingIndicator.shared.hideLoading()
                    self?.showAlertMessage(title: "Error", message: "no data avialabe")
                }
            }
        }
    }
    
    
    func getDate() {
        let patientIds = UserDefaults.standard.string(forKey: "userId") ?? ""
        let formData = [
            "pid": "\(patientIds)",
            
        ]
        
        APIHandler().postAPIValues(type: dtofproc.self, apiUrl: ServiceAPI.dtofprocurl, method: "POST", formData: formData) { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    [weak self] in
                    LoadingIndicator.shared.hideLoading()
                 
                    self?.showDatePicker(date: data.data.first?.dtofproc ?? "")
               
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    LoadingIndicator.shared.hideLoading()
                    self?.showAlertMessage(title: "Error", message: "no data avialabe")
                }
            }
        }
    }

    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
}

// Your other structs and models remain unchanged
