//
//  questionsViewController.swift
//  ortho
//
//  Created by SAIL L1 on 16/11/23.
//

import UIKit

class questionsViewController: UIViewController {

    @IBOutlet weak var submit: UIButton!

    @IBOutlet weak var optionC: UIButton!
    @IBOutlet weak var optionB: UIButton!
    @IBOutlet weak var optionA: UIButton!
    @IBOutlet weak var optionD: UIButton!
    
    
    @IBOutlet weak var dBtn: UIButton!
    @IBOutlet weak var aBtn: UIButton!
    
    @IBOutlet weak var bBtn: UIButton!
    
    @IBOutlet weak var cBtn: UIButton!
    
    @IBOutlet weak var questionNumLbl: UILabel!
    @IBOutlet weak var question: UILabel!
    
    
    
    @IBOutlet weak var optionABtn: UIButton!
    
    
    
    
    
    var allQuestionsArray:[displayquestions]?
    
    var index = 1
    var questionNum = 2
    var opionIndex = 0
   
    
    var selectedScore = String()
    var answer2 = String()
    var answer3 = String()
    var answer4 = String()
    var answer5 = String()
    var answer6 = String()
    var answer7 = String()
    var answer8 = String()
    var answer9 = String()
    var answer10 = String()
    var answer11 = String()
    var answer12 = String()
    var answer13 = String()
    var answer14 = String()
    var answer15 = String()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        questionNumLbl.layer.masksToBounds = true
        questionNumLbl.layer.cornerRadius = 25
        questionNumLbl.text = "2"
        LoadingIndicator.shared.showLoading(on: self.view)
        displayquestions()
        
    }
    func displayquestions() {
        
        let id = UserDefaults.standard.value(forKey: "userId")
                let formData = [
                    "pid": "\(id ?? "")",
                ]

                APIHandler().postAPIValues(type: QuestionDisplay.self, apiUrl: ServiceAPI.questiondisplay , method: "POST", formData: formData) {
                    [weak self] result in
                    switch result {
                    case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            LoadingIndicator.shared.hideLoading()
                            self?.allQuestionsArray = data.data
                            self?.question.text = self?.allQuestionsArray?.first?.questionText
                            self?.optionA.setTitle(self?.allQuestionsArray?.first?.optionA, for: .normal)
                            self?.optionB.setTitle(self?.allQuestionsArray?.first?.optionB, for: .normal)
                            self?.optionC.setTitle(self?.allQuestionsArray?.first?.optionC, for: .normal)
                            self?.optionD.setTitle(self?.allQuestionsArray?.first?.optionD, for: .normal)
                         
                        }
                    case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                            LoadingIndicator.shared.hideLoading()
                        self?.showAlertMessage(title: "Alert", message: "data unavailable.")
                        }
                    }
                }

    }
        
    
    @IBAction func submit(_ sender: Any){
        
        
        if  self.allQuestionsArray?.count ?? 0 > index {
            self.question.text = self.allQuestionsArray?[index].questionText
            if self.allQuestionsArray?[index].optionA == "" {
                self.optionA.isHidden = true
                self.aBtn.isHidden = true
            }else {
                self.optionA.isHidden = false
                self.aBtn.isHidden = false
            }
            if self.allQuestionsArray?[index].optionB == "" {
                self.optionB.isHidden = true
                self.bBtn.isHidden = true
            }else {
                self.optionB.isHidden = false
                self.bBtn.isHidden = false
            }
            if self.allQuestionsArray?[index].optionC == "" {
                self.optionC.isHidden = true
                self.cBtn.isHidden = true
            }else {
                self.optionC.isHidden = false
                self.cBtn.isHidden = false
            }
            if self.allQuestionsArray?[index].optionD == "" {
                self.optionD.isHidden = true
                self.dBtn.isHidden = true
            }else {
                self.optionD.isHidden = false
                self.dBtn.isHidden = false
            }
            self.optionA.setTitle(self.allQuestionsArray?[index].optionA, for: .normal)
            self.optionB.setTitle(self.allQuestionsArray?[index].optionB, for: .normal)
            self.optionC.setTitle(self.allQuestionsArray?[index].optionC, for: .normal)
            self.optionD.setTitle(self.allQuestionsArray?[index].optionD, for: .normal)
             
           
            index = index + 1
            questionNum = index + 1
            questionNumLbl.text = "\(questionNum)"
            opionIndex = opionIndex + 1
            if index != 15 {
                submit.setTitle("Next", for: .normal)
                buttonHightlight(tag:0)
            }else {
                submit.setTitle("Submit", for: .normal)
            }
            
       }
        else {
            if selectedScore != "" && answer2 != "" && answer3 != "" && answer4 != "" && answer5 != "" && answer6 != "" && answer7 != "" && answer8 != "" && answer9 != "" && answer10 != "" && answer11 != "" && answer12 != "" && answer13 != "" && answer14 != "" && answer15 != "" {
                
                
                let alertController = UIAlertController(title: "Message", message: "Are you want to submit answers ", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default) { _ in
                    
                    self.saveAnswers()
                 
                }
                alertController.addAction(okAction)

                // Add Cancel button
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { _ in
                    // Handle Cancel action
                    print("Cancel tapped")
                }
                alertController.addAction(cancelAction)

                // Present the alert controller
                self.present(alertController, animated: true, completion: nil)

                
                
               
            }
        }
        
}
    
    
    @IBAction func optAtapped(_ sender: Any) {
        buttonHightlight(tag:1)
        
        switch opionIndex {
        case 0:
            answer2 = String(5)
            print(self.allQuestionsArray?[opionIndex].optionA ?? "")
//            answer1 = self.allQuestionsArray?[opionIndex].optionA ?? ""
//            print(self.allQuestionsArray?[opionIndex].optionA ?? "")
//            answer1 = "5"
//            print(answer1 )
        case 1:
            answer3 = String(5)
//            answer2 = self.allQuestionsArray?[opionIndex].optionA ?? ""
            print(self.allQuestionsArray?[opionIndex].optionA ?? "")
        case 2:
            answer4 = String(5)
//            answer3 = self.allQuestionsArray?[opionIndex].optionA ?? ""
            print(self.allQuestionsArray?[opionIndex].optionA ?? "")
        case 3:
            answer5 = String(5)
//            answer4 = self.allQuestionsArray?[opionIndex].optionA ?? ""
            print(self.allQuestionsArray?[opionIndex].optionA ?? "")
        case 4:
            answer6 = String(5)
//            answer5 = self.allQuestionsArray?[opionIndex].optionA ?? ""
            print(self.allQuestionsArray?[opionIndex].optionA ?? "")
        case 5:
            answer7 = String(5)
//            answer6 = self.allQuestionsArray?[opionIndex].optionA ?? ""
            print(self.allQuestionsArray?[opionIndex].optionA ?? "")
        case 6:
            answer8 = String(5)
//            answer7 = self.allQuestionsArray?[opionIndex].optionA ?? ""
            print(self.allQuestionsArray?[opionIndex].optionA ?? "")
        case 7:
            answer9 = String(5)
//            answer8 = self.allQuestionsArray?[opionIndex].optionA ?? ""
            print(self.allQuestionsArray?[opionIndex].optionA ?? "")
        case 8:
            answer10 = String(5)
//            answer9 = self.allQuestionsArray?[opionIndex].optionA ?? ""
            print(self.allQuestionsArray?[opionIndex].optionA ?? "")
        case 9:
            answer11 = String(5)
//            answer10 = self.allQuestionsArray?[opionIndex].optionA ?? ""
            print(self.allQuestionsArray?[opionIndex].optionA ?? "")
        case 10:
            answer12 = String(5)
//            answer11 = self.allQuestionsArray?[opionIndex].optionA ?? ""
            print(self.allQuestionsArray?[opionIndex].optionA ?? "")
        case 11:
            answer13 = String(5)
//            answer12 = self.allQuestionsArray?[opionIndex].optionA ?? ""
            print(self.allQuestionsArray?[opionIndex].optionA ?? "")
        case 12:
            answer14 = String(5)
//            answer13 = self.allQuestionsArray?[opionIndex].optionA ?? ""
            print(self.allQuestionsArray?[opionIndex].optionA ?? "")
        case 13:
            answer15 = String(5)
//            answer14 = self.allQuestionsArray?[opionIndex].optionA ?? ""
            print(self.allQuestionsArray?[opionIndex].optionA ?? "")
//        case 14:
//            answer15 = String(5)
////            answer14 = self.allQuestionsArray?[opionIndex].optionA ?? ""
//            print(self.allQuestionsArray?[opionIndex].optionA ?? "")
    
        default:
            print("")
        }
    }
    
    
    
    @IBAction func optBtapped(_ sender: Any) {
        buttonHightlight(tag:2)
        switch opionIndex {
        case 0:
            answer2 = String(10)
//            answer1 = self.allQuestionsArray?[opionIndex].optionB ?? ""
            print(self.allQuestionsArray?[opionIndex].optionB ?? "")
        case 1:
            answer3 = String(10)
//            answer2 = self.allQuestionsArray?[opionIndex].optionB ?? ""
            print(self.allQuestionsArray?[opionIndex].optionB ?? "")
        case 2:
//            answer3 = self.allQuestionsArray?[opionIndex].optionB ?? ""
            answer4 = String(10)
            print(self.allQuestionsArray?[opionIndex].optionB ?? "")
        case 3:
//            answer4 = self.allQuestionsArray?[opionIndex].optionB ?? ""
            answer5 = String(10)
            print(self.allQuestionsArray?[opionIndex].optionB ?? "")
        case 4:
//            answer5 = self.allQuestionsArray?[opionIndex].optionB ?? ""
            answer6 = String(10)
            print(self.allQuestionsArray?[opionIndex].optionB ?? "")
        case 5:
//            answer6 = self.allQuestionsArray?[opionIndex].optionB ?? ""
            answer7 = String(10)
            print(self.allQuestionsArray?[opionIndex].optionB ?? "")
        case 6:
            answer8 = String(20)
//            answer7 = self.allQuestionsArray?[opionIndex].optionB ?? ""
            print(self.allQuestionsArray?[opionIndex].optionB ?? "")
        case 7:
            answer9 = String(20)
//            answer8 = self.allQuestionsArray?[opionIndex].optionB ?? ""
            print(self.allQuestionsArray?[opionIndex].optionB ?? "")
        case 8:
//            answer9 = self.allQuestionsArray?[opionIndex].optionB ?? ""
            answer10 = String(10)
            print(self.allQuestionsArray?[opionIndex].optionB ?? "")
        case 9:
//            answer10 = self.allQuestionsArray?[opionIndex].optionB ?? ""
            answer11 = String(10)
            print(self.allQuestionsArray?[opionIndex].optionB ?? "")
        case 10:
//            answer11 = self.allQuestionsArray?[opionIndex].optionB ?? ""
            answer12 = String(10)
            print(self.allQuestionsArray?[opionIndex].optionB ?? "")
        case 11:
            answer13 = String(20)
//            answer12 = self.allQuestionsArray?[opionIndex].optionB ?? ""
            print(self.allQuestionsArray?[opionIndex].optionB ?? "")
        case 12:
            answer14 = String(20)
//            answer13 = self.allQuestionsArray?[opionIndex].optionB ?? ""
            print(self.allQuestionsArray?[opionIndex].optionB ?? "")
        case 13:
//            answer14 = self.allQuestionsArray?[opionIndex].optionB ?? ""
            answer15 = String(10)
            print(self.allQuestionsArray?[opionIndex].optionB ?? "")
    
        default:
            print("")
        }
       
    
    }
    

    @IBAction func optCtapped(_ sender: Any) {
        buttonHightlight(tag:3)
        switch opionIndex {
        case 0:
//            answer1 = self.allQuestionsArray?[opionIndex].optionC ?? ""
            answer2 = String(15)
            print(self.allQuestionsArray?[opionIndex].optionC ?? "")
        case 1:
//            answer2 = self.allQuestionsArray?[opionIndex].optionC ?? ""
            answer3 = String(15)
            print(self.allQuestionsArray?[opionIndex].optionC ?? "")
        case 2:
//            answer3 = self.allQuestionsArray?[opionIndex].optionC ?? ""
            answer4 = String(15)
            print(self.allQuestionsArray?[opionIndex].optionC ?? "")
        case 3:
//            answer4 = self.allQuestionsArray?[opionIndex].optionC ?? ""
            answer5 = String(15)
            print(self.allQuestionsArray?[opionIndex].optionC ?? "")
        case 4:
//            answer5 = self.allQuestionsArray?[opionIndex].optionC ?? ""
            answer6 = String(15)
            print(self.allQuestionsArray?[opionIndex].optionC ?? "")
        case 5:
//            answer6 = self.allQuestionsArray?[opionIndex].optionC ?? ""
            answer7 = String(15)
            print(self.allQuestionsArray?[opionIndex].optionC ?? "")
        case 6:
//            answer7 = self.allQuestionsArray?[opionIndex].optionC ?? ""
            answer8 = String(15)
            print(self.allQuestionsArray?[opionIndex].optionC ?? "")
        case 7:
//            answer8 = self.allQuestionsArray?[opionIndex].optionC ?? ""
            answer9 = String(15)
            print(self.allQuestionsArray?[opionIndex].optionC ?? "")
        case 8:
//            answer9 = self.allQuestionsArray?[opionIndex].optionC ?? ""
            answer10 = String(15)
            print(self.allQuestionsArray?[opionIndex].optionC ?? "")
        case 9:
//            answer10 = self.allQuestionsArray?[opionIndex].optionC ?? ""
            answer11 = String(15)
            print(self.allQuestionsArray?[opionIndex].optionC ?? "")
        case 10:
//            answer11 = self.allQuestionsArray?[opionIndex].optionC ?? ""
            answer12 = String(15)
            print(self.allQuestionsArray?[opionIndex].optionC ?? "")
        case 11:
//            answer12 = self.allQuestionsArray?[opionIndex].optionC ?? ""
            answer13 = String(15)
            print(self.allQuestionsArray?[opionIndex].optionC ?? "")
        case 12:
//            answer13 = self.allQuestionsArray?[opionIndex].optionC ?? ""
            answer14 = String(15)
            print(self.allQuestionsArray?[opionIndex].optionC ?? "")
        case 13:
//            answer14 = self.allQuestionsArray?[opionIndex].optionC ?? ""
            answer15 = String(15)
            print(self.allQuestionsArray?[opionIndex].optionC ?? "")
    
        default:
            print("")
        }
       
    }
    
    @IBAction func optDtapped(_ sender: Any) {
        buttonHightlight(tag:4)
        switch opionIndex {
        case 0:
            answer2 = String(20)
//            answer1 = self.allQuestionsArray?[opionIndex].optionD ?? ""
            print(self.allQuestionsArray?[opionIndex].optionD ?? "")
        case 1:
//            answer2 = self.allQuestionsArray?[opionIndex].optionD ?? ""
            answer3 = String(20)
            print(self.allQuestionsArray?[opionIndex].optionD ?? "")
        case 2:
//            answer3 = self.allQuestionsArray?[opionIndex].optionD ?? ""
            answer4 = String(20)
            print(self.allQuestionsArray?[opionIndex].optionD ?? "")
        case 3:
//            answer4 = self.allQuestionsArray?[opionIndex].optionD ?? ""
            answer5 = String(20)
            print(self.allQuestionsArray?[opionIndex].optionD ?? "")
        case 4:
//            answer5 = self.allQuestionsArray?[opionIndex].optionD ?? ""
            answer6 = String(20)
            print(self.allQuestionsArray?[opionIndex].optionD ?? "")
        case 5:
//            answer6 = self.allQuestionsArray?[opionIndex].optionD ?? ""
            answer7 = String(20)
            print(self.allQuestionsArray?[opionIndex].optionD ?? "")
        case 6:
//            answer7 = self.allQuestionsArray?[opionIndex].optionD ?? ""
            answer8 = String(20)
            print(self.allQuestionsArray?[opionIndex].optionD ?? "")
        case 7:
//            answer8 = self.allQuestionsArray?[opionIndex].optionD ?? ""
            answer9 = String(20)
            print(self.allQuestionsArray?[opionIndex].optionD ?? "")
        case 8:
//            answer9 = self.allQuestionsArray?[opionIndex].optionD ?? ""
            answer10 = String(20)
            print(self.allQuestionsArray?[opionIndex].optionD ?? "")
        case 9:
//            answer10 = self.allQuestionsArray?[opionIndex].optionD ?? ""
            answer11 = String(20)
            print(self.allQuestionsArray?[opionIndex].optionD ?? "")
        case 10:
//            answer11 = self.allQuestionsArray?[opionIndex].optionD ?? ""
            answer12 = String(20)
            print(self.allQuestionsArray?[opionIndex].optionD ?? "")
        case 11:
//            answer12 = self.allQuestionsArray?[opionIndex].optionD ?? ""
            answer13 = String(20)
            print(self.allQuestionsArray?[opionIndex].optionD ?? "")
        case 12:
//            answer13 = self.allQuestionsArray?[opionIndex].optionD ?? ""
            answer14 = String(20)
            print(self.allQuestionsArray?[opionIndex].optionD ?? "")
        case 13:
//            answer14 = self.allQuestionsArray?[opionIndex].optionD ?? ""
            answer15 = String(20)
            print(self.allQuestionsArray?[opionIndex].optionD    ?? "")
    
        default:
            print("")
        }
       
    }
    
    
    func buttonHightlight(tag:Int) {
        
        switch tag {
        case 1:
           optionA.backgroundColor = .yellow
           optionC.backgroundColor = .white
           optionB.backgroundColor = .white
           optionD.backgroundColor = .white
        case 2:
            optionA.backgroundColor = .white
            optionC.backgroundColor = .white
            optionB.backgroundColor = .yellow
            optionD.backgroundColor = .white
        case 3:
            optionA.backgroundColor = .white
            optionC.backgroundColor = .yellow
            optionB.backgroundColor = .white
            optionD.backgroundColor = .white
        case 4:
            optionA.backgroundColor = .white
            optionC.backgroundColor = .white
            optionB.backgroundColor = .white
            optionD.backgroundColor = .yellow
       
        default:
            optionA.backgroundColor = .white
            optionC.backgroundColor = .white
            optionB.backgroundColor = .white
            optionD.backgroundColor = .white
        }
        
    }
    
    
    func saveAnswers()
    {
        
            
            let pid = UserDefaults.standard.value(forKey: "userId")
                    let formData = [
                        "pid":"\(pid ?? "")",
                        "question1":selectedScore,
                        "question2":answer2,
                        "question3":answer3,
                        "question4":answer4,
                        "question5":answer5,
                        "question6":answer6,
                        "question7":answer7,
                        "question8":answer8,
                        "question9":answer9,
                        "question10":answer10,
                        "question11":answer11,
                        "question12":answer12,
                        "question13":answer13,
                        "question14":answer14,
                        "question15":answer15,
                        
                    ]

                    APIHandler().postAPIValues(type: SaveAnswers.self, apiUrl: ServiceAPI.saveAnswers , method: "POST", formData: formData) {
                        [weak self] result in
                        switch result {
                        case .success(let data):
                            print(data)
                            DispatchQueue.main.async {
                            if data.status == true {
                                let alertController = UIAlertController(title: "Message", message: data.message, preferredStyle: .alert)
                                let okAction = UIAlertAction(title: "OK", style: .default) { _ in
                                    if let navigationController = self?.navigationController {
                                        for viewController in navigationController.viewControllers {
                                            if let desiredViewController = viewController as? PatientTabController {
                                                desiredViewController.selectedIndex = 1
                                                navigationController.popToViewController(desiredViewController, animated: true)
                                                break
                                            }
                                        }
                                    }
                                }
                                alertController.addAction(okAction)
                                self?.present(alertController, animated: true, completion: nil)

                                
                                
                                
                                
                                
                                
                            }else {
                                if let navi = self?.navigationController {
                                DataManager.shared.sendMessage(title: "Message", message: data.message, navigation: navi)
                                }
                            }
                                
                            }
                        case .failure(let error):
                            print(error)
                            DispatchQueue.main.async {
                                if let navi = self?.navigationController {
                                DataManager.shared.sendMessage(title: "Alert", message: "Error occured", navigation: navi)
                              }
                        }
                    }
        }
    }
    @IBAction func backTap(_ sender: Any) {
        if self.allQuestionsArray?.isEmpty == nil {
            
            
            if let navigationController = self.navigationController {
                for viewController in navigationController.viewControllers {
                    if let desiredViewController = viewController as? PatientTabController {
                        desiredViewController.selectedIndex = 1
                        navigationController.popToViewController(desiredViewController, animated: true)
                        break
                    }
                }
            }
            
        }else {
            self.navigationController?.popViewController(animated: false)
 
        }
       
        
    }
}
