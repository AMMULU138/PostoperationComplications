//
//  trackappointment.swift
//  ortho
//
//  Created by SAIL L1 on 21/11/23.
//

import UIKit

class trackappointment: UIViewController,UITableViewDelegate,UITableViewDataSource {
  
    @IBOutlet weak var listtable: UITableView!
    
    var trackAppoinmetDeatail:Getquestions1?
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad();
        listtable.dataSource = self
        listtable.delegate = self
    
        trackappointmentData ()
    }
    
    
    
    
    func trackappointmentData() {
        let id  = UserDefaults.standard.value(forKey: "userId")
                let formData = [
                    "pid": "\(id ?? "")",
                   
                ]

                APIHandler().postAPIValues(type: Getquestions1.self, apiUrl: ServiceAPI.trackappointmentUrl , method: "POST", formData: formData) {
                    [weak self] result in
                    switch result {
                    case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                        self?.trackAppoinmetDeatail = data
                        self?.listtable.reloadData()
                        }
                    case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        self?.showAlertMessage(title: "Alert", message: "Failed to register patient. Please try again.")
                        }
                    }
                }


        }
    
    @IBAction func backTap(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
    
}
    
extension trackappointment {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return trackAppoinmetDeatail?.appointments.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"cell3" , for: indexPath)as!  tracklistcell
        cell.docname.text = trackAppoinmetDeatail?.appointments[indexPath.row].docname
        cell.time.text = trackAppoinmetDeatail?.appointments[indexPath.row].date
        cell.newStatus.text = trackAppoinmetDeatail?.appointments[indexPath.row].status
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }
    
}
