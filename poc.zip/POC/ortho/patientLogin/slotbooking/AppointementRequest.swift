//
//  AppointementRequest.swift
//  ortho
//
//  Created by SAIL L1 on 21/11/23.
//

import UIKit

class AppointementRequest: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    @IBOutlet weak var table: UITableView!
    
    
    
    var doctorList:DoctorList?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       table.dataSource = self
        table.delegate = self
        
        
       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        doctorListData()
    }
    
    func doctorListData() {
                let formData = [
                    "": "",
                ]

                APIHandler().postAPIValues(type: DoctorList.self, apiUrl: ServiceAPI.doctorListUrl , method: "POST", formData: formData) {
                    [weak self] result in
                    switch result {
                    case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            self?.doctorList = data
                            self?.table.reloadData()
                        }
                    case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        self?.showAlertMessage(title: "Error", message: "Failed to register patient. Please try again.")
                        }
                    }
                }
        }

    


}

extension AppointementRequest {
    
   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return self.doctorList?.doctors.count ?? 0
     }

     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"cell" , for: indexPath)as!appointmentdclist
         cell.docname.text = self.doctorList?.doctors[indexPath.row].docname
         cell.speclization.text = self.doctorList?.doctors[indexPath.row].specalization
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "SlotBooking") as! SlotBooking
        vc.doctorId = self.doctorList?.doctors[indexPath.row].did ?? "0"
        vc.doctorName = self.doctorList?.doctors[indexPath.row].docname ?? ""
        self.navigationController?.pushViewController(vc, animated: true)
    }
   
}
