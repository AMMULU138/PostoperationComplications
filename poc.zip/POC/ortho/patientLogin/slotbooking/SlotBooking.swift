//
//  SlotBooking.swift
//  ortho
//
//  Created by SAIL L1 on 16/11/23.
//

import UIKit

class SlotBooking: UIViewController {

  
    
    @IBOutlet weak var doctorNamelbl: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var calView: UIView!
    
    
    
    @IBOutlet weak var reason: UITextField!
    @IBOutlet weak var slotBookBtn: UIButton!
    
    
  
    
    var slotDisplayData:SlotDisplay?
    
    let datePicker  = UIDatePicker()
    
    var array =  ["MORNING","AFTERNOON","NIGHT"]
    
    var doctorId = String()
    var doctorName = String()
    var slot = String()
    var slectedIndex = Int()
    var selectedDate = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        doctorNamelbl.text = doctorName
        let flow = CustomVerticalFlowLayout()
        collectionView.collectionViewLayout = flow
        
        collectionView.delegate = self
        collectionView.dataSource = self
        
        let cell = UINib(nibName: "SlotDisplayCell", bundle: nil)
        collectionView.register(cell, forCellWithReuseIdentifier: "cell")

        showDatePicker()
    }
    
    func showDatePicker() {
           // Formate Date
           datePicker.datePickerMode = .date

           if #available(iOS 13.4, *) {
               datePicker.preferredDatePickerStyle = .inline
           } else {
               datePicker.preferredDatePickerStyle = .wheels
           }
           let toolbar = UIToolbar()
           toolbar.sizeToFit()

           // done button & cancel button
           let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donedatePicker(_:)))
         
           let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)

           let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.cancelDatePicker(_:)))
           
           toolbar.setItems([cancelButton, spaceButton, doneButton], animated: false)

           // Add the datePicker to the view
           view.addSubview(datePicker)
           view.addSubview(toolbar)

           // Add constraints or frame as needed
           datePicker.translatesAutoresizingMaskIntoConstraints = false
           toolbar.translatesAutoresizingMaskIntoConstraints = false

           NSLayoutConstraint.activate([
               // Adjust the constraints as per your layout requirements
            datePicker.topAnchor.constraint(equalTo: calView.topAnchor),
            datePicker.leadingAnchor.constraint(equalTo: calView.leadingAnchor),
            datePicker.trailingAnchor.constraint(equalTo: calView.trailingAnchor),
            datePicker.bottomAnchor.constraint(equalTo: calView.bottomAnchor,constant: -10),

               toolbar.topAnchor.constraint(equalTo: datePicker.bottomAnchor,constant: -10),
               toolbar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
               toolbar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
           ])
       }

       @objc func cancelDatePicker(_ sender: UIButton) {
         //  datePicker.removeFromSuperview()
       }

       @objc func donedatePicker(_ sender: UIButton) {
           let formatter = DateFormatter()
           formatter.dateFormat = "yyyy-MM-dd"

           self.selectedDate = formatter.string(from: datePicker.date)
           print(formatter.string(from: datePicker.date))
           self.doctorListData(date: formatter.string(from: datePicker.date))

          
       }
    
    
    
    func doctorListData(date:String) {
                let formData = [
                    "date": date,
                    "Did":doctorId
                ]

                APIHandler().postAPIValues(type: SlotDisplay.self, apiUrl: ServiceAPI.slotDisplayUrl , method: "POST", formData: formData) {
                    [weak self] result in
                    switch result {
                    case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            self?.slotDisplayData = data
                            self?.collectionView.reloadData()
                        }
                    case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        self?.showAlertMessage(title: "Error", message: "Failed to register patient. Please try again.")
                        }
                    }
                }
        }


    @IBAction func SLOTBOOK(_ sender: Any) {
        
        
        let refreshAlert = UIAlertController(title: "Message", message: "Are you sure sent request!", preferredStyle: UIAlertController.Style.alert)

        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
            
            
            self.bookingSlot()
           
          }))

        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
            self.dismiss(animated: false, completion: nil)
          }))

        present(refreshAlert, animated: true, completion: nil)

        
        }

    func bookingSlot() {
        
        let pid = UserDefaults.standard.value(forKey: "userId") as? String ?? ""
                let formData = [
                    "pid":"\(pid )",
                    "date": selectedDate,
                    "Did":doctorId,
                    "slot":self.slot,
                    "docname":self.doctorName,
                    "reason":reason.text ?? ""
                ]

                APIHandler().postAPIValues(type: addppModel.self, apiUrl: ServiceAPI.slotBookingUrl , method: "POST", formData: formData) {
                    [weak self] result in
                    switch result {
                    case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                                let vc = storyBoard.instantiateViewController(withIdentifier: "PatientTabController") as! PatientTabController
                            vc.selectedIndex = 1
                            self?.navigationController?.pushViewController(vc, animated: true)
                        }
                    case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        self?.showAlertMessage(title: "Error", message: "Failed to register patient. Please try again.")
                        }
                    }
                }
    }
    
}
    


extension SlotBooking: UICollectionViewDelegate,UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.slotDisplayData?.data.count ?? 0
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! SlotDisplayCell
        cell.slotLabel.text = self.slotDisplayData?.data[indexPath.item]
        cell.layer.cornerRadius = 5
       return cell
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let cell = collectionView.cellForItem(at: indexPath) as? SlotDisplayCell else {
            return
        }

        for index in collectionView.indexPathsForVisibleItems {
            if let otherCell = collectionView.cellForItem(at: index) as? SlotDisplayCell {
                if index != indexPath {
                    otherCell.mainView.backgroundColor = UIColor.lightGray
                }
            }
        }
        self.slot = self.slotDisplayData?.data[indexPath.item] ?? ""
        print(self.slot)
        cell.mainView.backgroundColor = (cell.mainView.backgroundColor == UIColor.lightGray) ? UIColor(named: "appColor") : UIColor.lightGray
    }

    @IBAction func backTap(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
}



class CustomVerticalFlowLayout: UICollectionViewFlowLayout {
   override func prepare() {
       super.prepare()
       guard let collectionView = collectionView else { return }
       minimumLineSpacing = 10.0
       minimumInteritemSpacing = 10.0
       let availableWidth = collectionView.bounds.width - sectionInset.left - sectionInset.right - minimumInteritemSpacing
       let cellWidth = (availableWidth - minimumInteritemSpacing) / 3.0
       itemSize = CGSize(width: cellWidth, height: collectionView.frame.height)
   }
  
}
