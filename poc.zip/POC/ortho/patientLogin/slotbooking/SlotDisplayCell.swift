//
//  SlotDisplayCell.swift
//  ortho
//
//  Created by SAIL on 31/01/24.
//

import UIKit

class SlotDisplayCell: UICollectionViewCell {
    
    
    
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var slotLabel: UILabel!
    
  
    var tap:(() -> ())?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBAction func slotTapped(_ sender: Any) {
        
        tap?()
    }
}
