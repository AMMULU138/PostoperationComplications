//
//  patientprofilevc.swift
//  ortho
//
//  Created by SAIL on 03/02/24.
//

    import UIKit

    class patientProfilevc: UIViewController {
            
        @IBOutlet weak var patientId: UILabel!
        @IBOutlet weak var pmailId: UILabel!
        @IBOutlet weak var Address: UILabel!
        @IBOutlet weak var pname: UILabel!
        @IBOutlet weak var pimage: UIImageView!
        var pid1 : String = ""
     var patientProfile:pProfile?
        override func viewDidLoad() {
            super.viewDidLoad()
            
            LoadingIndicator.shared.showLoading(on: self.view)
            pimage.clipsToBounds = true
                fetchData()
            
        }
        func fetchData() {
            let id  = UserDefaults.standard.value(forKey: "userId")
            let formData = [
                "pid": "\(id ?? "")",
         ]
            APIHandler().postAPIValues(type: pProfile.self, apiUrl: ServiceAPI.pprofileUrl , method: "POST", formData: formData) {
                [ self] result in
                    switch result
                {
                    case .success(let data):
                        DispatchQueue.main.async {
                            LoadingIndicator.shared.hideLoading()
                            self.patientProfile = data
                            self.patientId.text = self.patientProfile?.data.first?.pid
                            self.pmailId.text = self.patientProfile?.data.first?.pmail
                            self.Address.text = self.patientProfile?.data.first?.paddress
                            self.pname.text = self.patientProfile?.data.first?.pname
                            self.loadImage(url: self.patientProfile?.data.first?.ppimage ?? "", imageView: self.pimage)
                    }
                    case .failure(_):
                        DispatchQueue.main.async
                        {
                            LoadingIndicator.shared.hideLoading()
                            if self.navigationController != nil {
                              self.showAlertMessage(title: "Alert", message: "Unable to fetch details")
                    
                            }
                        }

                }
            }
    }
        
        @IBAction func backbtn(_ sender: Any) { 
          
            self.navigationController?.popViewController(animated: false)
            
        }
        
        @IBAction func logout(_ sender: Any) {
            
            
            let alertController = UIAlertController(title: "Alert", message: "Do you want logout!", preferredStyle: .alert)
                   
                   // Create OK action
                   let okAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
                       
                       if let navigationController = self.navigationController {
                           for viewController in navigationController.viewControllers {
                               if let desiredViewController = viewController as? ViewController {
                                   navigationController.popToViewController(desiredViewController, animated: true)
                                   break
                               }
                           }
                       }
                     
                   }
                   
                   // Create Cancel action
                   let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action:UIAlertAction!) in
                       self.dismiss(animated: false, completion: nil)
                   }
                   alertController.addAction(okAction)
                   alertController.addAction(cancelAction)
                   self.present(alertController, animated: true, completion:nil)
        }
    }
