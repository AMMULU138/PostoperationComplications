import UIKit

class painScaleVC: UIViewController {
    @IBOutlet weak var b1BTN: UIButton!
    @IBOutlet weak var b2BTN: UIButton!
    @IBOutlet weak var b3BTN: UIButton!
    @IBOutlet weak var b4BTN: UIButton!
    @IBOutlet weak var b5BTN: UIButton!
    @IBOutlet weak var b6BTN: UIButton!
    
    var buttons: [UIButton] = []
    
    var selectedScore: String = " "
    
    override func viewDidLoad() {
        super.viewDidLoad()
        buttons = [b1BTN, b2BTN, b3BTN, b4BTN, b5BTN, b6BTN]
        b1BTN.tag = 0
        b2BTN.tag = 4
        b3BTN.tag = 7
        b4BTN.tag = 10
        b5BTN.tag = 15
        b6BTN.tag = 20

        b1BTN.setTitle("Score 1", for: .normal)
        b2BTN.setTitle("Score 2", for: .normal)
        b3BTN.setTitle("Score 3", for: .normal)
        b4BTN.setTitle("Score 4", for: .normal)
        b5BTN.setTitle("Score 5", for: .normal)
        b6BTN.setTitle("Score 6", for: .normal)
    }

    @IBAction func buttonTapped(_ sender: UIButton) {
        selectedScore = "\(sender.tag)"
        print("Selected Score: \(selectedScore)")
          
        
        updateButtonAppearance(selectedButton: sender)
    }
    
   
          
    
      func updateButtonAppearance(selectedButton: UIButton) {
          // Reset all button colors
          for button in buttons {
              if button == selectedButton {
                  // Set selected button color
                  button.backgroundColor = UIColor.systemBlue
              } else {
                  // Set other buttons to their default color
                  button.backgroundColor = UIColor.clear
                  // If you have custom background colors for buttons, replace UIColor.clear with the desired color
              }
          }
      }
   

    @IBAction func nexttap(_ sender: Any) {
        guard !selectedScore.isEmpty else {
            // Handle the case where no button is selected
            return
        }

        // Pass the selected score to the next view controller or perform any other action
        print("Selected Score for Next View Controller: \(selectedScore)")

        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "questionsViewController") as! questionsViewController
        vc.selectedScore = self.selectedScore

        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func backbtn(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
}
