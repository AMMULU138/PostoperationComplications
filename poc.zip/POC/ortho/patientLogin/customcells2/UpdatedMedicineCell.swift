//
//  UpdatedMedicineCell.swift
//  ortho
//
//  Created by SAIL on 24/01/24.
//

import UIKit

class UpdatedMedicineCell: UITableViewCell {
    
    
    @IBOutlet weak var adivceLbl: UILabel!
    
    
    
    @IBOutlet weak var suggestionlb: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    }

