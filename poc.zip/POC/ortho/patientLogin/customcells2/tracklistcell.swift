//
//  tracklistcell.swift
//  ortho
//
//  Created by SAIL L1 on 21/11/23.
//

import UIKit

class tracklistcell: UITableViewCell {

    @IBOutlet weak var docname: UILabel!
    @IBOutlet weak var time: UILabel!
    
    @IBOutlet weak var photoimage: UIImageView!
    
    
    
    @IBOutlet weak var newStatus: UILabel!

    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
  
    override func layoutSubviews() {
        super.layoutSubviews()
        let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        contentView.frame = contentView.bounds.inset(by: margin)
        contentView.layer.cornerRadius = 10
        }
            
   

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
