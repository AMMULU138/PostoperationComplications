//
//  questionnarieList.swift
//  ortho
//
//  Created by SAIL L1 on 16/11/23.
//

import UIKit

class questionnarieList: UITableViewCell {
    
    @IBOutlet weak var questionno: UILabel!
    
    
    @IBOutlet weak var viewButton: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }
    
    
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
     let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        contentView.frame = contentView.bounds.inset(by: margin)
        contentView.layer.cornerRadius = 10
    }
    
    
    
    
    }

