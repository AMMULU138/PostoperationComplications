//
//  Videos.swift
//  ortho
//
//  Created by SAIL L1 on 18/11/23.
//

import UIKit

class Videos: UIViewController {
    
    @IBOutlet weak var reasonView: UIView!
    @IBOutlet weak var completed: UIButton!
    
    @IBOutlet weak var reasonField: UITextView!
   
    
    @IBOutlet weak var notcomplicated: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       hiddenView(view: reasonView)
    }
   
    
    @IBAction func completedTap(_ sender: Any) {
      
        hiddenView(view: reasonView)
        DataManager.shared.reason = "yes"
        completed.backgroundColor = UIColor(hex: "#52BE80") // Change to desired color
        notcomplicated.backgroundColor = UIColor(hex: "#FFFFFF")
    }
    
    
    
    
    @IBAction func backbtn(_ sender: Any) {navigationController?.popViewController(animated: true)
    }
  
    @IBAction func next1(_ sender: Any) {
        if DataManager.shared.reason != "" {
            if  DataManager.shared.reason == "yes" {
                DataManager.shared.exercise = ""
            }else {
                DataManager.shared.exercise = reasonField.text ?? ""
            }
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "Videos1") as! Videos1
            
            self.navigationController?.pushViewController(vc, animated: true)
        
        }
    }
    
    
    
    
    @IBAction func notComTap(_ sender: Any) {
      
        showHiddenView(view: reasonView)
        DataManager.shared.reason = "no"
        completed.backgroundColor = UIColor(hex: "#FFFFFF") // Change to default color
        notcomplicated.backgroundColor = UIColor(hex: "#FF5733")
        
    }
  
    
    
    
    
}
