//
//  DloginModel.swift
//  ortho
//
//  Created by SAIL on 20/12/23.
//

import Foundation

struct BarModel: Codable {
    let status, message: String
    let quesData: [String]
}



struct DloginModel: Codable {
    let status: Bool
     let message: String
}


struct PatientList: Codable {
    let status, message: String
    let data: [Datum]
}


struct Datum: Codable {
    let pid: Int
    let pname,ppimage: String
}
//struct ViewPpDetail: Codable {
//    let status: Bool
//    let viewpatientpersonaldetails: [Viewpatientpersonaldetail]
//}
//
//// MARK: - Viewpatientpersonaldetail
//struct Viewpatientpersonaldetail: Codable {
//    let pid: String
//    let pname, pgender, pconsultant, diagnosis: String
//    let paddress, pdofadd, ppimage: String
//}

//struct ViewPpDetail: Codable {
//    let status: Bool
//    let viewpatientpersonaldetails: [Viewpatientpersonaldetail]
//}
//
//// MARK: - Viewpatientpersonaldetail
//struct Viewpatientpersonaldetail: Codable {
//    let pid: Int
//    let pname, pgender, pconsultant, diagnosis: String
//    let paddress, pdofadd, ppimage: String
//}

struct ViewPpDetail: Codable {
    let status: Bool
    let viewpatientpersonaldetails: [Viewpatientpersonaldetail]
}

// MARK: - Viewpatientpersonaldetail
struct Viewpatientpersonaldetail: Codable {
    let pid, pname, pgender, pconsultant: String
    let  paddress, pmail, ppimage: String
}

struct ViewPop: Codable {
    let status: Bool
    let viewpatientoperationaldetails: [Viewpatientoperationaldetail]
}

// MARK: - Viewpatientoperationaldetail
struct Viewpatientoperationaldetail: Codable {
    let sno, pid, status, proc: String
    let dtofproc, chfcompliants, hop, cinhos: String
    let treatmentgiven, otdetails, pmedicalhist, dischargeadvice: String
    let pimage: String
}

struct addppModel: Codable {
    let status: Bool
    let message: String
}
struct addpopModel: Codable {
    let status: Bool
    let message: String
}

struct AppoinmentStatus: Codable {
    let status: String
    let data: [Appointment]
}

// MARK: - Datum
struct Appointment: Codable {
    let appointmentID: Int
    let pid: String
    let did: Int
    let docname, date, slot, status: String
    let reason: String
    enum CodingKeys: String, CodingKey {
        case appointmentID, pid
        case did = "Did"
        case docname, date, slot, status ,reason 
    }
}

// MARK: - Welcome
struct Appoinmentapproved: Codable {
    let status: Bool
    let data: [approveappointment]
}

// MARK: - Datum
struct approveappointment: Codable {
    let appointmentID :Int
   let pid: String
    let did :Int
    let docname, date, slot, status: String
    let reason: String
    enum CodingKeys: String, CodingKey {
        case appointmentID, pid
        case did = "Did"
        case docname, date, slot, status ,reason
    }
}
struct SendToAccept: Codable {
    let status: String
    let message: String
}

//followupList
//struct FollowupList: Codable {
//    let status, message: String
//    let data: [Datum1]
//}
//
//// MARK: - Datum
//struct Datum1: Codable {
//    let pid: Int
//}
struct FollowupList: Codable {
    let status, message: String
    let data: [Datum1]
}

// MARK: - Datum
struct Datum1: Codable {
    let pid: Int
    let date: String?
}
//addreports
struct addreports1: Codable {
    let status: Bool
    let message: String
}
//struct shedule: Codable {
//    let status: Bool
//    let data: [sheduleapp]
//}
//
//// MARK: - Appointment
//struct sheduleapp: Codable {
//    let pid, day, date, slot: String
//}
//struct shedule: Codable {
//    let status: Bool
//    let schedule: [sheduleapp]
//}
//
//// MARK: - Appointment
//struct sheduleapp: Codable {
//    let pid, day, date, slot: String
//}
struct shedule: Codable {
    let status: Bool
    let appointments: [appointmentsapp]
}


// MARK: - Appointment
struct appointmentsapp: Codable {
    let pid, day, date, slot: String
}

struct Getquestions1: Codable {
    let status: Bool
    let appointments: [TrackApp]
}

struct TrackApp: Codable {
    let status,docname, date,slot: String

}



struct DoctorList: Codable {
    let status: Bool
    let doctors: [Doctor]
}


struct Doctor: Codable {
    let did, docname, specalization: String

    enum CodingKeys: String, CodingKey {
        case did = "Did"
        case docname, specalization
    }
}



struct FollowUp: Codable {
    let status: String
    let data: [FollowUpData]
}

struct FollowUpData: Codable {
    let updatedmed, addvice: String
}


struct SlotDisplay: Codable {
    let status: Bool
    let message: String
    let data: [String]
}

struct drProfile: Codable {
    let status: Bool
    let message: String
    let data: [dProfile]
}

// MARK: - Datum
struct dProfile: Codable {
    let did, docname, specalization, gender: String
    let mail, password: String

    enum CodingKeys: String, CodingKey {
        case did = "Did"
        case docname, specalization, gender, mail, password
    }
}
struct pProfile: Codable {
    let status: Bool
    let message: String
    let data: [patientprofile]
}

// MARK: - Datum
struct patientprofile: Codable {
    let pid, pname, pmail, pgender: String
    let ppassword, paddress, pconsultant: String
    let ppimage: String
}



// MARK: - Getquestions
struct QuestionDisplay: Codable {
    let status, message: String
    let data: [displayquestions]
}

// MARK: - Datum
struct displayquestions: Codable {
    let questionText, optionA, optionB, optionC: String
    let optionD: String

    enum CodingKeys: String, CodingKey {
        case questionText
        case optionA = "OptionA"
        case optionB = "OptionB"
        case optionC = "OptionC"
        case optionD = "OptionD"
    }
}
struct SaveAnswers: Codable {
    let status: Bool
    let message: String
}
struct DisplayStatus: Codable {
    let status: Bool
    let message: String
    let data: DataClass
}

struct DataClass: Codable {
    let pid, date, reason1, reason2: String
    let reason3, exercise1, exercise2, exercise3: String

    enum CodingKeys: String, CodingKey {
        case pid, date
        case reason1 = "reason_1"
        case reason2 = "reason_2"
        case reason3 = "reason_3"
        case exercise1 = "exercise_1"
        case exercise2 = "exercise_2"
        case exercise3 = "exercise_3"
    }
}



struct HighLightDate: Codable {
    let status: String
    let message: String
    let data: [TotalDates]
}

struct TotalDates: Codable {
    let date: String
 

}
struct dtofproc: Codable {
    let status: Bool
    let message: String
    let data: [Dtprocdone]
}

// MARK: - Datum
struct Dtprocdone: Codable {
    let dtofproc: String
}


 


