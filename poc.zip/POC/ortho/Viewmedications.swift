//
//  Viewmedications.swift
//  ortho
//
//  Created by SAIL on 08/05/24.
//

import UIKit

class Viewmedications: UIViewController {
    
    @IBOutlet weak var subView: UIView!
    @IBOutlet weak var ADVICETEXTFIELD: UITextView!
    @IBOutlet weak var upadatedmedtextfiled: UITextView!
    let datePicker: UIDatePicker = UIDatePicker()
    var patientId = String()
var date = String()
    var followUpdetails: FollowUp?
    
    override func viewDidLoad() {
        super.viewDidLoad()
//
//        LoadingIndicator.shared.showLoading(on: self.view)
        showDatePicker()
    }

    func showDatePicker() {
        datePicker.datePickerMode = .date
        
        // Set minimum and maximum dates
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        if let minDate = dateFormatter.date(from: "2024-05-08") {
            datePicker.minimumDate = minDate
        }
        if let maxDate = dateFormatter.date(from: "2024-05-31") {
            datePicker.maximumDate = maxDate
        }
        
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .inline
        } else {
            datePicker.preferredDatePickerStyle = .wheels
        }
        
        subView.addSubview(datePicker)
        datePicker.translatesAutoresizingMaskIntoConstraints = true
        datePicker.addTarget(self, action: #selector(datePickerValueChanged(_:)), for: .valueChanged)
    }


    @objc func datePickerValueChanged(_ datePicker: UIDatePicker) {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        dayfolowUpData(date: formatter.string(from: datePicker.date))
        print(formatter.string(from: datePicker.date))
    }

    func dayfolowUpData(date: String) {
        let patientIds = UserDefaults.standard.string(forKey: "userId") ?? ""
        let formData = [
            "pid": "\(patientIds)",
            "date": date,
        ]
        
        APIHandler().postAPIValues(type: FollowUp.self, apiUrl: ServiceAPI.followUpUrl, method: "POST", formData: formData) { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    [weak self] in
                    LoadingIndicator.shared.hideLoading()
                    self?.followUpdetails = data
                    if let followUpDetails = self?.followUpdetails,
                       let firstData = followUpDetails.data.first {
                        self?.ADVICETEXTFIELD.text = firstData.addvice
                        self?.upadatedmedtextfiled.text = firstData.updatedmed
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    LoadingIndicator.shared.hideLoading()
                    self?.showAlertMessage(title: "Error", message: "no data avialabe")
                }
            }
        }
    }

    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
}
