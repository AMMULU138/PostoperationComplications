//
//  Constant.swift
//  WeatherApp
//
//  Created by MAC-Air on 08/09/23.
//

import Foundation
import UIKit



struct ServiceAPI {
    
    static let baseURL = "http://192.168.254.66/Amar/"
    static let LogInURL = baseURL+"dlogin.php"
    static let PatientListURL = baseURL+"patientList.php"
    static let viewPp = baseURL+"viewpp.php"
    static let viewPop = baseURL+"viewpop.php"
    static let addpp = baseURL+"addpp.php"
    static let addpop = baseURL+"addpop.php"
    static let appPrintBooked = baseURL+"appprintbooked.php"
    static let appPrintBookedAccept = baseURL+"appprintbooked1.php"
    static let toChangeStatus = baseURL+"tochangestatus.php"
    static let flistURL = baseURL+"followuplist.php"
    static let addreports = baseURL+"addreports.php"
    static let daysSheduleUrl = baseURL+"shedule.php"
    static let patientLogin = baseURL+"plogin.php"
    static let trackappointmentUrl = baseURL+"trackapp.php"
    static let doctorListUrl = baseURL+"doclist.php"
    static let followUpUrl = baseURL+"pfollowup.php"
    static let SlotDisplayUrl = baseURL+"SlotDisplay.php"
    static let AppbookingUrl = baseURL+"appbooking.php"
    static let slotDisplayUrl = baseURL+"slotDisplay.php"
    static let slotBookingUrl = baseURL+"slotbook.php"
    static let drprofileUrl = baseURL+"dprofile.php"
    static let pprofileUrl = baseURL+"pprofile.php"
    static let questiondisplay = baseURL+"QuestionDisplay.php"
    static let saveAnswers = baseURL+"saveAnswers.php"
    static let addExceriseStatus = baseURL+"add_excerise_status.php"
    static let statusDisplay = baseURL+"todisplayexstatus.php"
    static let dateHighlight = baseURL+"toshowmedications.php"
    static let dtofprocurl = baseURL+"pdofadd.php"
    static let BarGraphAPI = baseURL+"bargraph.php"
    
}
