//
//  UIView.swift
//  DreamMom
//
//  Created by SAIL on 24/11/23.
//

import UIKit




extension UITextField {

    func setInputViewTimePicker(target: Any, selector: Selector) {
        let screenWidth = UIScreen.main.bounds.width
        let timePicker = UIDatePicker(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 216))
        
        timePicker.datePickerMode = .date // Set the picker mode to time

        if #available(iOS 14, *) {
            timePicker.preferredDatePickerStyle = .wheels
            timePicker.sizeToFit()
        }
        self.inputView = timePicker

        let toolBar = UIToolbar(frame: CGRect(x: 0.0, y: 0.0, width: screenWidth, height: 44.0))
        let flexible = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancel = UIBarButtonItem(title: "Cancel", style: .plain, target: nil, action: #selector(tapCancel))
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: target, action: selector)

        toolBar.setItems([cancel, flexible, doneButton], animated: false)
        self.inputAccessoryView = toolBar
    }

    @objc func tapCancel() {
        self.resignFirstResponder()
    }
}


