//
//  Videos1.swift
//  ortho
//
//  Created by SAIL on 17/04/24.
//

import UIKit

class Videos1: UIViewController {
    
    
    
    @IBOutlet weak var reasonField1: UITextView!
    
    @IBOutlet weak var reasonView: UIView!
    
    @IBOutlet weak var NOTCOMTAP: UIButton!
    @IBOutlet weak var COMTAP: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        hiddenView(view: reasonView)
    }
    

    
    @IBAction func comTap(_ sender: Any) {
        hiddenView(view: reasonView)
     
        DataManager.shared.reason1 = "yes"
        COMTAP.backgroundColor = UIColor(hex: "#52BE80") // Change to desired color
        NOTCOMTAP.backgroundColor = UIColor(hex: "#FFFFFF")
    }
    
    
    @IBAction func notComTap(_ sender: Any) {
        showHiddenView(view: reasonView)
     
        DataManager.shared.reason1 = "no"
        COMTAP.backgroundColor = UIColor(hex: "#FFFFFF") // Change to default color
        NOTCOMTAP.backgroundColor = UIColor(hex: "#FF5733")
        
       
    }
    
    @IBAction func nextTap(_ sender: Any) {
        
        if  DataManager.shared.reason1 != "" {
            if  DataManager.shared.reason1 == "yes" {
                DataManager.shared.exercise1 = ""
            }else {
                DataManager.shared.exercise1 = reasonField1.text ?? ""
            }
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "Videos2") as! Videos2
        self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func backtap(_ sender: Any) {navigationController?.popViewController(animated: true)
    }
    
}
