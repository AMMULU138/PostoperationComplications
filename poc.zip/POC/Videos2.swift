//
//  Videos2.swift
//  ortho
//
//  Created by SAIL on 17/04/24.
//

import UIKit

class Videos2: UIViewController {
    
    
    
    @IBOutlet weak var reasonField2: UITextView!
    @IBOutlet weak var reasonView: UIView!
    
    @IBOutlet weak var comtap: UIButton!
    
    @IBOutlet weak var notcomtap: UIButton!
    var exercise2 = String()
    var reason2 = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        hiddenView(view: reasonView)
    }
    
    
    
    
    @IBAction func comTap(_ sender: Any) {
        hiddenView(view: reasonView)
        exercise2 = ""
        reason2 = "yes"
        comtap.backgroundColor = UIColor(hex: "#52BE80") // Change to desired color
        notcomtap.backgroundColor = UIColor(hex: "#FFFFFF")
    }
    
    
    
    @IBAction func notComTap(_ sender: Any) {
        showHiddenView(view: reasonView)
        exercise2 = reasonField2.text ?? ""
        reason2 = "no"
        comtap.backgroundColor = UIColor(hex: "#FFFFFF") // Change to default color
        notcomtap.backgroundColor = UIColor(hex: "#FF5733")
        
    }
    
    
    
    
    @IBAction func submitTap(_ sender: Any) {
        hiddenView(view: reasonView)
        if reason2 != "" {
            self.submitToBackend()
        }else {
            
            if let navi = self.navigationController {
            DataManager.shared.sendMessage(title: "Alert", message: "Click complete or not completed", navigation: navi)
            }
        }
    }
    
    func submitToBackend()
    {

        let currentDate = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let formattedDate = dateFormatter.string(from: currentDate)
        
      


            let pid = UserDefaults.standard.value(forKey: "userId")
                    let formData = [
                        "pid":"\(pid ?? "")",
                        "date":formattedDate,
                        "exercise_1": DataManager.shared.exercise,
                        "exercise_2":DataManager.shared.exercise1,
                        "exercise_3":exercise2,
                        "reason_1":DataManager.shared.reason,
                        "reason_2":DataManager.shared.reason1,
                        "reason_3":reason2,
                    
                        

                    ]

                    APIHandler().postAPIValues(type: SaveAnswers.self, apiUrl: ServiceAPI.addExceriseStatus , method: "POST", formData: formData) {
                        [weak self] result in
                        switch result {
                        case .success(let data):
                            print(data)
                            DispatchQueue.main.async {
                            if data.status == true {
                                let alertController = UIAlertController(title: "Message", message: data.message, preferredStyle: .alert)
                                let okAction = UIAlertAction(title: "OK", style: .default) { _ in
                                    if let navigationController = self?.navigationController {
                                        for viewController in navigationController.viewControllers {
                                            if let desiredViewController = viewController as? PatientTabController {
                                                desiredViewController.selectedIndex = 1
                                                navigationController.popToViewController(desiredViewController, animated: true)
                                                break
                                            }
                                        }
                                    }
                                }
                                alertController.addAction(okAction)
                                self?.present(alertController, animated: true, completion: nil)

                            }else {
                                if let navi = self?.navigationController {
                                DataManager.shared.sendMessage(title: "Message", message: data.message, navigation: navi)
                                }
                            }

                            }
                        case .failure(let error):
                            print(error)
                            DispatchQueue.main.async {
                                if let navi = self?.navigationController {
                                DataManager.shared.sendMessage(title: "Alert", message: "Error occured", navigation: navi)
                              }
                        }
                    }
        }
    }

    @IBAction func backtap(_ sender: Any) {navigationController?.popViewController(animated: true)
    }
}
