-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2024 at 06:07 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `poc`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appointmentID` int(11) NOT NULL,
  `pid` varchar(255) NOT NULL,
  `Did` int(11) NOT NULL,
  `docname` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `slot` varchar(80) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appointmentID`, `pid`, `Did`, `docname`, `date`, `slot`, `status`) VALUES
(3, '54322', 54322, 'akshaya ', '2023-12-18', 'afternoon', 'approved'),
(4, '350001', 54321, '', '2024-01-01', '', 'approved'),
(5, '', 1234, '', '2023-12-18', '', 'approved'),
(7, '350001', 54321, 'jai', '2024-01-24', 'morning', 'approved'),
(8, '350002', 54322, 'jai', '2024-01-24', 'Evening', 'approved'),
(26, '350003', 54321, 'jai', '2024-01-21', 'afternoon', 'approved'),
(27, '350003', 54321, 'jai', '2024-01-21', 'Evening', 'approved'),
(28, '', 54321, '', '2024-01-24', 'morning', 'approved'),
(29, '', 54321, '', '2024-01-29', 'morning', 'approved'),
(30, '350001', 54321, '', '2024-01-29', 'morning', 'approved'),
(31, '350001', 54321, 'jai\n', '2024-01-29', 'morning', 'approved'),
(32, '350001', 54321, 'jai\n', '2024-01-29', 'morning', 'pending'),
(33, '350001', 54321, 'jai', '2024-01-25', 'afternoon', 'approved'),
(34, '350001', 54322, 'akshaya', '2024-02-02', 'morning', 'approved'),
(35, '350001', 54321, 'jai', '2024-02-09', 'morning', 'approved'),
(37, '350001', 54321, 'jai', '2024-02-22', 'morning', 'approved'),
(38, '350001', 54322, 'akshaya', '2024-02-21', 'morning', 'approved'),
(39, '350001', 54321, 'jai', '2024-03-01', 'afternoon', 'approved'),
(40, '350001', 54321, 'jai', '2024-03-13', 'night', 'approved'),
(41, '350001', 54321, 'jai', '2024-03-08', 'afternoon', 'approved'),
(42, '350002', 54321, 'jai', '2024-03-22', 'morning', 'approved'),
(43, '350001', 54321, 'jai', '2024-03-21', '', 'approved'),
(44, '350001', 54322, 'akshaya', '2024-03-26', '', 'pending'),
(45, '350001', 54322, 'akshaya', '2024-03-27', 'morning', 'pending'),
(47, '189076', 54321, 'jaii', '2024-03-29', 'afternoon', 'approved'),
(48, '189076', 54321, 'jaii', '0000-00-00', 'afternoon', 'approved'),
(49, '189076', 54321, 'jaii', '2024-03-29', 'afternoon', 'approved'),
(50, '189076', 54321, 'jaii', '2024-03-29', 'afternoon', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `Did` int(11) NOT NULL,
  `docname` varchar(100) NOT NULL,
  `specalization` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`Did`, `docname`, `specalization`, `gender`, `mail`, `password`) VALUES
(54321, 'jai', 'ortho', 'male', 'salisamjai2002@gmail.com', '12345'),
(54322, 'akshaya', 'ortho', 'female', 'venkatasahithi138@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `medicalreports`
--

CREATE TABLE `medicalreports` (
  `sNo` int(11) NOT NULL,
  `pid` int(11) DEFAULT NULL,
  `updatedmed` varchar(3555) NOT NULL,
  `addvice` varchar(3555) NOT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicalreports`
--

INSERT INTO `medicalreports` (`sNo`, `pid`, `updatedmed`, `addvice`, `date`) VALUES
(1, NULL, 'ekqjshdi', 'lksjdxnoaw', NULL),
(2, 1234, 'ekqjshdi', 'lksjdxnoaw', NULL),
(5, 350003, 'mhv', 'mhv', '2024-01-12'),
(36, 99999, 'fads', 'dfgr', NULL),
(40, 350001, '', '', '2024-03-12'),
(42, 350001, 'asdaw', 'sfdv', '2024-03-12'),
(43, 0, '', '', NULL),
(44, 0, 'asdaw', 'sfdv', NULL),
(45, 0, 'asdaw', 'sfdv', NULL),
(46, 189076, 'asdaw', 'sfdv', '2024-03-28');

-- --------------------------------------------------------

--
-- Table structure for table `pain_scale`
--

CREATE TABLE `pain_scale` (
  `name` int(11) NOT NULL,
  `saved responses` varchar(999) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `pid` int(11) NOT NULL,
  `pname` text NOT NULL,
  `pmail` text NOT NULL,
  `pgender` text NOT NULL,
  `ppassword` text NOT NULL,
  `paddress` text NOT NULL,
  `pconsultant` text NOT NULL,
  `Did` int(11) NOT NULL,
  `pdofadd` datetime NOT NULL,
  `diagnosis` varchar(27) NOT NULL,
  `ppimage` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`pid`, `pname`, `pmail`, `pgender`, `ppassword`, `paddress`, `pconsultant`, `Did`, `pdofadd`, `diagnosis`, `ppimage`) VALUES
(8, 'testing5', 'Bianca’s', 'male', '00', 'encasing', '54321', 0, '0000-00-00 00:00:00', '', 'uploads/A17AEC2F-C855-46C9-A5DB-BC6B5E3E3A36.jpg'),
(123, 'sahithi', 'we', 'dev', '123', 'see', '54322', 0, '0000-00-00 00:00:00', '', ''),
(999, 'texting2', '32', '00', '001', '131', '54321', 0, '0000-00-00 00:00:00', '', 'uploads/2662D676-FABC-41FA-AE47-025703AFF695.jpg'),
(1238, 'www', 'ERTZSER', 'DZRT', '1234', 'XDRTZ', '54321', 0, '0000-00-00 00:00:00', '', ''),
(5421, 'hunk', 'Ty', 'yui8', 'Fuji', 'tyke', '54322', 0, '0000-00-00 00:00:00', '', 'uploads/6A4FCAEB-6F6B-4D2A-A427-D513F90F4786.jpg'),
(8451, 'cab', 'zest', 'zagged', 'fcvg', 'sere', '54321', 0, '0000-00-00 00:00:00', '', 'uploads/F63B84DB-1449-4BE4-8786-F4E0704EA234.jpg'),
(8888, 'testing5', 'JSAAHSD', 'tesing5', 'tesing5', 'CHENNAI', '54321', 0, '0000-00-00 00:00:00', '', 'uploads/41505597-4D14-41CF-A351-7BFA31F39A9A.jpg'),
(9999, 'testing4', 'testing4', 'testing4', 'testing4', 'testing4', '54322', 0, '0000-00-00 00:00:00', '', 'uploads/BBFE5395-527E-4E8B-A061-DA65316552FA.jpg'),
(19452, 'annuli', 'dfgdfg', 'male', '1235', 'Nellie', '54321', 0, '0000-00-00 00:00:00', '', 'uploads/8E53A3A2-1348-4F90-B90D-0232DA163A62.jpg'),
(21755, 'Kathiravan', 'kahir@gmail.com', 'male', 'Kathir', 'Pallavaram Chennai', '54322', 0, '0000-00-00 00:00:00', '', ''),
(84625, 'hgc', 'mvhuj', 'hbn', 'mhvk', 'jhyv', '54322', 0, '0000-00-00 00:00:00', '', ''),
(87354, 'Amy', 'ammu@138', 'female', '1234', 'Nellie', '54321', 0, '0000-00-00 00:00:00', '', 'uploads/8ECC4CB6-BAFD-4123-9B2B-407D814D2CF2.jpg'),
(90009, 'kiruba1', 'kiruba@gmail.com', 'male', '009', 'Chennai', '54321', 0, '0000-00-00 00:00:00', '', 'uploads/E249B5DC-25B3-4F30-9734-BC01D8ADE1C5.jpg'),
(99255, 'hgc', 'mvhuj', 'hbn', 'mhvk', 'jhyv', '0', 0, '0000-00-00 00:00:00', '', ''),
(123654, 'fab', 'dg', 'zig', 'fog', 'dog', '0', 0, '0000-00-00 00:00:00', '', 'uploads/554D18A7-E32D-4135-9889-EBF2CFF4D836.jpg'),
(189076, 'asde', 'asxd', 'efrw4r', 'aser3', 'asdeasa', '0', 0, '0000-00-00 00:00:00', '', 'uploads/0F34101E-9877-4E12-9D91-8A3ED9D61CA3.jpg'),
(192011, 'svz', 'wefr', 'sfr', 'sdfwr', 'sert', '0', 0, '0000-00-00 00:00:00', '', 'uploads/ppimage.jpeg'),
(350001, 'abbinav', 'abbhinav@gmail.com', 'male', '1234', 'nellore', '0', 0, '0000-00-00 00:00:00', 'fever', ''),
(350002, 'chinni', 'chhini@gmail.com', 'female', '1234', 'chittor', '0', 0, '0000-00-00 00:00:00', 'cold', ''),
(350003, 'abbhi', 'abbhi@gmail.com', 'male', '1234', 'nellore', '0', 0, '0000-00-00 00:00:00', 'cold', 'http://192.168.91.66:80/Amar/uploads/ppimage.jpeg'),
(350004, 'sahithip', 'psahithi@gmail.com', 'female', '1234', 'palamaneru', '0', 0, '0000-00-00 00:00:00', 'cold', 'uploads/Profile1.jpg'),
(350005, 'sathishdm', 'pm', 'male', '12345', 'didn’t', '0', 0, '0000-00-00 00:00:00', '', ''),
(350009, 'amar', 'amar@gmail.com', 'male', '1234', 'guntur', '0', 0, '0000-00-00 00:00:00', '', ''),
(870011, 'fgawer', 'eras', '2-2-2024', 'wEU', 'erf', '0', 0, '2024-02-12 00:00:00', '', ''),
(870012, 'fgawer', 'eras', '2-2-2024', 'wEU', 'erf', '0', 0, '2024-02-12 00:00:00', '', ''),
(870019, 'fgawer', 'eras', '2-2-2024', 'wEU', 'erf', '0', 0, '2024-02-12 00:00:00', '', ''),
(870099, 'sir', 'eras', '2-2-2024', 'wEU', 'erf', '0', 0, '2024-02-12 00:00:00', '', ''),
(963852, 'testingTwo ', 'mascasncc', '000', '005', 'chennai', '0', 0, '0000-00-00 00:00:00', '', 'uploads/667DDEED-D3E4-4999-B35D-B4FECE72D934.jpg'),
(987654, 'testing', 'chennai@gmail.com', 'male', '008', 'Chennai', '1', 0, '0000-00-00 00:00:00', '', 'uploads/12D6B091-1817-41D6-9817-B1D4B4C69974.jpg'),
(9876540, 'hgc', 'mvhuj', 'hbn', 'mhvk', 'jhyv', '0', 0, '0000-00-00 00:00:00', '', 'uploads/1B96B449-C95D-477F-BE5D-605C61860D22.jpg'),
(9876543, 'hgc', 'mvhuj', 'hbn', 'mhvk', 'jhyv', '0', 0, '0000-00-00 00:00:00', '', ''),
(32541899, 'v ', 'sadx', 'sec', 'dev', 'Zach’s', '0', 0, '0000-00-00 00:00:00', '', ''),
(32541900, 'v ', 'dads', 'sec', 'dev', 'Zach’s', '0', 0, '0000-00-00 00:00:00', '', ''),
(32541901, 'ASx', 'Zx', 'sasxASx', 'Zx', 'ASx', '0', 0, '0000-00-00 00:00:00', '', ''),
(32541902, 'ASx', 'Zx', 'sasxASx', 'Zx', 'ASx', '0', 0, '0000-00-00 00:00:00', '', ''),
(32541903, 'dev', 'sedf', 'add', 'f', 'do', '0', 0, '0000-00-00 00:00:00', '', ''),
(32541904, 'e', 'w', 'e', 'f', 'wee', '0', 0, '0000-00-00 00:00:00', '', ''),
(32541905, 'thus', 'W432', 'ta45', 'rate', 'w34r', '0', 0, '0000-00-00 00:00:00', '', ''),
(32541906, 'great', 'sd', 'as', 'add', 'as', '0', 0, '0000-00-00 00:00:00', '', ''),
(32541907, 'dvdsvdv', 'cxvcxv', 'cxvcxv', 'bccs', 'bccs', '0', 0, '0000-00-00 00:00:00', '', ''),
(32541908, 'eraw', 'awed', 'awed', 'serf', 'd', '0', 0, '0000-00-00 00:00:00', '', 'uploads/C60D75E9-E765-475C-AA1C-CD48FE8BA955.jpg'),
(32541909, 'ewe', 'Q3E', 'WRW4R', 'WER', 'w', '0', 0, '0000-00-00 00:00:00', '', ''),
(32541910, 'GBZ', 'WER', 'R', 'DRF', 'WER', '0', 0, '0000-00-00 00:00:00', '', ''),
(32541911, '', '', '', '', '', '0', 0, '0000-00-00 00:00:00', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `patientopdetails`
--

CREATE TABLE `patientopdetails` (
  `sno` int(11) NOT NULL,
  `pid` varchar(100) NOT NULL,
  `status` text NOT NULL,
  `Did` int(11) NOT NULL,
  `proc` text NOT NULL,
  `dtofproc` text NOT NULL,
  `chfcompliants` text NOT NULL,
  `hop` text NOT NULL,
  `cinhos` text NOT NULL,
  `treatmentgiven` text NOT NULL,
  `otdetails` text NOT NULL,
  `pmedicalhist` text NOT NULL,
  `dischargeadvice` text NOT NULL,
  `pimage` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patientopdetails`
--

INSERT INTO `patientopdetails` (`sno`, `pid`, `status`, `Did`, `proc`, `dtofproc`, `chfcompliants`, `hop`, `cinhos`, `treatmentgiven`, `otdetails`, `pmedicalhist`, `dischargeadvice`, `pimage`) VALUES
(9, '350003', 'inpatient', 0, 'tablets', 'aljdo nas', 'bgfvyh', 'mhg7uyhj', 'emkndhbknesb', 'k,djcm', 'ejqadnl', 'dejwdsn', ',djnm', 'uploads/Screenshot (3).png'),
(10, '350004', '', 0, '', '', '', '', '', '', '', '', '', ''),
(11, '350001', 'inpatient', 0, 'cold', '2023/07/21', 'heavy cold', 'nill', 'nill', 'breathing', 'nhutbsh', 'asndb', 'kjwe', ''),
(12, '350002', 'inpatient', 0, 'tablets', 'aljdo nas', 'bgfvyh', 'mhg7uyhj', 'emkndhbknesb', 'k,djcm', 'ejqadnl', 'dejwdsn', '', 'uploads/Profile1.jpg'),
(13, '', '', 0, '', '', '', '', '', '', '', '', '', ''),
(14, '192011', 'inpatient', 0, 'ankle sprain', '2024-03-12', 'ankle sprain', '', 'sdcf', 'Sedfw', 'sefa', 'fa', 'SDfrfeujrfhBK,FNA,EKJRNF', 'uploads/Profile1.jpg'),
(15, '192012', 'inpatient', 0, 'ankle sprain', '2024-03-12', 'ankle sprain', 'ajbd', 'sdcf', 'Sedfw', 'sefa', 'fa', 'SDfrfeujrfhBK,FNA,EKJRNF', 'uploads/Profile1.jpg'),
(16, 'Optional(\"123654\")', 'Optional(\"dfg\")', 0, 'Optional(\"drtger5t\")', 'Optional(\"drtger5t\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod aergtaert incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, et5ert cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, eerie cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do refgtsert tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magnaetgsdrt aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"1253\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do ertgse5teiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', ''),
(17, 'Optional(\"90009\")', 'Optional(\"\")', 0, 'Optional(\"\")', 'Optional(\"\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"1253\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'uploads/0F34101E-9877-4E12-9D91-8A3ED9D61CA3.jpg'),
(18, 'Optional(\"987654\")', 'Optional(\"gdfgdf\")', 0, 'Optional(\"gdfgdfgd\")', 'Optional(\"gdfgdfgd\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"1253\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'uploads/F85F9B82-1919-4B5F-B0DC-4C79E5E10FDD.jpg'),
(19, 'Optional(\"00999\")', 'Optional(\"\")', 0, 'Optional(\"\")', 'Optional(\"\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"1253\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'uploads/45FAA305-1708-4CD5-853D-74D342D7ABDD.jpg'),
(20, 'Optional(\"963852\")', 'Optional(\"dfgdfg\")', 0, 'Optional(\"dfgdfg\")', 'Optional(\"dfgdfg\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"1253\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'uploads/85A9E74D-3335-4EC4-AE92-674F2E6B0677.jpg'),
(21, 'Optional(\"008\")', 'Optional(\"\")', 0, 'Optional(\"\")', 'Optional(\"\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"1253\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'uploads/8B09165D-2D6A-4774-B4DB-A364B221FE15.jpg'),
(22, 'Optional(\"9999\")', 'Optional(\"\")', 0, 'Optional(\"\")', 'Optional(\"\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"1253\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'uploads/E2761740-CEC7-40AA-8A45-4FA03E4AE16C.jpg'),
(23, 'Optional(\"8888\")', 'Optional(\"DFGDFG\")', 0, 'Optional(\"DFDGDFGDFGDFG\")', 'Optional(\"DFDGDFGDFGDFG\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"1253\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', ''),
(24, 'Optional(\"5421\")', 'Optional(\"fyu8if\")', 0, 'Optional(\"yfu8ir\")', 'Optional(\"yfu8ir\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"1253\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', ''),
(25, '87354', 'inpatient', 0, 'ankle sprain', '2024-03-12', 'ankle sprain', 'ajbd', 'sdcf', 'Sedfw', 'sefa', 'fa', 'SDfrfeujrfhBK,FNA,EKJRNF', 'uploads/4A0932D8-369F-457D-B70D-CA31D91482D6.jpg'),
(26, 'Optional(\"1238\")', 'Optional(\"\")', 0, 'Optional(\"\")', 'Optional(\"\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"1253\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', ''),
(27, 'Optional(\"we’re\")', 'Optional(\"\")', 0, 'Optional(\"\")', 'Optional(\"\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"1253\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', ''),
(28, 'Optional(\"WER\")', 'Optional(\"\")', 0, 'Optional(\"\")', 'Optional(\"\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"1253\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', ''),
(29, 'Optional(\"21755\")', 'Optional(\"\")', 0, 'Optional(\"\")', 'Optional(\"\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', 'Optional(\"1253\")', 'Optional(\"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.\")', ''),
(31, '189076', 'the data pid 189076', 0, 'the data pid 189076', 'the data pid 189076', 'the data pid 189076', 'the data pid 189076', 'the data pid 189076', 'the data pid 189076', 'the data pid 189076', 'the data pid 189076', 'the data pid 189076', 'uploads/7A97CF2B-297D-464A-AD1D-25CD108ED851.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `SNO` int(11) NOT NULL,
  `questionText` longtext NOT NULL,
  `OptionA` text NOT NULL,
  `OptionB` text NOT NULL,
  `OptionC` text NOT NULL,
  `OptionD` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`SNO`, `questionText`, `OptionA`, `OptionB`, `OptionC`, `OptionD`) VALUES
(1, 'Range of Movements at the affected site?              ', 'Full range of movement', 'Movement against gravity', 'Movement eliminating gravity', 'No movement'),
(2, 'General Mobility and Dependency for day to day activities                                              ', 'Active mobilisation, independent', 'Mobilisation with assistance for long intervals', 'Walking with assistance for short intervals ', 'Difficulty in mobilisation and completely dependent '),
(3, 'Any discoloration or discharge from the affected site.                                                         ', 'NO DISCHARGE PRESENT', 'MILD/INTERMITTENT DISCHARGE PRESENT without fever', 'MILD/INTERMITTENT DISCHARGE PRESENT with     fever', 'ACTIVE DISCHARGE PRESENT '),
(4, 'Tingling sensation, itching or discomfort in the affected site.                                                ', 'NILL', 'ABNORMAL', 'SEVERE', ''),
(5, 'Drugs for pain relief', 'No pain relief reqired', 'pain relieved with prescribed medications', 'pain relieved not relieved with prescribed medications', 'severe pain inspite of medications'),
(6, 'Dressing at the operated site                                                               ', 'NO SOAKAGE', 'SOAKAGE PRESENT', '', ''),
(7, 'wound healing at the operated site                                                                ', 'Healthy', 'Unhealthy', '', ''),
(8, 'need for Physiotherapy and Rehabilitation', 'no reqirements for physio', 'Once a day/Twice a day    ', 'Thrice a day', 'total dependency for physio '),
(9, 'Outcome Post rehabilitation and physiotherapy exercises', 'excellent', 'good/better', 'satisfactory', 'bad/worse'),
(10, 'Diabetes under optimum control.', 'YES - <120\r\n', 'NO - 120-140 \r\n', 'Not applicable - >140\r\n', ''),
(11, 'Emotional well being- is there any Need for counselling and antidepressants', 'NO', 'YES', '', ''),
(12, 'Any obvious deformity at the affected site.', 'NO', 'YES', '', ''),
(13, 'Over all progress .', 'Excellent', 'BETTER', 'GOOD', 'BAD/worse'),
(14, 'swelling/edema at operated site?', 'no swelling', 'swelling without redness', 'swelling with rednesss', 'swelling with redness and discharge');

-- --------------------------------------------------------

--
-- Table structure for table `uploadimage`
--

CREATE TABLE `uploadimage` (
  `id` int(11) NOT NULL,
  `Userid` int(20) NOT NULL,
  `image` varchar(50) NOT NULL,
  `date` date DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `uploadimage`
--

INSERT INTO `uploadimage` (`id`, `Userid`, `image`, `date`) VALUES
(0, 20, '', '0000-00-00'),
(0, 20, '', '2024-01-25'),
(0, 20, 'videos/ppimage.jpeg', '2024-01-25');

-- --------------------------------------------------------

--
-- Table structure for table `user_responses`
--

CREATE TABLE `user_responses` (
  `usersrseponse` int(11) NOT NULL,
  `Pid` int(255) NOT NULL,
  `pconsultant` int(11) NOT NULL,
  `question1` text NOT NULL,
  `question2` text NOT NULL,
  `question3` text NOT NULL,
  `question4` text NOT NULL,
  `question12` text NOT NULL,
  `question5` text NOT NULL,
  `question6` text NOT NULL,
  `question7` text NOT NULL,
  `question8` text NOT NULL,
  `question9` text NOT NULL,
  `question10` text NOT NULL,
  `question11` text NOT NULL,
  `question13` text NOT NULL,
  `question14` text NOT NULL,
  `question15` text NOT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_responses`
--

INSERT INTO `user_responses` (`usersrseponse`, `Pid`, `pconsultant`, `question1`, `question2`, `question3`, `question4`, `question12`, `question5`, `question6`, `question7`, `question8`, `question9`, `question10`, `question11`, `question13`, `question14`, `question15`, `date`) VALUES
(1, 1234, 0, 'yes', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2023-12-13'),
(2, 1234, 0, 'yes', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2023-12-13'),
(3, 521478, 0, 'ed', 'edwe', 'ew', 'ewa', 'wed', 'ewa', 'we', 'wefc', 'wef', 'ewad', 'edfwa', 'wef', '', '', '', '2023-12-27'),
(12, 99999, 0, '5', '10', '15', '', '', '20', '', '5', '10', '15', '20', '', '5', '15', '20', '2024-02-24'),
(33, 350001, 0, '10', '5', '10', '15', '10', '15', '15', '10', '5', '20', '10', '10', '20', '5', '10', '2024-03-12'),
(40, 350001, 0, '15', '10', '10', '10', '10', '15', '10', '10', '20', '20', '10', '15', '20', '20', '10', '2024-03-15'),
(44, 350001, 0, '7', '5', '15', '15', '10', '10', '5', '10', '20', '5', '10', '15', '5', '5', '10', '2024-03-20'),
(45, 350001, 0, '4', '5', '10', '15', '10', '20', '15', '10', '20', '20', '15', '15', '20', '15', '5', '2024-03-22'),
(46, 350001, 0, '7', '5', '15', '20', '5', '15', '10', '10', '5', '20', '10', '10', '20', '5', '15', '2024-03-26'),
(50, 189076, 0, '5', '10', '5', '10', '10', '5', '10', '5', '10', '5', '10', '5', '5', '10', '5', '2024-03-28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appointmentID`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`Did`);

--
-- Indexes for table `medicalreports`
--
ALTER TABLE `medicalreports`
  ADD PRIMARY KEY (`sNo`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `patientopdetails`
--
ALTER TABLE `patientopdetails`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`SNO`);

--
-- Indexes for table `user_responses`
--
ALTER TABLE `user_responses`
  ADD PRIMARY KEY (`usersrseponse`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appointmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `Did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54324;

--
-- AUTO_INCREMENT for table `medicalreports`
--
ALTER TABLE `medicalreports`
  MODIFY `sNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32541912;

--
-- AUTO_INCREMENT for table `patientopdetails`
--
ALTER TABLE `patientopdetails`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `SNO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `user_responses`
--
ALTER TABLE `user_responses`
  MODIFY `usersrseponse` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
