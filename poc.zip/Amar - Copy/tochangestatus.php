<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["pid"])) {
    $pid = $_POST["pid"];
    $status = "approved";

    $conn = new mysqli("localhost", "root", "", "poc");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "UPDATE appointment SET status = '$status' WHERE pid = '$pid'";

    if ($conn->query($sql) === TRUE) {
        $response = array('status' => 'success', 'message' => 'Data updated successfully');
        echo json_encode($response);
    } else {
        $response = array('status' => 'failure', 'message' => 'Data not updated');
        echo json_encode($response);
    }

    $conn->close();
} else {
    $response = array('status' => 'failure', 'message' => 'Invalid or missing PID value');
    echo json_encode($response);
}
?>
