<?php
if ($_SERVER["REQUEST_METHOD"] == "POST")
error_reporting(E_ALL);
ini_set('display_errors', 1);
    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "poc");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    // Get input data from the application
    $targetDirectory = "uploads/";
    function uploadImages($fieldName) {
        global $targetDirectory;
        $result = [];
        if (isset($_FILES[$fieldName]) && is_array($_FILES[$fieldName]["name"])) {
            foreach ($_FILES[$fieldName]["name"] as $key => $value) {
                $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"][$key]);
                if (move_uploaded_file($_FILES[$fieldName]["tmp_name"][$key], $targetFile)) {
                    $result[] = $targetFile;
                } else {
                    $result[] = null;
                }
            }
        } elseif (isset($_FILES[$fieldName])) {
            // If there's only one file, treat it as an array
            $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"]);
            if (move_uploaded_file($_FILES[$fieldName]["tmp_name"], $targetFile)) {
                $result[] = $targetFile;
            } else {
                $result[] = null;
            }
        }
        return $result;
    }

    $pimage = isset($_FILES["pimage"]) ? uploadImages("pimage") : [];
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pid = $_POST['pid'];
    $status = $_POST['status'];
    $proc = $_POST['proc'];
    $dtofproc = $_POST['dtofproc'];
    $chfcompliants = $_POST['chfcompliants'];
    $hop = $_POST['hop'];
    $cinhos = $_POST['cinhos'];
    $treatmentgiven = $_POST['treatmentgiven'];
    $otdeatils = $_POST['otdeatils'];
    $pmedicalhist = $_POST['pmedicalhist'];
    $dischargeadvice = $_POST['dischargeadvice'];
        $diagonsis = $_POST['diagonsis'];
    // Check if the user_id already exists in patientopdetails
    $check_sql = "SELECT pid FROM patientopdetails WHERE pid = '$pid'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows > 0) {
        // User already exists
        $response = array('status' => false, 'message' => 'User already exists.');
        echo json_encode($response);
    } else {
        // Process the image paths
       $imagePaths = implode(",", array_filter($pimage));

        // Insert data into the patientopdetails table
        $sql = "INSERT INTO patientopdetails (pid, status, proc, dtofproc, chfcompliants, hop, diagonsis, cinhos, treatmentgiven, otdetails, pmedicalhist, dischargeadvice, pimage)
        VALUES ('$pid', '$status', '$proc', '$dtofproc', '$chfcompliants', '$hop', '$diagonsis', '$cinhos', '$treatmentgiven', '$otdeatils', '$pmedicalhist', '$dischargeadvice', '$imagePaths')";



        if ($conn->query($sql) === TRUE) {
            // Successful insertion
            $response = array('status' => true, 'message' => 'Patient registration successful.');
            echo json_encode($response);
        } else {
            // Error in database insertion
            $response = array('status' => false, 'message' => 'Error: ' . $conn->error);
            echo json_encode($response);
        }
    }
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => false, 'message' => 'Invalid request method.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
