<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = new mysqli("localhost", "root", "", "poc");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $pid = $conn->real_escape_string($_POST["pid"]);
    $Did = $conn->real_escape_string($_POST["Did"]);
    $docname = $conn->real_escape_string($_POST["docname"]);
    $date = $conn->real_escape_string($_POST["date"]);
    $slot = $conn->real_escape_string($_POST["slot"]);
    $reason = $conn->real_escape_string($_POST["reason"]); // New line to get the reason

    // Add a new record with 'pending' status
    $addAppointmentQuery = "INSERT INTO appointment (pid, Did, docname, date, slot, status, reason) VALUES ('$pid', '$Did', '$docname', '$date', '$slot', 'pending', '$reason')";

    if ($conn->query($addAppointmentQuery)) {
        $conn->commit(); // Commit changes
        $response = array('status' => true, 'message' => 'Appointment added successfully');
    } else {
        $response = array('status' => false, 'message' => 'Error adding appointment: ' . $conn->error);
    }

    echo json_encode($response);

    $conn->close();
} else {
    $response = array('status' => false, 'message' => 'Invalid request method');
    echo json_encode($response);
}
?>
