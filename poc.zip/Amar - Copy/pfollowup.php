<?php

$conn = new mysqli("localhost", "root", "", "poc");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get user input for pid and date (assuming it comes from a form)
    $patientID = $_POST['pid']; // Replace 'patient_id' with the actual input field name
    $date = $_POST['date']; // Replace 'date' with the actual input field name

    // Query to retrieve patient responses for a specific patient ID on a specific date using prepared statements
    $sql = "SELECT updatedmed,addvice FROM medicalreports WHERE pid = ? AND date = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("is", $patientID, $date); // 'i' for integer, 's' for string; adjust as per column types
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $response = array('status' => 'success', 'data' => array());
            while ($row = $result->fetch_assoc()) {
                $response['data'][] = $row;
            }
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            echo json_encode(['status' => 'error', 'message' => "No responses found for Patient ID $patientID on $date."]);
        }

        $stmt->close();
    } else {
        echo json_encode(['status' => 'error', 'message' => "Error in the prepared statement."]);
    }
}

$conn->close();
?>
