<?php
session_start();

$response = array(); // Initialize an empty associative array to store response data

$conn = new mysqli("localhost", "root", "", "poc");

if ($conn->connect_error) {
    $response['status'] = false;
    $response['message'] = "Connection failed: " . $conn->connect_error;
} else {
    // Assuming you have a variable $pid containing the patient ID from the POST request
    $pid = isset($_POST['pid']) ? $_POST['pid'] : null;

    if ($pid !== null) {
        $tableName = "appointment";

        // Retrieve data from the appointment table for a specific patient ID and today to upcoming days
        $sql = "SELECT * FROM $tableName WHERE pid = ? AND DATE(date) >= CURDATE() ORDER BY date";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $pid); // Assuming 'pid' is an integer, adjust the type if necessary
        $stmt->execute();
        
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $appointments = array(); // Initialize an array to store appointment data

            while ($row = $result->fetch_assoc()) {
                $appointmentData = array(
                    'status' => $row['status'],
                    'docname' => $row['docname'],
                    'date' => $row['date'],
                    'slot' => $row['slot']
                );

                $appointments[] = $appointmentData;
            }

            // Remove duplicate appointments
            $appointments = array_unique($appointments, SORT_REGULAR);

            $response['status'] = true;
            $response['appointments'] = array_values($appointments); // Re-index array after removing duplicates
        } else {
            $response['status'] = false;
            $response['message'] = "No data found in the $tableName table for pid: $pid";
        }

        $stmt->close();
    } else {
        $response['status'] = false;
        $response['message'] = "Missing or invalid 'pid' parameter in the POST request";
    }

    $conn->close();
}

// Send JSON response
sendResponse($response);

function sendResponse($response) {
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
}
?>
