<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "poc");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get input data from the application
    $pid = $_POST['pid'];

    // Select data from the doctor_profile table based on the provided userid
    $select_sql = "SELECT dtofproc FROM patientopdetails WHERE pid = '$pid'";
    $select_result = $conn->query($select_sql);

    if ($select_result->num_rows > 0) {
        // User found, fetch all rows
        $user_data = array();
        while ($row = $select_result->fetch_assoc()) {
            $user_data[] = $row;
        }

        $response = array('status' => true, 'message' => 'User details retrieved successfully.', 'data' => $user_data);
        echo json_encode($response);
    } else {
        // User not found
        $response = array('status' => false, 'message' => 'User not found.');
        echo json_encode($response);
    }

    // Close the database connection
    $conn->close();
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => false, 'message' => 'Invalid request method.');
    echo json_encode($response);
}
?>
