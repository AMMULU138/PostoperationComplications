<?php
// Include your database connection code here (e.g., db_conn.php)
$conn = new mysqli("localhost", "root", "", "poc");

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if 'userid' is set
    if (isset($_POST['pid'])) {
        $pid = $_POST['pid'];

        $sql = "SELECT * FROM patientopdetails WHERE pid = '$pid'";  // Add the condition for the user ID
        
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Fetch all rows as an associative array
            $viewpatientoperationaldetails = array();
            while ($row = $result->fetch_assoc()) {
                $viewpatientoperationaldetails[] = $row;
            }

            // Return all entries for the given Userid as JSON with proper Content-Type header
            header('Content-Type: application/json');
            echo json_encode(array('status' => true, 'viewpatientoperationaldetails' => $viewpatientoperationaldetails));
        } else {
            // No patient found with the provided Userid
            header('Content-Type: application/json');
            echo json_encode(array('status' => false, 'message' => 'No advice found for the provided Userid.'));
        }
    } else {
        // 'userid' not provided
        header('Content-Type: application/json');
        echo json_encode(array('status' => false, 'message' => 'Please provide a userid.'));
    }
} else {
    // Handle non-POST requests (e.g., return an error response)
    header('Content-Type: application/json');
    echo json_encode(array('status' => false, 'message' => 'Invalid request method.'));
}

// Close the database connection
$conn->close();
?>

