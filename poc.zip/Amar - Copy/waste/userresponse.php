<?php
// Include database connection file
$conn = new mysqli("localhost", "root", "", "poc");
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the form is submitted and if "pid" is set in POST data
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["pid"])) {
    $pid = $_POST["pid"];
    $responses = [];

    // Process each question
    for ($i = 1; $i <= 15; $i++) {
        $questionkey = 'question' . $i;
        if (isset($_POST[$questionkey])) {
            $responses["question$i"] = $_POST[$questionkey];
        } else {
            // Assign a default value if the question is not set
            $responses["question$i"] = ''; // You can set any default value here
        }
    }

    // Insert data into the "user_responses" table with individual columns for each question
    $sql = "INSERT INTO user_responses (pid, question1, question2, question3, question4, question5, question6, question7, question8, question9, question10, question11, question12) 
    VALUES ('$pid', '{$responses['question1']}', '{$responses['question2']}', '{$responses['question3']}', '{$responses['question4']}', '{$responses['question5']}', '{$responses['question6']}', '{$responses['question7']}', '{$responses['question8']}', '{$responses['question9']}', '{$responses['question10']}', '{$responses['question11']}', '{$responses['question12']}')";


    if ($conn->query($sql) === TRUE) {
        echo "User answers inserted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Error: 'pid' is not set in the POST data";
}

// Close the database connection
$conn->close();
?>
