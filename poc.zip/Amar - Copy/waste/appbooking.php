<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "poc");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Assuming you receive the data from a form
    $selectedSlot = $_POST['selectedSlot'];  // Make sure to validate and sanitize user input
    $Did = $_POST['Did'];                // Make sure to validate and sanitize user input
    $docname = $_POST['docname'];          // Make sure to validate and sanitize user input
    $date = $_POST['date'];                   // Make sure to validate and sanitize user input
    $pid = $_POST['pid'];  // Make sure to validate and sanitize user input

    // Validate that the selected slot is one of the allowed values
    $allowedSlots = ['morning', 'afternoon', 'evening'];
    if (!in_array($selectedSlot, $allowedSlots)) {
        // Output error message in JSON format if the selected slot is not allowed
        $response = ['success' => false, 'message' => 'Invalid slot selected'];
        echo json_encode($response);
        exit();  // Terminate the script
    }

    // Insert all the data into the appointments table, including the "issue" column
    $status = 'pending';  // Set the default status to pending
    $sql = "INSERT INTO appointment (slot, Did, docname, date, pid, status) 
            VALUES ('$selectedSlot', '$Did', '$docname', '$date', '$pid', '$status')";

    if ($conn->query($sql) !== TRUE) {
        echo "Error: " . $sql . "<br>" . $conn->error;
    } else {
        // Output success message in JSON format
        $response = ['success' => true, 'message' => 'Appointment inserted successfully'];
        echo json_encode($response);
    }

    // Close the database connection
    $conn->close();
}
?>
