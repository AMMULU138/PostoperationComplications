<?php
// Include database connection file
$conn = new mysqli("localhost", "root", "", "poc");

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Retrieve data from the form
    $qcontent = $_POST["qcontent"];
    
    $qop1 = $_POST["qop1"];
    $qop2 = $_POST["qop2"];
    $qop3= $_POST["qop3"];
    $qop4 = $_POST["qop4"];
    $qop5 = $_POST["qop5"];
    $qop6 = $_POST["qop6"];
      
    // Insert data into the "questions" table
    $sql = "INSERT INTO Questionnarie (qcontent, qop1, qop2, qop3, qop4, qop5, qop6) 
            VALUES ('$qcontent', '$qop1', '$qop2', '$qop3', '$qop4', '$qop5', '$qop6')";

    if ($conn->query($sql) === TRUE) {
        echo "Data inserted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>