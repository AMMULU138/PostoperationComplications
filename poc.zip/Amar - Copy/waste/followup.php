<?php
if (isset($_POST['Pid'])) {
    $pid_value = $_POST['Pid'];

    // Database connection
    $conn = new mysqli("localhost", "root", "", "poc");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $pid_value = $conn->real_escape_string($pid_value);

    $sql = "SELECT * FROM `user_responses` WHERE `Pid` = '$pid_value'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $response = array();
        while ($row = $result->fetch_assoc()) {
            $response[] = $row;
        }
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        echo "No results found for PID: " . $pid_value;
    }

    $conn->close();
} else {
    echo "PID not provided in the POST data.";
}
?>
