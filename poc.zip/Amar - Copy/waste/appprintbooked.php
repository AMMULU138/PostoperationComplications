<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "poc");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $data = array();
    $Did = $_POST["Did"];
    // Perform the database query to select data from the appointment table
    $sql = "SELECT * FROM appointment WHERE status='pending' and Did = '$Did'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        // Return the data as JSON
        echo json_encode($data, JSON_PRETTY_PRINT);
    } else {
        $response = array('status' => 'failure', 'message' => 'No pending appointments');
        echo json_encode($response);
    }

    $conn->close();
} else {
    $response = array('status' => 'failure', 'message' => 'Invalid request method');
    echo json_encode($response);
}
?>
