<?php
$month = date("n"); // Current month as a number without leading zeros
$year = date("Y"); // Current year

// Get the number of days in the current month
$days_in_month = cal_days_in_month(CAL_GREGORIAN, $month, $year);

// Get the first day of the month
$first_day = date("N", mktime(0, 0, 0, $month, 1, $year)); // N: 1 (for Monday) to 7 (for Sunday)

// Create an array of days of the week
$daysOfWeek = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

// Create an array to hold calendar data
$calendarData = [
    'daysOfWeek' => $daysOfWeek,
    'dates' => []
];

// Fill in the empty cells for the days before the first day of the month
for ($i = 1; $i < $first_day; $i++) {
    $calendarData['dates'][] = null;
}

// Fill in the days of the month
for ($day = 1; $day <= $days_in_month; $day++) {
    $date = $year . '-' . str_pad($month, 2, '0', STR_PAD_LEFT) . '-' . str_pad($day, 2, '0', STR_PAD_LEFT);
    $calendarData['dates'][] = ['date' => $date, 'day' => $day];
}

// Fill in the remaining empty cells after the last day of the month
if (($day + $first_day - 1) % 7 != 0) {
    for ($i = 1; $i <= 7 - (($day + $first_day - 1) % 7); $i++) {
        $calendarData['dates'][] = null;
    }
}

// Encode the calendar data to JSON
$jsonCalendar = json_encode($calendarData);

// Output the JSON data
header('Content-Type: application/json');
echo $jsonCalendar;
?>
