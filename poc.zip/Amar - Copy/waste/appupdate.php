<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "poc");

// Check if the request method is GET to process the URL parameter
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Check if the patient_id parameter exists in the URL
    if (isset($_GET["Pid"])) {
        $Pid = $_GET["Pid"];

        // Update the appointment status to 'Approved' using prepared statements
        $sql = "UPDATE appointment SET status='Approved' WHERE Pid=?";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param('s', $Pid);

            if ($stmt->execute()) {
                $response = array('status' => 'success', 'message' => 'Status updated successfully');
                echo json_encode($response);
            } else {
                $response = array('status' => 'failure', 'message' => 'Failed to execute statement');
                echo json_encode($response);
            }
        } else {
            $response = array('status' => 'failure', 'message' => 'Failed to prepare statement');
            echo json_encode($response);
        }
    } else {
        $response = array('status' => 'failure', 'message' => 'Missing required "pid" parameter');
        echo json_encode($response);
    }
} else {
    $response = array('status' => 'failure', 'message' => 'Invalid request method');
    echo json_encode($response);
}
?>
