<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming the slot value is sent via POST request
    $slot = $_POST['slot'] ?? '';

    // Validate $slot if needed

    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "poc");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the query using a prepared statement
    $stmt = $conn->prepare("SELECT pid, issue, slot FROM appointment WHERE status = 'pending'");
    $stmt->bind_param("s", $slot);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if there are results
    if ($result->num_rows > 0) {
        // Output data of each row
        while ($row = $result->fetch_assoc()) {
            echo "ID: " . $row["pid"] . " - issue: " . $row["issue"] . " - Slot: " . $row["slot"] . "<br>";
        }
    } else {
        echo "0 results";
    }

    // Close the prepared statement, close the database connection
    $stmt->close();
    $conn->close();
}
?>
