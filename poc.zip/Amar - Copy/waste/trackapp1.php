<?php
session_start();

$response = array(); // Initialize an empty associative array to store response data

// Assuming 'pid' is passed in the POST request
$pid = isset($_POST['pid']) ? $_POST['pid'] : null;

if (!$pid) {
    $response['status'] = false;
    $response['message'] = "Missing 'pid' parameter";
    sendResponse($response);
    exit;
}

$conn = new mysqli("localhost", "root", "", "poc");

if ($conn->connect_error) {
    $response['status'] = false;
    $response['message'] = "Connection failed: " . $conn->connect_error;
} else {
    $tableName = "appointment";
    
    // Retrieve 'docname', 'status', and 'date' for the given 'pid'
    $sql = "SELECT docname, status, date FROM appointment WHERE pid = ?";
    
    // Using prepared statement to avoid SQL injection
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $pid);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $appointments = array(); // Initialize an array to store appointment data

        while ($row = $result->fetch_assoc()) {
            $appointmentData = array(
                'docname' => $row['docname'],
                'status' => $row['status'],
                'date' => $row['date'],
            );

            $appointments[] = $appointmentData;
        }

        $response['status'] = true;
        $response['appointments'] = $appointments;
    } else {
        $response['status'] = false;
        $response['message'] = "No data found for the given 'pid'";
    }

    $stmt->close();
    $conn->close();
}

// Send JSON response
sendResponse($response);

function sendResponse($response) {
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
}
?>
