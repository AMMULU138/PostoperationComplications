<?php
if ($_SERVER["REQUEST_METHOD"] == "POST")
    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "poc");

 // Check if the request method is POST and the request contains a JSON payload
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $data = json_decode(file_get_contents('php://input'), true);

    // Check if the required field "patient_id" is present in the JSON data
    if (isset($_POST["patient_id"])) {
        $patient_id = $_POST["patient_id"];

        // Perform the deletion
        $sql = "DELETE FROM appointment WHERE patient_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s', $patient_id);

        // Execute the query
        if ($stmt->execute()) {
            $response = array('status' => 'success', 'message' => 'Data deleted successfully');
            echo json_encode($response);
        } else {
            $response = array('status' => 'failure', 'message' => 'Data not deleted');
            echo json_encode($response);
        }
    } else {
        $response = array('status' => 'failure', 'message' => 'Missing required field "patient_id" in JSON data');
        echo json_encode($response);
    }
} else {
    $response = array('status' => 'failure', 'message' => 'Invalid request method');
    echo json_encode($response);
}

header('Content-Type: application/json');
?>
