<?php
// Check if 'pid' parameter is set in the request
$conn = new mysqli("localhost", "root", "", "poc");
error_reporting(E_ALL);
ini_set('display_errors', 1);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
header('Content-Type: application/json; charset=UTF-8');
$response = array();

if (isset($_POST['pid']))  {
  
    $pid = $_POST['pid'];

    // Use prepared statement to prevent SQL injection
    $sql = "SELECT date
            FROM medicalreports 
            WHERE pid = ? AND updatedmed != 'Nill'"; // Adjusted query to select only 'date'
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $pid); // Changed to one "s" for one parameter
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $response['status'] = "success";
        $response['message'] = "Data found";
        $response['data'] = array();

        while ($row = $result->fetch_assoc()) {
            // Retrieve 'date' column
            $data = array(
                "date" => $row['date']
            );

            array_push($response['data'], $data);
        }
    } else {
        $response['status'] = "error";
        $response['message'] = "No results found for the given PID or 'updatedmed' is not 'Nill'";
    }
} else {
    // If 'pid' parameter is not set, handle the error accordingly
    $response['status'] = "error";
    $response['message'] = "'pid' parameter is required in the request.";
}

$conn->close();

// Convert PHP array to JSON and output the response
echo json_encode($response);
?>
