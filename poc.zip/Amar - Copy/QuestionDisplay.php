<?php

$conn = new mysqli("localhost", "root", "", "poc");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if answers are already submitted for the user
$pid = isset($_POST['pid']) ? $_POST['pid'] : null;
$response = [
    "status" => "",
    "message" => ""
];

if ($pid) {
    $checkAnswersQuery = "SELECT * FROM user_responses WHERE pid = '$pid' AND date = CURDATE()";
    $checkResult = $conn->query($checkAnswersQuery);

    // If answers are already submitted, set status and message
    if ($checkResult->num_rows > 0) {
        $conn->close();
        $response["status"] = "error";
        $response["message"] = "Answers already submitted for this user.";
        echo json_encode($response);
        exit;
    }
}

// Fetch questions from the database
// Fetch questions from the database
$sql = "SELECT * FROM questions";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Create an array to store questions and options
    $questionsArray = array();

    while ($row = $result->fetch_assoc()) {
        // Create an array for each question
        $questionData = array(
            'questionText' => $row['questionText'],
        );

        // Include 'OptionA' even if not present in the database
        $questionData['OptionA'] = isset($row['OptionA']) ? $row['OptionA'] : null;

        // Determine the number of options for the current question
        for ($i = 'B'; $i <= 'D'; $i++) {
            $optionKey = 'Option' . $i;
            if (isset($row[$optionKey])) {
                $questionData[$optionKey] = $row[$optionKey];
            }
        }

        // Add the question data to the main array
        $questionsArray[] = $questionData;
    }

    // Close the database connection
    $conn->close();

    // Set status and message
    $response["status"] = "success";
    $response["message"] = "Questions fetched successfully.";
    $response["data"] = $questionsArray;

    // Output the JSON data
    header('Content-Type: application/json');
    echo json_encode($response, JSON_PRETTY_PRINT);
} else {
    // If no questions are found, set status and message
    $response["status"] = "error";
    $response["message"] = "No questions found in the database.";
    echo json_encode($response);
}

?>
