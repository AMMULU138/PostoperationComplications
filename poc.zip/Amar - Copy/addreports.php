<?php
// Include database connection file
$conn = new mysqli("localhost", "root", "", "poc");
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Include your database configuration

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming you have form data or variables for advice, updated medication, and patient ID
    $addvice = $_POST['addvice']; // Fixed variable name
    $updatedmed = $_POST['updatedmed']; // Replace with your actual form field name
    $pid = $_POST['pid']; // Replace with your actual form field name
    $date = $_POST['date'];



    // SQL query to insert data into the medical reports table
    $insertSql = "INSERT INTO medicalreports (addvice, updatedmed, pid, date) VALUES ('$addvice', '$updatedmed', '$pid', '$date')";

    $response = array();

    if ($conn->query($insertSql) === TRUE) {
        $response['status'] = true;
        $response['message'] = "Record added successfully";
    } else {
        $response['status'] = false;
        $response['message'] = "Error inserting record in medicalreports table: " . $conn->error;
    }

    // Send the response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>

