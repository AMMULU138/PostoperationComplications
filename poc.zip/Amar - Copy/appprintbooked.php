<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "poc");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $data = array();

    // Assuming "did" is a column in the appointment table
    // Modify the value of $did_param according to your needs
    $did_param = isset($_POST['Did']) ? $conn->real_escape_string($_POST['Did']) : '';

    // Validate input (e.g., check if $did_param is not empty, etc.)
    if (empty($did_param)) {
        $response = array('status' => 'false', 'message' => 'Invalid input');
        echo json_encode($response, JSON_PRETTY_PRINT);
        exit; // Stop execution
    }

    // Prepare SQL statement
    $sql = "SELECT * FROM appointment WHERE status='pending' AND Did = ? AND DATE(date) >= CURDATE() ORDER BY date";
    $stmt = $conn->prepare($sql);

    // Bind parameters
    $stmt->bind_param("s", $did_param);

    // Execute query
    if ($stmt->execute()) {
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }

            // Return the data along with status as true
            $response = array('status' => 'true', 'data' => $data);
            echo json_encode($response, JSON_PRETTY_PRINT);
        } else {
            // No pending appointments found
            $response = array('status' => 'false', 'message' => 'No pending appointments for the specified DID');
            echo json_encode($response, JSON_PRETTY_PRINT);
        }
    } else {
        // Error handling
        $response = array('status' => 'false', 'message' => 'Error executing the query');
        echo json_encode($response, JSON_PRETTY_PRINT);
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    // Invalid request method
    $response = array('status' => 'false', 'message' => 'Invalid request method');
    echo json_encode($response, JSON_PRETTY_PRINT);
}
?>
