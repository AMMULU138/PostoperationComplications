<?php
// Include database connection file
$conn = new mysqli("localhost", "root", "", "poc");
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Initialize response array
$response = [
    "status" => "",
    "message" => ""
];

// Check if the form is submitted and if "pid" is set in POST data
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["pid"])) {
    $pid = $_POST["pid"];

    // Check if answers are already submitted for the user
    $checkAnswersQuery = "SELECT * FROM user_responses WHERE pid = '$pid' AND date = CURDATE()";
    $checkResult = $conn->query($checkAnswersQuery);

    // If answers are already submitted, set status and message
    if ($checkResult->num_rows > 0) {
        $response["status"] = "error";
        $response["message"] = "Answers already submitted for this user.";
    } else {
        $responses = [];

        // Flag to track if responses for all 15 questions are provided
        $allResponsesProvided = true;

        // Process each of the 15 questions
        for ($i = 1; $i <= 15; $i++) {
            $questionKey = 'question' . $i;
            if (isset($_POST[$questionKey])) {
                $responses[$questionKey] = $_POST[$questionKey];
            } else {
                // If any question response is missing, set flag to false
                $allResponsesProvided = false;
                break;
            }
        }

        // Check if responses for all 15 questions are provided
        if ($allResponsesProvided) {
            // Add the current date to the responses array
            $responses['date'] = date('Y-m-d'); // Adjust the date format if needed

            // Construct the SQL query with individual columns for each question
            $columns = implode(', ', array_keys($responses));
            $values = "'" . implode("', '", $responses) . "'";
            $sql = "INSERT INTO user_responses (pid, $columns) VALUES ('$pid', $values)";

            if ($conn->query($sql) === TRUE) {
                // Database insertion successful
                $response["status"] = true;
                $response["message"] = "User responses for all 15 questions inserted successfully";
            } else {
                // Database insertion failed
                $response["status"] = false;
                $response["message"] = "Error inserting data into the database: " . $conn->error;
            }
        } else {
            // If responses for any question are missing, set the error status
            $response["status"] = false;
            $response["message"] = "Responses for all 15 questions are mandatory.";
        }
    }
} else {
    // If "pid" is not set in the POST data, set the error status
    $response["status"] = false;
    $response["message"] = "'pid' is not set in the POST data";
}

// Output the JSON string
echo json_encode($response);

// Close the database connection
$conn->close();
?>

