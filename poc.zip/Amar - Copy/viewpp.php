<?php
// Include your database connection code here (e.g., db_conn.php)
$conn = new mysqli("localhost", "root", "", "poc");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['pid'])) {
        $pid = $_POST['pid'];

        $sql = "SELECT pid, pname, pgender, pconsultant, paddress, pmail, ppimage FROM patient WHERE pid = '$pid'";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $viewpatientpersonaldetails = array();
            while ($row = $result->fetch_assoc()) {
                // Create an associative array containing the specific fields
                $patientData = array(
                    "pid" => $row["pid"],
                    "pname" => $row["pname"],
                    "pgender" => $row["pgender"],
                    "pconsultant" => $row["pconsultant"],
                    "paddress" => $row["paddress"],
                    "pmail" => $row["pmail"],
                    "ppimage" => $row["ppimage"]
                );

                $viewpatientpersonaldetails[] = $patientData;
            }

            // Return specific fields for the given Userid as JSON
            header('Content-Type: application/json');
            echo json_encode(array('status' => true, 'viewpatientpersonaldetails' => $viewpatientpersonaldetails));
        } else {
            // No patient found with the provided Userid
            header('Content-Type: application/json');
            echo json_encode(array('status' => false, 'message' => 'No advice found for the provided Userid.'));
        }
    } else {
        // 'userid' not provided
        header('Content-Type: application/json');
        echo json_encode(array('status' => false, 'message' => 'Please provide a userid.'));
    }
} else {
    // Handle non-POST requests (e.g., return an error response)
    header('Content-Type: application/json');
    echo json_encode(array('status' => false, 'message' => 'Invalid request method.'));
}

$conn->close();
?>
