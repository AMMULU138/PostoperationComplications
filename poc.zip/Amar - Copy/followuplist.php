<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$response = array();

$conn = new mysqli("localhost", "root", "", "poc");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    // Sanitize and validate $data as needed

    // Updated SQL query to include the condition for PID and date in both tables
    $sql = "SELECT ur.pid, ur.date
            FROM user_responses AS ur
            WHERE EXISTS (
                SELECT 1
                FROM user_responses AS mr
                WHERE ur.pid = mr.pid AND ur.date = mr.date
            ) AND EXISTS (
                SELECT 1
                FROM excercise_status AS es
                WHERE ur.pid = es.pid AND ur.date = es.date
            ) AND NOT EXISTS (
                SELECT 1
                FROM medicalreports AS mr
                WHERE ur.pid = mr.pid AND ur.date = mr.date
            )";

    // Updated SQL query
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $response["status"] = "success";
            $response["message"] = "Data retrieved successfully";
            $response['data'] = array();
            while ($row = $result->fetch_assoc()) {
                $patientData = array(
                    "pid" => $row["pid"],
                    "date" => $row["date"], // Added 'date' column
                    // Add other fields as needed
                );

                array_push($response['data'], $patientData);
            }
        } else {
            $response["status"] = "error";
            $response["message"] = "No results found";
        }

        $stmt->close();
    } else {
        $response["status"] = "error";
        $response["message"] = "Error preparing statement: " . $conn->error;
    }
} else {
    $response["status"] = "error";
    $response["message"] = "Invalid request method";
}

$conn->close();
echo json_encode($response, JSON_PRETTY_PRINT);
?>

