<?php
// Include database connection file
$conn = new mysqli("localhost", "root", "", "poc");
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Include your database configuration

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming you have form data or variables for pid and date
    $pid = $_POST['pid']; // Replace with your actual form field name
    $date = $_POST['date'];

    $selectSql = "SELECT * FROM excercise_status WHERE pid = '$pid' AND date = '$date'";
    $result = $conn->query($selectSql);

    $response = array();

    if ($result->num_rows > 0) {
        // Data found for the provided pid and date
        $row = $result->fetch_assoc();
        $response['status'] = true;
        $response['message'] = "Data found";
       
  

        $response['data'] = $row;

    } else {
        // No data found for the provided pid and date
        $response['status'] = false;
        $response['message'] = "No data found for the provided PID and date";
    }

    // Send the response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
