<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "poc");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $data = array();

    // Assuming "Did" is a column in the appointment table
    // Modify the value of $did_param according to your needs
    $did_param = $_POST['Did'] ?? ''; // Adjust the name accordingly

    // Prepare SQL statement
    $sql = "SELECT * FROM appointment WHERE status='approved' AND Did = ? AND DATE(date) >= CURDATE() ORDER BY date";
    $stmt = $conn->prepare($sql);

    // Bind parameters and execute query
    $stmt->bind_param("s", $did_param);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check for results
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        // Return the data as JSON
        $response = array('status' => true, 'data' => $data);
        echo json_encode($response, JSON_PRETTY_PRINT);
    } else {
        $response = array('status' => false, 'message' => 'No approved appointments for the specified Did');
        echo json_encode($response, JSON_PRETTY_PRINT);
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    $response = array('status' => false, 'message' => 'Invalid request method');
    echo json_encode($response, JSON_PRETTY_PRINT);
}
?>
