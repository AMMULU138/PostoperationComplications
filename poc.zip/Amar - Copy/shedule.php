<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "poc";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Use $_POST to retrieve Doctor ID if set
$Did = isset($_POST["Did"]) ? $conn->real_escape_string($_POST["Did"]) : null;

if ($Did === null) {
    echo "Doctor ID is not set.";
    exit;
}

$sql = "SELECT appointment.appointmentID, appointment.Pid, appointment.Did, appointment.date, appointment.slot, appointment.status
        FROM appointment
        WHERE appointment.Did = '$Did' AND DATE(appointment.date) >= CURDATE()
        ORDER BY appointment.date ASC, appointment.slot ASC";


$result = $conn->query($sql);

if ($result) {
    $response = array(); // Initialize an array to store the response

    if ($result->num_rows > 0) {
        $appointmentsArray = array(); // Initialize an array to store all appointments

        while ($row = $result->fetch_assoc()) {
            $formattedAppointment = array(
                "pid" => $row["Pid"],
                "day" => date('l', strtotime($row["date"])),
                "date" => $row["date"],
                "slot" => $row["slot"]
            );

            // Add each formatted appointment to the array
            $appointmentsArray[] = $formattedAppointment;
        }

        $response['status'] = true;
        $response['appointments'] = $appointmentsArray;

        // Encode the entire response array as JSON and echo it
        echo json_encode($response, JSON_PRETTY_PRINT) . PHP_EOL;
    } else {
        $response['status'] = "No appointments found";
        
        // Encode the response array as JSON and echo it
        echo json_encode($response, JSON_PRETTY_PRINT) . PHP_EOL;
    }
} else {
    $response['status'] = "Query failed: " . $conn->error;

    // Encode the response array as JSON and echo it
    echo json_encode($response, JSON_PRETTY_PRINT) . PHP_EOL;
}

$conn->close();
?>
