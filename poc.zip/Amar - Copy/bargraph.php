<?php
// Check if 'pid' and 'date' parameters are set in the URL
$conn = new mysqli("localhost", "root", "", "poc");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$response = array();

if (isset($_POST['pid']) && isset($_POST['date'])) {
    // Retrieve the 'pid' and 'date' parameter values
    $pid = $_POST['pid'];
    $date = $_POST['date'];

    $sql = "SELECT * FROM user_responses WHERE pid = ? AND `date` = ?";
    $stmt = mysqli_prepare($conn, $sql);

    // Bind parameters
    mysqli_stmt_bind_param($stmt, "ss", $pid, $date);

    // Execute the prepared statement
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    if ($result->num_rows > 0) {
        $response['status'] = "success";
        $response['message'] = "Data found";
        $response['quesData'] = array(); // Array to store questions

        while ($row = $result->fetch_assoc()) {
            if (isset($row["pid"])) {
                $response['pid'] = strval($row["pid"]);
            }

            // Add 15 questions to the quesData array
            for ($i = 1; $i <= 15; $i++) {
                $questionKey = "question" . $i;
                array_push($response['quesData'], $row[$questionKey]);
            }
        }
    } else {
        $response['status'] = "error";
        $response['message'] = "No results found";
    }

    // Close the statement
    mysqli_stmt_close($stmt);
} else {
    // If 'pid' or 'date' parameters are not set, handle the error accordingly
    $response['status'] = "error";
    $response['message'] = "'pid' or 'date' parameter not found in the URL.";
}

$conn->close();

// Convert PHP array to JSON and output the response
echo json_encode($response);
?>
