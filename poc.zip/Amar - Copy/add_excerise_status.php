<?php
// Include database connection file
$conn = new mysqli("localhost", "root", "", "poc");
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Include your database configuration

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming you have form data or variables for exercises and reasons
    $pid = $_POST['pid']; // Replace with your actual form field name
    $date = date("Y-m-d"); // Default to current date
    $exercise_1 = $_POST['exercise_1'];
    $exercise_2 = $_POST['exercise_2'];
    $exercise_3 = $_POST['exercise_3'];
    $reason_1 = $_POST['reason_1'];
    $reason_2 = $_POST['reason_2'];
    $reason_3 = $_POST['reason_3'];

    // Check if data for the current date already exists
    $checkSql = "SELECT * FROM excercise_status WHERE pid = '$pid' AND date = '$date'";
    $result = $conn->query($checkSql);

    if ($result->num_rows > 0) {
        $response['status'] = false;
        $response['message'] = "Data for today already exists";
    } else {
        // SQL query to insert data into the exercise_status table
        $insertSql = "INSERT INTO excercise_status (pid, date, exercise_1, exercise_2, exercise_3, reason_1, reason_2, reason_3) VALUES ('$pid', '$date', '$exercise_1', '$exercise_2', '$exercise_3', '$reason_1', '$reason_2', '$reason_3')";

        if ($conn->query($insertSql) === TRUE) {
            $response['status'] = true;
            $response['message'] = "Record added successfully";
        } else {
            $response['status'] = false;
            $response['message'] = "Error inserting record in exercise_status table: " . $conn->error;
        }
    }

    // Send the response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
