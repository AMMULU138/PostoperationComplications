<?php
$conn = new mysqli("localhost", "root", "", "poc");
error_reporting(E_ALL);
ini_set('display_errors', 1);
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "poc");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get input data from the application
    $targetDirectory = "uploads/";

    function uploadImages($fieldName) {
        global $targetDirectory;
        $result = [];

        if (isset($_FILES[$fieldName]) && is_array($_FILES[$fieldName]["name"])) {
            foreach ($_FILES[$fieldName]["name"] as $key => $value) {
                $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"][$key]);
                $uploadError = $_FILES[$fieldName]["error"][$key];

                if ($uploadError !== UPLOAD_ERR_OK) {
                    // Handle upload error
                    $result[] = null;
                    continue; // Skip to the next file
                }

                if (move_uploaded_file($_FILES[$fieldName]["tmp_name"][$key], $targetFile)) {
                    $result[] = $targetFile;
                } else {
                    // Handle move_uploaded_file error
                    $result[] = null;
                }
            }
        } elseif (isset($_FILES[$fieldName])) {
            $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"]);
            $uploadError = $_FILES[$fieldName]["error"];

            if ($uploadError !== UPLOAD_ERR_OK) {
                // Handle upload error
                $result[] = null;
            } elseif (move_uploaded_file($_FILES[$fieldName]["tmp_name"], $targetFile)) {
                $result[] = $targetFile;
            } else {
                // Handle move_uploaded_file error
                $result[] = null;
            }
        }

        return $result;
    }

    $ppimage = isset($_FILES["ppimage"]) ? uploadImages("ppimage") : [];

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $pid = $_POST['pid'];
        $pname = $_POST['pname'];
        $ppassword = $_POST['ppassword'];
        $pgender = $_POST['pgender'];
        $pmail = $_POST['pmail'];
        $paddress = $_POST['paddress'];
        $pconsultant = $_POST['pconsultant'];

        // Check if the user_id already exists in patientopdetails
        $check_sql = "SELECT pid FROM patient WHERE pid = '$pid'";
        $check_result = $conn->query($check_sql);

        if ($check_result->num_rows > 0) {
            // User already exists
            $response = array('status' => false, 'message' => 'User already exists.');
            echo json_encode($response);
        } else {
            // Process the image paths
            $imagePaths = implode(",", array_filter($ppimage));
            $sql = "INSERT INTO patient (pid, pname, ppassword, pgender, pmail, paddress, pconsultant, ppimage) VALUES
            ('$pid', '$pname', '$ppassword', '$pgender', '$pmail', '$paddress', '$pconsultant', '$imagePaths')";

            if ($conn->query($sql) === TRUE) {
                // Successful insertion
                $response = array('status' => true, 'message' => 'Patient registration successful.');
                echo json_encode($response);
            } else {
                // Error in database insertion
                $response = array('status' => false, 'message' => 'Error: ' . $conn->error);
                echo json_encode($response);
            }
        }
    } else {
        // Handle non-POST requests (e.g., return an error response)
        $response = array('status' => false, 'message' => 'Invalid request method.');
        echo json_encode($response);
    }

    // Close the database connection
    $conn->close();
}
?>

