<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$response = array();

$conn = new mysqli("localhost", "root", "", "poc");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    // Sanitize and validate $data as needed

    $sql = "SELECT pid, pname ,ppimage FROM patient";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $response["status"] = "success";
            $response["message"] = "Data retrieved successfully";
            $response['data'] = array();
            while ($row = $result->fetch_assoc()) {
                $patientData = array(
                    "pid" => $row["pid"],
                    "pname" => $row["pname"]
                );

                $ppimage = $row["ppimage"];
                if (!empty($ppimage) && file_exists($ppimage)) {
                    $patientData["ppimage"] = $ppimage;
                } else {
                    error_log("Image not found or invalid path for ID: " . $row["pid"]);
                    $patientData["ppimage"] = ""; // Set a default value for image if not found
                }
                
                array_push($response['data'], $patientData);
            }
        } else {
            $response["status"] = "error";
            $response["message"] = "No results found";
        }

        $stmt->close();
    } else {
        $response["status"] = "error";
        $response["message"] = "Error preparing statement: " . $conn->error;
    }
} else {
    $response["status"] = "error";
    $response["message"] = "Invalid request method";
}

$conn->close();
echo json_encode($response, JSON_PRETTY_PRINT);
?>
