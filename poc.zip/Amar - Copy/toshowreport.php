<?php
// Check if 'pid' and 'date' parameters are set in the request
$conn = new mysqli("localhost", "root", "", "poc");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
header('Content-Type: application/json; charset=UTF-8');
$response = array();

if (isset($_POST['pid']) && isset($_POST['date'])) {
    // Retrieve the 'pid' and 'date' parameter values
    $pid = $_POST['pid'];
    $date = $_POST['date'];

    // Use prepared statement to prevent SQL injection
    $sql = "SELECT addvice, updatedmed
            FROM medicalreports 
            WHERE pid = ? AND date = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $pid, $date);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $response['status'] = "success";
        $response['message'] = "Data found";
        $response['data'] = array();

        while ($row = $result->fetch_assoc()) {
            $data = array(
                "addvice" => $row['addvice'],
                "updatedmed" => $row['updatedmed'],
            );

            array_push($response['data'], $data);
        }
    } else {
        $response['status'] = "error";
        $response['message'] = "No results found for the given PID and date";
    }
} else {
    // If 'pid' or 'date' parameters are not set, handle the error accordingly
    $response['status'] = "error";
    $response['message'] = "Both 'pid' and 'date' parameters are required in the request.";
}

$conn->close();

// Convert PHP array to JSON and output the response
echo json_encode($response);
?>
