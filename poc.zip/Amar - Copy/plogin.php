<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") 
    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "poc");

    // Check connect<?php 

$conn = new mysqli("localhost","root","","poc");

if($_SERVER['REQUEST_METHOD'] === 'POST')
{
    $pid = $_POST['pid'];
    $ppassword = $_POST['ppassword'];

    $sql = "SELECT * FROM patient WHERE pid = '$pid' AND ppassword = '$ppassword' ";
    $result = $conn->query($sql);

    if($result->num_rows > 0)
    {
        $response = array('status' => 'success', 'message' =>'Login Success');
    }
    else
    {
        $response = array('status' => 'error', 'message' =>'Login Failed');
    }
}
else
{
    $response = array('status' => 'error', 'message' =>'Invalid request method');
}
echo json_encode($response);

$conn->close();
?>
           