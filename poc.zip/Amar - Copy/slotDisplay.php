<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = new mysqli("localhost", "root", "", "poc");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $data = array();
    $Did = $conn->real_escape_string($_POST["Did"]);
    $date = date("Y-m-d", strtotime($conn->real_escape_string($_POST["date"])));

    $sql = "SELECT slot_options.slot
            FROM (
                SELECT 'MORNING' AS slot
                UNION
                SELECT 'AFTERNOON' AS slot
                UNION
                SELECT 'NIGHT' AS slot
            ) AS slot_options
            WHERE slot_options.slot NOT IN (
                SELECT slot
                FROM appointment
                WHERE Did = ? AND date = ? AND status = 'approved'
            )";

    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("ss", $Did, $date);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result) {
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $data[] = $row['slot'];
                }

                $response = array('status' => true, 'message' => 'Available slots', 'data' => $data);
                echo json_encode($response, JSON_PRETTY_PRINT);
            } else {
                $response = array('status' => false, 'message' => 'No available slots for this date and Did');
                echo json_encode($response, JSON_PRETTY_PRINT);
            }
        } else {
            $response = array('status' => false, 'message' => 'Query Error: ' . $conn->error);
            echo json_encode($response, JSON_PRETTY_PRINT);
        }

        $stmt->close();
    } else {
        $response = array('status' => false, 'message' => 'Error preparing statement: ' . $conn->error);
        echo json_encode($response, JSON_PRETTY_PRINT);
    }

    $conn->close();
} else {
    $response = array('status' => false, 'message' => 'Invalid request method');
    echo json_encode($response, JSON_PRETTY_PRINT);
}
?>
