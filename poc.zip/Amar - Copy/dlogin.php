 <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") 
    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "poc");

    // Check connect<?php 

$conn = new mysqli("localhost","root","","poc");

if($_SERVER['REQUEST_METHOD'] === 'POST')
{
    $Did = $_POST['Did'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM doctor WHERE Did = '$Did' AND password = '$password' ";
    $result = $conn->query($sql);

    if($result->num_rows > 0)
    {
        $response = array('status' => true , 'message' =>'Login Success');
    }
    else
    {
        $response = array('status' => false, 'message' =>'Login Failed');
    }
}
else
{
    $response = array('status' => false, 'message' =>'Invalid request method');
}
echo json_encode($response);

$conn->close();
?>
           