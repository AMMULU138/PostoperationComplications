<?php
// Check if all necessary parameters are provided
if (isset($_POST['pid'])) {
    $conn = new mysqli("localhost", "root", "", "poc");

    // Check connection
    if ($conn->connect_error) {
        $response = array(
            "status" => "error",
            "message" => "Connection failed: " . $conn->connect_error
        );
    } else {
        $pid = $_POST['pid'];
        $Did = $_POST['Did'];
        $docname = $_POST['docname'];
        $slot = $_POST['slot'];
        $date = $_POST['date'];
        $status = 'pending';

        // Check if the patient exists
        $checkStmt = $conn->prepare("SELECT * FROM patient WHERE pid = ?");
        $checkStmt->bind_param("i", $pid);
        $checkStmt->execute();
        $result = $checkStmt->get_result();

        if ($result->num_rows > 0) {
            // Patient exists, proceed to add medical report
            $insertStmt = $conn->prepare("INSERT INTO appointment (pid,Did,docname, slot, date,status) VALUES (?,?,?,?,?,?)");
            $insertStmt->bind_param("iissss", $pid,$Did, $docname,$slot,$date,$status );

            if ($insertStmt->execute()) {
                // Insert successful
                $response = array(
                    "status" => true,
                    "message" => "Medications and advice added to MedicalReports for the patient."
                );
            } else {
                // Error in insert
                $response = array(
                    "status" => false,
                    "message" => "Error adding medications and advice to MedicalReports: " . $conn->error
                );
            }
            $insertStmt->close();
        } else {
            // Patient does not exist in the database
            $response = array(
                "status" => false,
                "message" => "Patient with ID $patientID does not exist."
            );
        }
        $checkStmt->close();
        $conn->close();
    }
} else {
    // If parameters are missing in the request
    $response = array(
        "status" => false,
        "message" => "Missing parameters in the request."
    );
}

// Output JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
