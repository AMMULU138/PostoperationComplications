<?php
session_start();

$response = array(); // Initialize an empty associative array to store response data

$conn = new mysqli("localhost", "root", "", "poc");

if ($conn->connect_error) {
    $response['status'] = false;
    $response['message'] = "Connection failed: " . $conn->connect_error;
} else {
    $tableName = "doctor";
    
    // Retrieve data from the doctor table
    $sql = "SELECT * FROM $tableName";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $doctors = array(); // Initialize an array to store doctor data

        while ($row = $result->fetch_assoc()) {
            $doctorData = array(
                'Did' => $row['Did'],
                'docname' => $row['docname'],
                'specalization' => $row['specalization'],
               
                // Add more fields as needed
            );

            $doctors[] = $doctorData;
        }

        $response['status'] = true;
        $response['doctors'] = $doctors;
    } else {
        $response['status'] = false;
        $response['message'] = "No data found in the $tableName table";
    }

    $conn->close();
}

// Send JSON response
sendResponse($response);

function sendResponse($response) {
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
}
?>
 